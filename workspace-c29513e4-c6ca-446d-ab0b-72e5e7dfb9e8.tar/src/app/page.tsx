'use client';

import dynamic from 'next/dynamic';

const GameClient = dynamic(() => import('@/components/game/GameClient'), {
  ssr: false,
  loading: () => (
    <div className="fixed inset-0 flex items-center justify-center bg-black">
      <div className="font-vhs text-2xl text-[#f2ecd2] vhs-text vhs-blink">LOADING TAPE...</div>
    </div>
  ),
});

export default function Home() {
  return <GameClient />;
}
