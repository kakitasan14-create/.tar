import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "The Backrooms: Level 0 - Found Footage",
  description:
    "A procedural first-person Backrooms horror game: mono-yellow maze, a stalker that hunts by sound, VHS 1996 camcorder look, branching endings. Headphones recommended.",
  keywords: ["Backrooms", "Level 0", "horror game", "Three.js", "procedural", "VHS", "found footage"],
  authors: [{ name: "Z.ai Code" }],
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  openGraph: {
    title: "The Backrooms: Level 0 - Found Footage",
    description:
      "It hunts by sound. It only exists on tape. A fully procedural VHS horror descent - every maze, texture and sound is synthesized the moment you press play.",
    type: "website",
    images: [{ url: "/og-art.jpg", width: 1200, height: 630, alt: "The Backrooms: Level 0 - found footage VHS still" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "The Backrooms: Level 0 - Found Footage",
    description: "It hunts by sound. It only exists on tape. Fully procedural VHS horror in your browser.",
    images: ["/og-art.jpg"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=VT323&display=swap" rel="stylesheet" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
