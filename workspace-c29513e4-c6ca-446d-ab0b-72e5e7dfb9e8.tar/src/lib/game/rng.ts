// Seeded RNG + periodic value noise (tileable) for procedural Backrooms textures.

export function mulberry32(seed: number): () => number {
  let t = seed >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = t;
    r = Math.imul(r ^ (r >>> 15), r | 1);
    r ^= r + Math.imul(r ^ (r >>> 7), r | 61);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Value noise on a wrapping lattice: sampling [0,1) with `period` lattice cells tiles seamlessly. */
export class PeriodicNoise {
  private perm: Uint8Array;

  constructor(seed: number) {
    const rand = mulberry32(seed);
    this.perm = new Uint8Array(512);
    const base = new Uint8Array(256);
    for (let i = 0; i < 256; i++) base[i] = i;
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      const tmp = base[i];
      base[i] = base[j];
      base[j] = tmp;
    }
    for (let i = 0; i < 512; i++) this.perm[i] = base[i & 255];
  }

  private lat(ix: number, iy: number, period: number): number {
    const x = ((ix % period) + period) % period;
    const y = ((iy % period) + period) % period;
    return this.perm[(this.perm[x & 255] + y) & 255] / 255;
  }

  /** u,v in [0,1). Returns [0,1]. */
  value(u: number, v: number, period: number): number {
    const x = u * period;
    const y = v * period;
    const x0 = Math.floor(x);
    const y0 = Math.floor(y);
    const fx = x - x0;
    const fy = y - y0;
    const sx = fx * fx * (3 - 2 * fx);
    const sy = fy * fy * (3 - 2 * fy);
    const a = this.lat(x0, y0, period);
    const b = this.lat(x0 + 1, y0, period);
    const c = this.lat(x0, y0 + 1, period);
    const d = this.lat(x0 + 1, y0 + 1, period);
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  }

  /** Fractal brownian motion, each octave doubles the period so the tile stays seamless. */
  fbm(u: number, v: number, basePeriod: number, octaves: number): number {
    let sum = 0;
    let amp = 0.5;
    let norm = 0;
    let p = basePeriod;
    for (let o = 0; o < octaves; o++) {
      sum += this.value(u, v, p) * amp;
      norm += amp;
      amp *= 0.5;
      p *= 2;
    }
    return sum / norm;
  }
}
