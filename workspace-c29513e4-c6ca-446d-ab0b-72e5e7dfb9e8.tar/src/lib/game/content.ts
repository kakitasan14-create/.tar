// Narrative content: dialogue scripts (radio K / inner monologue) and the
// collectible M.E.G. lore pages.

export interface DialogueLine {
  speaker: 'YOU' | 'K' | '???';
  text: string;
  garble?: boolean; // radio static flavor
}

export const NOTES: { title: string; body: string }[] = [
  {
    title: 'M.E.G. FIELD REPORT 0-14 (PAGE 1)',
    body:
      'Designation: LEVEL 0. Approx. 600 million sq mi of segmented empty rooms. Damp carpet. Mono-yellow wallpaper. Fluorescent hum at all times.\n\nNo entities confirmed on this floor as of this report. Supplies: none. Exits: unstable.\n\nIf you are reading this and you can still hear your own heartbeat: good. Keep it that way.',
  },
  {
    title: "WANDERER'S JOURNAL - PAGE 1",
    body:
      'day 3? maybe 4.\n\nthe hum never stops. you stop hearing it after a while and that is WORSE, because then you start hearing the other thing underneath it.\n\nfound a water bottle shaped like an almond. tastes like calm. i am keeping them.',
  },
  {
    title: "WANDERER'S JOURNAL - PAGE 2",
    body:
      'it listens.\n\nwalking is fine. it does not care about walking. but RUNNING - running is a dinner bell.\n\nwhen you must run, run short. break the sight. corners are currency. spend them well.',
  },
  {
    title: 'M.E.G. BULLETIN - ALMOND WATER',
    body:
      'Almond Water: potable. Restores stamina and steadies the nerves. Mildly anesthetic scent.\n\nField use: if something is tracking you, one sip clouds its nose. It will lose your trail for a while. Do not rely on it twice in a row.',
  },
  {
    title: 'SCRAWLED PAGE - UNKNOWN',
    body:
      'NOT EVERY DOOR IS A DOOR\n\nsome of them are MOUTHS\n\nthe one with the smile hums a tune and the tune is nice and THAT IS THE POINT',
  },
  {
    title: 'M.E.G. MAP FRAGMENT - GRID E',
    body:
      '...stairwell shaft registered at grid E7. Sealed. Lamp circuit runs off MAINS power - somewhere there is a breaker room that still holds charge.\n\nRestore mains, the shaft lights, and Level 1 is one cold ladder away.',
  },
  {
    title: "WANDERER'S JOURNAL - PAGE 3",
    body:
      'found others today. they stand very still and they SMILE now.\n\nthey asked me to the party. they said there will be balloons.\n\ni said no.\n\nthey said the invitation does not expire.',
  },
  {
    title: 'M.E.G. WARNING - "LEVEL FUN"',
    body:
      'DO NOT follow the music. DO NOT open doors marked =).\n\nSurvivors who attend never report back. The few recovered recordings show a party that never ends and guests who never stop smiling.\n\nThere is no cake. There was never going to be cake.',
  },
  {
    title: "WANDERER'S JOURNAL - FINAL PAGE",
    body:
      'i hear the music box from here.\n\nit is such a pretty little tune.\n\ni am so tired of walking.\n\nif you found this page: come to the party =) we saved you a seat =) =) =)',
  },
  {
    title: 'ELECTRICAL ROOM MEMO',
    body:
      'Breaker LEVER feeds the stairwell lamps. Flip it and the shaft goes live - AND the whole floor goes dark while the grid reroutes.\n\nEvery... thing... on this level hears that lever.\n\nPlan your exit before you pull it. We will not plan it for you.',
  },
  {
    title: 'TORN CAMCORDER LABEL',
    body:
      'property of M.E.G. Scout-4 "K". If found:\n\n1. the camera is not haunted, the FLOOR is\n2. do not record the smiling ones, they pose\n3. almond water is not a mixer\n4. get out. seriously. get out.',
  },
  {
    title: 'M.E.G. MEMO - THIN WALLS',
    body:
      'Survey note: wallpaper panel E-15 rings hollow when struck. Rat-scratches behind it. The hole was made FROM THE OTHER SIDE.\n\nDo not patch it. The things that patch holes here are not maintaining the building. They are maintaining the trap.\n\nIf the breach is still open: crawl. What waits on the other side does not smile.',
  },
  {
    title: 'OUTPOST LOG - ECHO-4',
    body:
      'Day 12 in the Hub. The tunnel lamps hold. A trade caravan passed through - they speak of doors to a hundred levels, and of a lift that goes UP.\n\nWe are moving camp deeper tonight. The yellow floor hums louder every day, like it is getting hungry again.\n\nIf you read this: the lift works. The lift always works. Do not ask what powers it. - Sgt. Aoyama, M.E.G.',
  },
  {
    title: 'PUMP ROOM NOTICE',
    body:
      'FACILITY ORDER 7-C: the east gallery floods when the water table rises. The pump rig was left RUNNING when the floor merged.\n\nIt will run forever. That is the problem - the mains it draws is the same mains that feeds the freight lift.\n\nIf you need the lift: shut the pump down at the rig, and the lift circuit goes live. Mind the water. It is deeper than it looks and it is NOT almond.',
  },
  {
    title: "SURVIVOR'S LETTER - UNSIGNED",
    body:
      'whoever reads this - i made it further than anyone. the tunnels. the camp. the lift.\n\ni stood at the cage and the button was dead and i laughed because of course. of course the last door needs a key.\n\nthe pump room is east. i could hear the water from here. i am going to try. if i do not come back for this letter, tell K i almost made it.\n\ntell her i was not scared.',
  },
];

// ---- dialogue scripts ----

export const SCRIPTS: Record<string, DialogueLine[]> = {
  intro: [
    { speaker: 'YOU', text: '...where. Where am I?' },
    { speaker: 'YOU', text: 'The floor is wet. The lights are... wrong.' },
    { speaker: 'YOU', text: 'Okay. Get up. GET UP.' },
  ],
  kIntro: [
    { speaker: '???', text: '-zzt- ...anyone on this band? Hello, camcorder person.', garble: true },
    { speaker: 'K', text: 'Name is K. M.E.G. Scout-4. I picked up your camera light on the seismic sweep. You no-clipped into LEVEL 0.', garble: true },
    { speaker: 'K', text: 'Do not panic. Panic is loud, and this floor listens.', garble: true },
  ],
  kGoal: [
    { speaker: 'K', text: 'Two ways out that we trust. A maintenance stairwell far off your grid - dead, unless you feed it mains power.', garble: true },
    { speaker: 'K', text: 'And a second door. The one that hums. Whatever you hear behind it: that is NOT an exit.', garble: true },
  ],
  kHum: [
    { speaker: 'K', text: 'That hum in the walls? It lies. It wants you to believe the yellow is safe. Keep moving.', garble: true },
  ],
  kWater: [
    { speaker: 'K', text: 'Almond water. Good. Drink it when your legs give out - one sip clouds ITS nose if it is tracking you.', garble: true },
  ],
  kStalker: [
    { speaker: 'K', text: 'Listen to me. Something walks this floor. Tall. Smiling. It does not see well - but it HEARS running.', garble: true },
    { speaker: 'K', text: 'Sprint in bursts. Break its line of sight. Corners are currency.', garble: true },
  ],
  kPillars: [
    { speaker: 'K', text: 'Pillar hall on my sweep. Landmark it in your head. When it hunts you, halls like this are where you die.', garble: true },
  ],
  kElectrical: [
    { speaker: 'K', text: 'There is a breaker room near you - my map says grid E-something. Find the lever. The stairwell lamps run on mains.', garble: true },
  ],
  kBlackout: [
    { speaker: 'K', text: '-zzt- WHAT DID YOU TOUCH?! The grid just rerouted, everything is dark on my sweep--', garble: true },
    { speaker: 'K', text: 'Something is MOVING on the grid. Toward you. RUN. Do not stop. DO NOT STOP.', garble: true },
  ],
  kBlackoutEnd: [
    { speaker: 'K', text: '...Lights are back. I lost you for a minute. I do not want to do that again.', garble: true },
    { speaker: 'K', text: 'Stairwell E7 is LIVE now. Level 1 is cold, wet and ugly - but it is REAL. Get out of this floor.', garble: true },
  ],
  kHubHint: [
    { speaker: 'K', text: 'One more thing. My seismic sweep just flagged a void behind the wallpaper - junction room with the signposts, east wall. Old pre-merge structure.', garble: true },
    { speaker: 'K', text: 'The old-timers call it THE HUB. Concrete. Lamps. No hum. If the legends hold, that hole is the only door on this floor that does not scream.', garble: true },
  ],
  kHubEnter: [
    { speaker: 'YOU', text: 'The wallpaper is loose. Something dug through here from the other side. Recently.' },
    { speaker: 'K', text: 'That breach just lit up my sweep. If it holds, it drops into THE HUB. Crawl through. I will watch your dot.', garble: true },
  ],
  kHubArrive: [
    { speaker: 'YOU', text: 'Concrete. Actual poured concrete. It even smells like rain down here.' },
    { speaker: 'K', text: '...there you are. Different signature on the sweep. Quiet. You found it, camcorder person. That is THE HUB.', garble: true },
    { speaker: 'K', text: 'It cannot follow you in there. Follow the tunnel. There is supposed to be an outpost. And hey - good job not dying.', garble: true },
  ],
  kOutpost: [
    { speaker: 'K', text: 'An Echo-4 outpost! Someone stockpiled almond water here and never came back for it. Take it. All of it.', garble: true },
    { speaker: 'YOU', text: "There's a map on the table. Someone drew doors on it. Dozens of doors." },
    { speaker: 'K', text: 'The Hub connects everywhere. That is the legend anyway. The freight lift at the end of the tunnel goes UP. Take it.', garble: true },
  ],
  kElevator: [
    { speaker: 'YOU', text: 'A freight lift. The call button is still warm.' },
    { speaker: 'K', text: 'Then someone used it recently. Call it. If the cage opens - get in, ride it up, and do not look back.', garble: true },
  ],
  kMachineHint: [
    { speaker: 'YOU', text: 'Water. There is water on the concrete - it runs east, toward a machine noise.' },
    { speaker: 'K', text: 'That will be the old pump gallery. My sweep shows a heavy draw on that circuit - something down there is drinking the mains.', garble: true },
    { speaker: 'K', text: 'If the lift is dead, THAT is why. Find the rig. Shut it down. Watch your step in the water.', garble: true },
  ],
  kMachine: [
    { speaker: 'YOU', text: 'Pump is down. The whole tunnel just... exhaled.' },
    { speaker: 'K', text: '-zzt- Draw just dropped to zero and the lift circuit is LIVE on my sweep. That was you? Good work. Get to that cage.', garble: true },
  ],
  kLiftNoPower: [
    { speaker: 'YOU', text: 'The button clicks. Nothing. The cage is dead.' },
    { speaker: 'K', text: 'No draw on the shaft circuit - the lift has no power. Something on this level is drinking the mains. Follow the water.', garble: true },
  ],
  kNearParty: [
    { speaker: 'K', text: 'That music box... do you hear it? That is an invitation, not an exit. WALK. AWAY.', garble: true },
  ],
  kStairwellReady: [
    { speaker: 'K', text: 'Stairwell is live - the lamp above the door should be green. Go. I will find you below.', garble: true },
  ],
  kFinale: [
    { speaker: 'K', text: "It's right behind you. I'm sorry. GO. NOW.", garble: true },
  ],
  caught: [{ speaker: '???', text: '=)', garble: false }],
  endingA: [
    { speaker: 'YOU', text: 'Cold air. Real air. It smells like rust and rain.' },
    { speaker: 'YOU', text: 'The hum is gone. I never thought silence could feel this loud.' },
    { speaker: 'K', text: '-zzt- Welcome to LEVEL 1, camcorder person. Keep walking. I am on my way.', garble: true },
  ],
  endingB: [
    { speaker: '???', text: 'You came! =)' },
    { speaker: '???', text: 'Everyone stayed. Everyone smiled. The party is forever. =)' },
    { speaker: '???', text: 'We saved you a seat. Right here. In the front. =) =) =)' },
  ],
  endingC: [
    { speaker: 'YOU', text: 'The cage rattles upward. The hum fades below the floor. For real, this time.' },
    { speaker: 'K', text: '-zzt- Elevator trace confirmed - you are rising through a live shaft. Concrete all the way up.', garble: true },
    { speaker: 'K', text: 'See you topside, camcorder person. First round of almond water is on me.', garble: true },
  ],
};
