// The Smiler - a stalker that hunts by sound and LIVES IN THE DARK. States:
// dormant -> stalk (move to last heard noise) -> hunt (has line of sight)
// -> search (lost you) -> retreat (teleports away, cooldown).
// It is a creature of the dark areas of the backrooms: it spawns in dead-light
// pockets, routes through shadow (weighted pathfinding), retreats from bright
// circuits, hesitates at the edge of the light where you stand, and its grin
// only truly glows where the panels are dead. During the blackout set piece it
// gets "forced knowledge" ticks and the whole floor becomes its territory.

import * as THREE from 'three';
import { MazeData, GRID, CELL, findPath, hasLOS, cellCenterWorld, randomOpenCellFar } from './maze';
import { GameTextures } from './textures';

export type EntityState = 'dormant' | 'stalk' | 'hunt' | 'search' | 'retreat';

export interface EntityEvents {
  onFootstep: (hunting: boolean, pan: number, vol: number) => void;
  onDetect: () => void;
  onLunge: (pan: number, vol: number) => void;
  onTransition: (from: EntityState, to: EntityState) => void;
}

/** Anything that can answer "how lit is this world position (0..1)". */
export interface LightField {
  lightAt(x: number, z: number): number;
}

const HUNT_SPEED = 4.55;
const STALK_SPEED = 3.1;
const SEARCH_SPEED = 2.6;
const DETECT_DIST = 17;
const SENSE_DIST = 3.6; // point-blank 360 senses
const CATCH_DIST = 1.25;
const LUNGE_DIST = 6.2;   // opens the charge when it sees you this close
const LUNGE_MULT = 1.42;  // burst speed multiplier
const LUNGE_TIME = 1.15;  // burst duration (s)
const LUNGE_COOLDOWN = 3.4;
const LIGHT_COMFORT = 0.7;  // above this it is standing in light it hates
const LIGHT_EDGE = 5.8;     // how close it will press toward a lit player

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export class Entity {
  group = new THREE.Group();
  pos = new THREE.Vector3();
  state: EntityState = 'dormant';
  stateTimer = 0;
  path: { x: number; y: number }[] = [];
  repathTimer = 0;
  lastHeard: { x: number; z: number } | null = null;
  lastSeen: { x: number; z: number } | null = null;
  lostSightTimer = 0;
  stepTimer = 0;
  aggressive = false; // post-blackout mode: faster + keener hearing, ignores light
  forcedKnowledgeTimer = 0;
  dormantCooldown = 0;
  private light: LightField | null = null;
  private grinMat!: THREE.MeshBasicMaterial;
  private head!: THREE.Group;
  private twitchTimer = 0;
  private wanderTimer = 0;
  private wanderTarget: { x: number; z: number } | null = null;
  private lungeT = 0;        // remaining burst time
  private lungeCd = 0;       // seconds until next lunge is allowed
  private huntRage = 0;      // builds the longer the hunt lasts (grin/audio)
  private holdingEdge = false; // paused at the rim of the player's light

  /** Lunge multiplier currently applied to hunt speed (for HUD/AI debug). */
  get lunging(): boolean {
    return this.lungeT > 0;
  }

  constructor(private maze: MazeData, private tex: GameTextures, private events: EntityEvents) {
    void this.tex;
    this.build();
    this.group.visible = false;
  }

  /** Wire the level's light field once the level exists. */
  setLightField(f: LightField | null): void {
    this.light = f;
  }

  private build(): void {
    const bodyMat = new THREE.MeshBasicMaterial({ color: 0x060605 });
    // elongated torso
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 1.0, 4, 10), bodyMat);
    torso.position.y = 1.35;
    torso.scale.set(1, 1, 0.72);
    this.group.add(torso);
    // hips + legs merged silhouette
    const hips = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.14, 0.9, 8), bodyMat);
    hips.position.y = 0.45;
    this.group.add(hips);
    // arms - too long, hanging
    for (const side of [-1, 1]) {
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 1.15, 3, 8), bodyMat);
      arm.position.set(side * 0.32, 1.28, 0);
      arm.rotation.z = side * 0.08;
      this.group.add(arm);
    }
    // head with grin billboard
    this.head = new THREE.Group();
    this.head.position.y = 2.12;
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.21, 12, 10), bodyMat);
    skull.scale.set(0.9, 1.15, 0.95);
    this.head.add(skull);
    this.grinMat = new THREE.MeshBasicMaterial({ map: this.tex.grin, transparent: true, depthWrite: false });
    const grin = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.5), this.grinMat);
    grin.position.z = 0.16;
    grin.name = 'grin';
    this.head.add(grin);
    this.group.add(this.head);
  }

  // ---------------- light helpers ----------------

  /** 0 = blazing light, 1 = pitch dark at a world position. */
  private darkness(x: number, z: number): number {
    if (!this.light) return 0.5;
    return clamp01(1 - this.light.lightAt(x, z));
  }

  /**
   * Sample the ring around a point and return the darkest cell center - this
   * is where it lurks, creeps and flees to. Falls back to the query point.
   */
  private darkSpotNear(px: number, pz: number, minR: number, maxR: number, rand: () => number): { x: number; z: number } {
    if (!this.light) return { x: px, z: pz };
    let best: { x: number; z: number } | null = null;
    let bestScore = -Infinity;
    for (let i = 0; i < 8; i++) {
      const a = rand() * Math.PI * 2;
      const r = minR + rand() * (maxR - minR);
      const x = px + Math.cos(a) * r;
      const z = pz + Math.sin(a) * r;
      const dark = this.darkness(x, z);
      const score = dark * 2 + rand() * 0.45;
      if (score > bestScore) {
        bestScore = score;
        best = { x, z };
      }
    }
    return best ?? { x: px, z: pz };
  }

  /** Pathfinding cost that makes lit cells expensive: shadow is home turf. */
  private darkCost(): ((cx: number, cy: number) => number) | undefined {
    if (!this.light) return undefined;
    return (cx: number, cy: number) => {
      const w = cellCenterWorld(cx, cy);
      const l = this.light!.lightAt(w.x, w.z);
      return 1 + l * l * 6.0;
    };
  }

  /** Teleport far from the player into a DARK cell, then go dormant. */
  sendFar(playerX: number, playerZ: number, cooldown: number, rand: () => number): void {
    const pc = { x: Math.floor(playerX / CELL), y: Math.floor(playerZ / CELL) };
    const preferDark = this.light
      ? (x: number, y: number) => {
          const w = cellCenterWorld(x, y);
          return clamp01(1 - this.light!.lightAt(w.x, w.z));
        }
      : undefined;
    const cell = randomOpenCellFar(this.maze, rand, pc.x, pc.y, 14, preferDark);
    const w = cellCenterWorld(cell.x, cell.y);
    this.pos.set(w.x, 0, w.z);
    this.group.position.copy(this.pos);
    this.state = 'dormant';
    this.stateTimer = cooldown;
    this.lastHeard = null;
    this.lastSeen = null;
    this.path = [];
    this.holdingEdge = false;
    this.group.visible = false;
  }

  hearNoise(x: number, z: number, radius: number): void {
    if (this.state === 'dormant' && this.dormantCooldown > 0) return;
    const d = Math.hypot(this.pos.x - x, this.pos.z - z);
    const hearRange = radius * (this.aggressive ? 1.35 : 1);
    if (d > hearRange) return;
    this.lastHeard = { x, z };
    // Loud close noise (sprinting nearby) while already aware -> it stops being
    // polite and just charges. Quiet noises only make it investigate.
    const closeLoud = radius >= 14 && d < hearRange * 0.75;
    if ((this.state === 'stalk' || this.state === 'search') && (closeLoud || (d < 9 && this.aggressive))) {
      const from = this.state;
      this.state = 'hunt';
      this.stateTimer = 0;
      this.lastSeen = { x, z };
      this.lostSightTimer = 0;
      this.path = [];
      this.events.onTransition(from, 'hunt');
      return;
    }
    if (this.state === 'dormant' || this.state === 'retreat' || this.state === 'search') {
      const from = this.state;
      this.state = 'stalk';
      this.stateTimer = 0;
      this.path = [];
      this.events.onTransition(from, 'stalk');
    }
  }

  /** Blackout mode: the entity "knows" where you are every couple seconds. */
  forceKnowledge(x: number, z: number): void {
    this.forcedKnowledgeTimer = 2.2;
    this.lastHeard = { x, z };
    if (this.state === 'dormant' || this.state === 'retreat' || this.state === 'stalk') {
      const from = this.state;
      this.state = 'hunt';
      this.stateTimer = 0;
      this.events.onTransition(from, 'hunt');
    }
  }

  setHuntImmediate(): void {
    if (this.state !== 'hunt') {
      const from = this.state;
      this.state = 'hunt';
      this.stateTimer = 0;
      this.events.onTransition(from, 'hunt');
    }
  }

  private repathTo(tx: number, tz: number, cost?: (cx: number, cy: number) => number): void {
    const from = { x: Math.floor(this.pos.x / CELL), y: Math.floor(this.pos.z / CELL) };
    const to = { x: Math.max(0, Math.min(GRID - 1, Math.floor(tx / CELL))), y: Math.max(0, Math.min(GRID - 1, Math.floor(tz / CELL))) };
    this.path = findPath(this.maze, from.x, from.y, to.x, to.y, cost);
  }

  private moveAlongPath(dt: number, speed: number): boolean {
    if (this.path.length === 0) return false;
    const node = this.path[0];
    const w = cellCenterWorld(node.x, node.y);
    const dx = w.x - this.pos.x;
    const dz = w.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.45) {
      this.path.shift();
      return this.path.length > 0;
    }
    const step = Math.min(d, speed * dt);
    this.pos.x += (dx / d) * step;
    this.pos.z += (dz / d) * step;
    // face movement direction
    const targetYaw = Math.atan2(dx, dz);
    let diff = targetYaw - this.group.rotation.y;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.group.rotation.y += diff * Math.min(1, dt * 6);
    return true;
  }

  private setGrinIntensity(intensity: number, selfDark: number): void {
    // the grin only truly GLOWS in the dark; under live panels it fades to a
    // suggestion - the Smiler does not smile in the light
    const glow = 0.3 + 0.7 * selfDark;
    this.grinMat.opacity = (0.55 + intensity * 0.45) * glow;
    this.grinMat.color.setScalar((0.6 + intensity * 0.4) * (0.55 + 0.45 * glow));
  }

  update(dt: number, playerX: number, playerZ: number, rand: () => number): { caught: boolean; dist: number; visible: boolean } {
    const dist = Math.hypot(this.pos.x - playerX, this.pos.z - playerZ);
    const los = dist < 30 ? hasLOS(this.maze, this.pos.x, this.pos.z, playerX, playerZ) : false;
    const selfDark = this.darkness(this.pos.x, this.pos.z);
    const selfLit = !this.aggressive && this.light !== null && this.light.lightAt(this.pos.x, this.pos.z) > LIGHT_COMFORT;
    const playerLight = this.light ? this.light.lightAt(playerX, playerZ) : 1;
    // detection reaches further in its own domain (dark), shorter in the light
    const detect =
      DETECT_DIST *
      (playerLight < 0.35 ? 1.18 : playerLight > 0.75 ? 0.88 : 1);

    let moving = false;
    let hunting = false;

    switch (this.state) {
      case 'dormant': {
        this.stateTimer -= dt;
        this.dormantCooldown = Math.max(0, this.dormantCooldown - dt);
        if (this.stateTimer <= 0) {
          // wake and start drifting toward the player's general area
          this.state = 'stalk';
          this.lastHeard = { x: playerX + (rand() - 0.5) * 8, z: playerZ + (rand() - 0.5) * 8 };
          this.events.onTransition('dormant', 'stalk');
        }
        break;
      }
      case 'stalk': {
        hunting = false;
        if (this.lastHeard) {
          this.repathTimer -= dt;
          if (this.repathTimer <= 0 || this.path.length === 0) {
            this.repathTimer = 0.5;
            // route to the noise through the dark
            this.repathTo(this.lastHeard.x, this.lastHeard.z, this.darkCost());
          }
          moving = this.moveAlongPath(dt, STALK_SPEED * (this.aggressive ? 1.15 : 1));
          const arrived = Math.hypot(this.pos.x - this.lastHeard.x, this.pos.z - this.lastHeard.z) < 1.2 && this.path.length === 0;
          if (arrived) {
            this.lastHeard = null;
            this.stateTimer = 11; // linger in your area, hunting posture
          }
        } else {
          this.stateTimer -= dt;
          this.wanderTimer -= dt;
          if (this.wanderTimer <= 0) {
            this.wanderTimer = 2.2;
            // creep between shadow pockets near you, never standing in the open
            const spot = selfLit
              ? this.darkSpotNear(this.pos.x, this.pos.z, 3, 9, rand)
              : this.darkSpotNear(playerX, playerZ, 3.5, 9.5, rand);
            this.wanderTarget = spot;
            if (selfLit) this.repathTimer = 0; // leave the light immediately
          }
          if (this.wanderTarget) {
            this.repathTimer -= dt;
            if (this.repathTimer <= 0) {
              this.repathTimer = 0.55;
              this.repathTo(this.wanderTarget.x, this.wanderTarget.z, this.darkCost());
            }
            moving = this.moveAlongPath(dt, STALK_SPEED * (selfLit ? 1.25 : 0.72));
          }
          if (this.stateTimer <= 0) {
            this.state = 'retreat';
            this.stateTimer = 0;
          }
        }
        break;
      }
      case 'hunt': {
        hunting = true;
        this.huntRage = Math.min(1, this.huntRage + dt * 0.06);
        this.forcedKnowledgeTimer -= dt;
        this.lungeCd = Math.max(0, this.lungeCd - dt);
        const sensesYou = (los && dist < detect) || dist < SENSE_DIST || this.forcedKnowledgeTimer > 0;
        if (sensesYou) {
          this.lastSeen = { x: playerX, z: playerZ };
          this.lostSightTimer = 0;
        } else {
          this.lostSightTimer += dt;
        }
        // THE LIGHT RULE: standing in live light keeps it at bay - it stops at
        // the rim of your glow and waits, grin flickering. Rage (or the
        // blackout, or post-power aggression) overcomes the hesitation.
        const canStrike =
          this.aggressive || playerLight < 0.55 || this.huntRage > 0.65 || this.forcedKnowledgeTimer > 0;
        if (!canStrike && dist < LIGHT_EDGE) {
          this.holdingEdge = true;
          if (dist < 4.4) {
            // too close to the glow - give ground back into the dark
            if (this.repathTimer <= 0) {
              this.repathTimer = 0.5;
              const spot = this.darkSpotNear(this.pos.x, this.pos.z, 2.5, 7, rand);
              this.repathTo(spot.x, spot.z, this.darkCost());
            }
            moving = this.moveAlongPath(dt, STALK_SPEED * 1.1);
          }
        } else {
          this.holdingEdge = false;
          // THE ATTACK: direct sight + close -> explosive burst toward the player
          if (this.lungeT > 0) this.lungeT -= dt;
          else if (this.lungeCd <= 0 && los && dist < LUNGE_DIST && canStrike) {
            this.lungeT = LUNGE_TIME;
            this.lungeCd = LUNGE_COOLDOWN * (this.aggressive ? 0.6 : 1);
            this.events.onLunge(this.panHint(playerX, playerZ), clamp01(1.1 - dist / 14));
          }
          const target = this.lastSeen ?? { x: playerX, z: playerZ };
          this.repathTimer -= dt;
          if (this.repathTimer <= 0) {
            this.repathTimer = this.aggressive ? 0.28 : 0.38;
            this.repathTo(target.x, target.z); // hunts straight: rage ignores shadow
          }
          const burst = this.lungeT > 0 ? LUNGE_MULT : 1;
          moving = this.moveAlongPath(dt, HUNT_SPEED * (this.aggressive ? 1.07 : 1) * burst);
        }
        if (this.lostSightTimer > 2.6 && this.forcedKnowledgeTimer <= 0) {
          const from = this.state;
          this.state = 'search';
          this.stateTimer = 8;
          this.huntRage = 0;
          this.events.onTransition(from, 'search');
        }
        break;
      }
      case 'search': {
        if (this.lastSeen) {
          this.repathTimer -= dt;
          if (this.repathTimer <= 0 || this.path.length === 0) {
            this.repathTimer = 0.6;
            this.repathTo(this.lastSeen.x, this.lastSeen.z, this.darkCost());
          }
          moving = this.moveAlongPath(dt, SEARCH_SPEED);
          if (Math.hypot(this.pos.x - this.lastSeen.x, this.pos.z - this.lastSeen.z) < 1.3 && this.path.length === 0) {
            this.lastSeen = null;
          }
        } else {
          this.stateTimer -= dt;
          this.wanderTimer -= dt;
          if (this.wanderTimer <= 0) {
            this.wanderTimer = 2.2;
            // search from the shadows: it checks dark pockets, not open floor
            this.wanderTarget = this.darkSpotNear(this.pos.x, this.pos.z, 3, 9, rand);
          }
          if (this.wanderTarget) {
            this.repathTimer -= dt;
            if (this.repathTimer <= 0) {
              this.repathTimer = 0.7;
              this.repathTo(this.wanderTarget.x, this.wanderTarget.z, this.darkCost());
            }
            moving = this.moveAlongPath(dt, SEARCH_SPEED * 0.7);
          }
          if (this.stateTimer <= 0) {
            this.state = 'retreat';
          }
        }
        break;
      }
      case 'retreat': {
        this.state = 'dormant';
        this.dormantCooldown = this.aggressive ? 5 : 9;
        this.huntRage = 0;
        this.events.onTransition('retreat', 'dormant');
        break;
      }
    }

    // detection sting: transition into hunt via senses (scaled by your light)
    if (this.state !== 'hunt' && ((los && dist < detect) || dist < SENSE_DIST)) {
      if (this.state !== 'dormant' || this.dormantCooldown <= 0) {
        this.setHuntImmediate();
        this.events.onDetect();
      }
    }

    // NOTE: group.visible is owned by the game loop (the Smiler exists only on
    // tape). The entity must NOT self-hide - fighting the loop re-triggers the
    // reveal glitch burst every frame and pins the tape static at hunt levels.

    // footsteps
    if (moving) {
      this.stepTimer -= dt;
      if (this.stepTimer <= 0) {
        this.stepTimer = hunting ? 0.34 : 0.46;
        this.events.onFootstep(hunting, 0, 1); // pan/vol refined by game
      }
    }

    // pose: lean forward + grin intensity while hunting, twitchy head otherwise
    const lungePose = this.lungeT > 0 ? 0.34 : 0; // doubles over mid-charge
    const lean = hunting ? 0.16 + lungePose : 0.04;
    this.group.rotation.x = THREE.MathUtils.lerp(this.group.rotation.x, lean, dt * (this.lungeT > 0 ? 9 : 4));
    this.group.position.set(this.pos.x, hunting ? Math.sin(performance.now() * (this.lungeT > 0 ? 0.02 : 0.012)) * 0.05 : 0, this.pos.z);
    this.twitchTimer -= dt;
    if (this.twitchTimer <= 0) {
      this.twitchTimer = 0.4 + rand() * 1.4;
      this.head.rotation.z = (rand() - 0.5) * 0.5;
      this.head.rotation.x = (rand() - 0.5) * 0.24;
    }
    const t = performance.now() / 1000;
    let grin = hunting ? 1 : this.state === 'stalk' ? 0.55 : 0.3;
    if (this.holdingEdge) grin = 0.75 + Math.sin(t * 2.4) * 0.25; // smiling at you from the rim
    if (this.state === 'stalk' && dist < 12) grin += 0.1 + Math.sin(t * 2.1) * 0.08; // glinting in the dark
    this.setGrinIntensity(grin, selfDark);
    if (this.lungeT > 0) this.grinMat.color.setRGB(1.05, 0.98, 0.9); // flare white-hot mid-attack

    const caught = dist < CATCH_DIST && this.state !== 'dormant';
    return { caught, dist, visible: los && dist < detect };
  }

  private panHint(x: number, z: number): number {
    return Math.max(-1, Math.min(1, Math.atan2(x - this.pos.x, z - this.pos.z) / Math.PI));
  }

  /** Direction the grin should face (Y-billboard toward camera). */
  faceCamera(camX: number, camZ: number): void {
    const grin = this.head.getObjectByName('grin');
    if (!grin) return;
    const dx = camX - this.pos.x;
    const dz = camZ - this.pos.z;
    const worldYaw = Math.atan2(dx, dz) - this.group.rotation.y;
    this.head.rotation.y = worldYaw;
  }
}
