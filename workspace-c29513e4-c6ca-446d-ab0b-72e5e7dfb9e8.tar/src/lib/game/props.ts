// Low-poly prop builders. Every prop is plain boxes/cylinders/planes - the
// VHS filter and gloomy lighting do the heavy lifting.

import * as THREE from 'three';
import type { TextureSet } from './textures';

export const matBox = (color: number, emissive = 0x000000): THREE.MeshLambertMaterial =>
  new THREE.MeshLambertMaterial({ color, emissive });

function box(w: number, h: number, d: number, color: number, emissive = 0x000000): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), matBox(color, emissive));
  return m;
}

export function buildDesk(): { group: THREE.Group; collider: { w: number; d: number } } {
  const g = new THREE.Group();
  const top = box(1.7, 0.07, 0.85, 0x8a6f46);
  top.position.y = 0.78;
  g.add(top);
  for (const [lx, lz] of [[-0.78, -0.35], [0.78, -0.35], [-0.78, 0.35], [0.78, 0.35]]) {
    const leg = box(0.08, 0.78, 0.08, 0x4d4433);
    leg.position.set(lx, 0.39, lz);
    g.add(leg);
  }
  const drawer = box(0.55, 0.5, 0.75, 0x6d5a3a);
  drawer.position.set(0.45, 0.42, 0);
  g.add(drawer);
  return { group: g, collider: { w: 1.7, d: 0.85 } };
}

export function buildChair(): { group: THREE.Group; collider: { w: number; d: number } } {
  const g = new THREE.Group();
  const seat = box(0.46, 0.06, 0.46, 0x3c3630);
  seat.position.y = 0.46;
  g.add(seat);
  const back = box(0.46, 0.55, 0.06, 0x35302b);
  back.position.set(0, 0.76, -0.2);
  g.add(back);
  const pole = box(0.07, 0.42, 0.07, 0x23201d);
  pole.position.y = 0.22;
  g.add(pole);
  const base = box(0.5, 0.04, 0.5, 0x23201d);
  base.position.y = 0.02;
  g.add(base);
  return { group: g, collider: { w: 0.5, d: 0.5 } };
}

export function buildShelf(): { group: THREE.Group; collider: { w: number; d: number } } {
  const g = new THREE.Group();
  const frame = box(1.9, 2.1, 0.5, 0x4a4034);
  frame.position.y = 1.05;
  g.add(frame);
  for (let i = 0; i < 3; i++) {
    const crate = box(0.5, 0.36, 0.42, i % 2 ? 0x71603f : 0x5d5138);
    crate.position.set(-0.55 + i * 0.55, 0.6 + (i % 2) * 0.75, 0.02);
    g.add(crate);
  }
  return { group: g, collider: { w: 1.9, d: 0.5 } };
}

export function buildCrateStack(tex?: {
  map: THREE.Texture;
  bumpMap?: THREE.Texture;
}): { group: THREE.Group; collider: { w: number; d: number } } {
  const g = new THREE.Group();
  // box() builds MeshLambertMaterial (flat color), which cannot show a map +
  // bump - so the textured path builds the BoxGeometry meshes directly with a
  // MeshStandardMaterial instead. Geometry/colliders stay identical either way.
  const woodMat = tex
    ? new THREE.MeshStandardMaterial({
        map: tex.map,
        bumpMap: tex.bumpMap ?? null,
        bumpScale: 0.25,
        roughness: 0.85,
        metalness: 0,
      })
    : null;
  const a = woodMat
    ? new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.72, 0.72), woodMat)
    : box(0.72, 0.72, 0.72, 0x6a5a3c);
  a.position.y = 0.36;
  g.add(a);
  const b = woodMat
    ? new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.6), woodMat)
    : box(0.6, 0.6, 0.6, 0x5a4c32);
  b.position.set(0.06, 1.0, 0.04);
  b.rotation.y = 0.3;
  g.add(b);
  return { group: g, collider: { w: 0.8, d: 0.8 } };
}

/** Wall-mounted breaker box with a lever; leverRef rotates when pulled. */
export function buildBreaker(): { group: THREE.Group; leverRef: THREE.Mesh; lampOn: THREE.Mesh } {
  const g = new THREE.Group();
  const body = box(0.52, 0.74, 0.16, 0x4e5659);
  body.position.y = 1.45;
  g.add(body);
  const panel = box(0.4, 0.3, 0.02, 0x2c3234);
  panel.position.set(0, 1.62, -0.09);
  g.add(panel);
  const lever = box(0.09, 0.26, 0.07, 0xb03a2e);
  lever.position.set(-0.08, 1.36, -0.12);
  lever.geometry.translate(0, 0.13, 0);
  g.add(lever);
  const lampOff = box(0.06, 0.06, 0.03, 0x330d0a, 0x330d0a);
  lampOff.position.set(0.14, 1.7, -0.1);
  g.add(lampOff);
  const lampOn = box(0.06, 0.06, 0.03, 0x38ff62, 0x2fdd55);
  lampOn.position.set(0.14, 1.7, -0.1);
  lampOn.visible = false;
  g.add(lampOn);
  // cables along the wall
  for (const dy of [1.1, 1.05]) {
    const cable = box(2.2, 0.035, 0.035, 0x1d1a16);
    cable.position.set(1.2, dy, -0.06);
    g.add(cable);
  }
  return { group: g, leverRef: lever, lampOn };
}

/**
 * Almond Water bottle: lathe-profile glass shell, milky liquid inside, screw
 * cap with tamper ring, wrapped paper label and a faint pickup halo so it
 * reads in the dark. No external assets - everything procedural.
 */
export function buildBottle(labelTex: THREE.Texture): THREE.Group {
  const g = new THREE.Group();

  // glass profile (radius, height) - base, body, waist grip, shoulder, neck
  const profile: [number, number][] = [
    [0.001, 0.004],
    [0.048, 0.004],
    [0.058, 0.014],
    [0.060, 0.05],
    [0.058, 0.1],
    [0.05, 0.145],
    [0.046, 0.168],
    [0.052, 0.192],
    [0.047, 0.216],
    [0.032, 0.246],
    [0.022, 0.258],
    [0.022, 0.292],
  ];
  const lathePts = profile.map(([r, y]) => new THREE.Vector2(r, y));

  // inner liquid - same silhouette scaled in, filled ~3/4 and capped
  const liqPts: THREE.Vector2[] = [];
  for (const [r, y] of profile) {
    if (y > 0.21) break;
    liqPts.push(new THREE.Vector2(Math.max(0.001, r * 0.84), y));
  }
  liqPts.push(new THREE.Vector2(0.001, 0.206));
  const liquid = new THREE.Mesh(
    new THREE.LatheGeometry(liqPts, 18),
    new THREE.MeshLambertMaterial({ color: 0xf0f2e4, emissive: 0x38423a })
  );
  liquid.renderOrder = 0;
  g.add(liquid);

  // glass shell
  const glass = new THREE.Mesh(
    new THREE.LatheGeometry(lathePts, 18),
    new THREE.MeshLambertMaterial({
      color: 0xd3ece4,
      transparent: true,
      opacity: 0.42,
      emissive: 0x11221f,
      depthWrite: false,
    })
  );
  glass.renderOrder = 2;
  g.add(glass);

  // paper label band wrapped around the body
  const label = new THREE.Mesh(
    new THREE.CylinderGeometry(0.0635, 0.0635, 0.1, 20, 1, true),
    new THREE.MeshLambertMaterial({ map: labelTex })
  );
  label.position.y = 0.118;
  label.renderOrder = 1;
  g.add(label);

  // cap + tamper ring
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.04, 14), matBox(0xd9d2c0));
  cap.position.y = 0.31;
  g.add(cap);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.005, 6, 14), matBox(0xb23b30));
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.292;
  g.add(ring);

  // faint halo on the carpet (helps spotting bottles in dark corners)
  const halo = new THREE.Mesh(
    new THREE.CircleGeometry(0.3, 16),
    new THREE.MeshBasicMaterial({
      color: 0xbfe4d2,
      transparent: true,
      opacity: 0.13,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  halo.rotation.x = -Math.PI / 2;
  halo.position.y = 0.012;
  g.add(halo);

  return g;
}

/** Procedural brand sticker for the camcorder body (reference: HC-V110 style). */
function makeCamSticker(): THREE.CanvasTexture {
  const W = 256;
  const H = 128;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d') as CanvasRenderingContext2D;

  // near-black brushed plate (the reference body is glossy black)
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#1b1d21');
  g.addColorStop(0.5, '#15171a');
  g.addColorStop(1, '#191b1f');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 240; i++) {
    ctx.fillStyle = `rgba(${150 + Math.random() * 70},${150 + Math.random() * 70},${160 + Math.random() * 70},0.035)`;
    ctx.fillRect(Math.random() * W, Math.random() * H, 10 + Math.random() * 34, 1);
  }

  // "Panasonic" wordmark - white, slightly italic, wide
  ctx.fillStyle = '#e8eaee';
  ctx.font = 'italic bold 31px Arial, Helvetica, sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText('Panasonic', 12, 47);

  // FULL HD badge (thin rounded outline, right of the wordmark)
  ctx.strokeStyle = '#dfe2e7';
  ctx.lineWidth = 2;
  ctx.strokeRect(170, 22, 66, 22);
  ctx.fillStyle = '#dfe2e7';
  ctx.font = 'bold 14px Arial, sans-serif';
  ctx.fillText('FULL HD', 175, 38);

  // model line under the wordmark
  ctx.fillStyle = '#9aa0a9';
  ctx.font = 'bold 15px Arial, sans-serif';
  ctx.fillText('HC-V110', 14, 72);
  ctx.fillStyle = '#6f757e';
  ctx.font = '9px Arial, sans-serif';
  ctx.fillText('20x OPTICAL ZOOM  ·  LEVEL 0 MOVIE', 14, 88);

  // red lens-dot motif (bottom right, like the reference's red accent)
  ctx.fillStyle = '#b03028';
  ctx.beginPath();
  ctx.arc(228, 92, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#d6d9de';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(228, 92, 10, 0, Math.PI * 2);
  ctx.stroke();

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/**
 * Shared detailed lens assembly for both camcorders. Built pointing +Z at the
 * group origin; mount it on the body and rotate as needed. Multi-stage barrel
 * with knurled focus ring, flared hood, recessed coated glass and a glint.
 */
function buildLensAssembly(): THREE.Group {
  const g = new THREE.Group();
  // rear mount
  const mount = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.048, 0.02, 16), matBox(0x101215));
  mount.rotation.x = Math.PI / 2;
  mount.position.z = 0.01;
  g.add(mount);
  // focus ring with knurling teeth
  const focus = new THREE.Mesh(new THREE.CylinderGeometry(0.054, 0.054, 0.032, 16), matBox(0x1f2226));
  focus.rotation.x = Math.PI / 2;
  focus.position.z = 0.036;
  g.add(focus);
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.01, 0.024), matBox(0x2b2f35));
    tooth.position.set(Math.cos(a) * 0.056, Math.sin(a) * 0.056, 0.036);
    tooth.rotation.z = a;
    g.add(tooth);
  }
  // zoom ring
  const zoom = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.051, 0.026, 16), matBox(0x17191d));
  zoom.rotation.x = Math.PI / 2;
  zoom.position.z = 0.066;
  g.add(zoom);
  // dark hood in front of the silver band
  const hood = new THREE.Mesh(new THREE.CylinderGeometry(0.056, 0.052, 0.02, 16), matBox(0x121417));
  hood.rotation.x = Math.PI / 2;
  hood.position.z = 0.089;
  g.add(hood);
  // WIDE GUNMETAL BEZEL RING around the front glass - dark machined metal so
  // it reads properly under the menu light instead of flat toy-silver
  const bezel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.061, 0.063, 0.022, 20),
    new THREE.MeshStandardMaterial({ color: 0x2b2e30, metalness: 0.7, roughness: 0.35 })
  );
  bezel.rotation.x = Math.PI / 2;
  bezel.position.z = 0.108;
  g.add(bezel);
  // inner step ring between bezel and glass: a shade darker, sinking inward
  const step = new THREE.Mesh(
    new THREE.CylinderGeometry(0.049, 0.057, 0.01, 20),
    new THREE.MeshStandardMaterial({ color: 0x1d2022, metalness: 0.65, roughness: 0.5 })
  );
  step.rotation.x = Math.PI / 2;
  step.position.z = 0.119;
  g.add(step);
  // recessed near-black glass: standard material so direct light glazes a
  // moving specular across it and the disc reads curved, not sticker-flat
  const glass = new THREE.Mesh(
    new THREE.CircleGeometry(0.045, 18),
    new THREE.MeshStandardMaterial({ color: 0x090b0d, metalness: 0.6, roughness: 0.15 })
  );
  glass.position.z = 0.118;
  g.add(glass);
  // coated inner element: faint deep sheen one step in front of the glass
  const element = new THREE.Mesh(
    new THREE.CircleGeometry(0.028, 16),
    new THREE.MeshStandardMaterial({ color: 0x111c22, metalness: 0.5, roughness: 0.25 })
  );
  element.position.set(0, 0, 0.121);
  g.add(element);
  // curved-glass cues: thin ring highlight inside the glass + a tiny offset
  // specular dot (unlit materials so the hint survives the gloomiest corner)
  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(0.036, 0.0016, 6, 24),
    new THREE.MeshBasicMaterial({ color: 0x39464d })
  );
  rim.position.z = 0.1215;
  g.add(rim);
  const glint = new THREE.Mesh(
    new THREE.CircleGeometry(0.006, 8),
    new THREE.MeshBasicMaterial({ color: 0xa9bac1 })
  );
  glint.position.set(0.014, 0.011, 0.122);
  g.add(glint);
  return g;
}

/** Small top control cluster shared by both models (REC button, mic, rocker). */
function buildTopControls(): THREE.Group {
  const g = new THREE.Group();
  // stereo mic block with two holes
  const mic = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.018, 0.034), matBox(0x1f2226));
  g.add(mic);
  for (const hx of [-0.02, 0.02]) {
    const hole = new THREE.Mesh(new THREE.CircleGeometry(0.004, 8), new THREE.MeshBasicMaterial({ color: 0x08090b }));
    hole.rotation.x = -Math.PI / 2;
    hole.position.set(hx, 0.01, 0.004);
    g.add(hole);
  }
  // REC button
  const rec = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.014, 0.034), matBox(0xb03028));
  rec.position.set(0.105, -0.001, 0.05);
  g.add(rec);
  // power slider + notch
  const pwr = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.012, 0.02), matBox(0x2e3237));
  pwr.position.set(-0.02, 0.0, -0.03);
  g.add(pwr);
  const notch = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.013, 0.006), matBox(0xd8c052));
  notch.position.set(-0.035, 0.001, -0.03);
  g.add(notch);
  // zoom rocker
  const rocker = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.01, 0.024), matBox(0x17191d));
  rocker.position.set(0.105, 0.002, -0.03);
  g.add(rocker);
  return g;
}

/**
 * Flip-out LCD mount shared by both camcorders. The panel is hinged on the
 * LEFT SIDE of the body (screen against the flank when closed) and rotates
 * about a vertical hinge. `openY/openX` aim the screen face at the viewer.
 * Built around local +Z = the screen face.
 */
function buildFlipOutLcd(feedTex: THREE.Texture): {
  pivot: THREE.Group;
  screen: THREE.Mesh;
  recDot: THREE.Mesh;
} {
  const pivot = new THREE.Group();
  pivot.rotation.order = 'YXZ';
  const bezel = new THREE.Mesh(new THREE.BoxGeometry(0.145, 0.108, 0.012), matBox(0x191b1e));
  pivot.add(bezel);
  // backlight bleed so the bezel edge catches a little of the glow
  const bleed = new THREE.Mesh(
    new THREE.PlaneGeometry(0.16, 0.12),
    new THREE.MeshBasicMaterial({
      color: 0xfff0c8,
      transparent: true,
      opacity: 0.22,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  bleed.position.z = 0.005;
  pivot.add(bleed);
  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.128, 0.088),
    new THREE.MeshBasicMaterial({ map: feedTex })
  );
  (screen.material as THREE.MeshBasicMaterial).color.setScalar(1.75); // LCD backlight pop
  screen.position.z = 0.0075;
  screen.name = 'lcdScreen';
  pivot.add(screen);
  const recDot = new THREE.Mesh(
    new THREE.PlaneGeometry(0.012, 0.012),
    new THREE.MeshBasicMaterial({ color: 0xff2a22 })
  );
  recDot.position.set(0.056, -0.042, 0.0075);
  recDot.name = 'recDot';
  pivot.add(recDot);
  return { pivot, screen, recDot };
}

/** Hinge barrel detail for the flip-out LCD (vertical axis on the left flank). */
function buildLcdHinge(len: number): THREE.Mesh {
  const hinge = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, len, 10), matBox(0x15171a));
  hinge.rotation.z = Math.PI / 2;
  return hinge;
}

/** Viewmodel flip-out LCD poses: closed against the left flank -> swung up at the eye. */
export const LCD_CLOSED = { x: 0, y: Math.PI / 2 };
/** Open pose aims the panel straight at the operator's head (Outlast takeover). */
export const LCD_OPEN = { x: -0.58, y: -0.72 };

/**
 * 1996 prosumer camcorder for the title screen (HC-V110 look): glossy black
 * body with grip, deck controls, big gunmetal-ringed lens, pull-out viewfinder
 * with rubber eyecup, strap lugs, battery pack, brand sticker and a flip-out
 * LCD on the SIDE of the body (hinged left flank), swung open and tilted to
 * face the viewer with a live render-to-texture feed of the maze.
 */
export function buildCamcorder(feedTex: THREE.Texture): {
  group: THREE.Group;
  recLed: THREE.Mesh;
  recDot: THREE.Mesh;
} {
  const g = new THREE.Group();
  const shell = 0x1b1d21;
  const shell2 = 0x24272c;

  // main body + deck + panel line
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.125, 0.16), matBox(shell));
  body.position.y = 0.075;
  g.add(body);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.024, 0.16), matBox(shell2));
  deck.position.y = 0.149;
  g.add(deck);
  const line = new THREE.Mesh(new THREE.BoxGeometry(0.362, 0.005, 0.162), matBox(0x0e0f11));
  line.position.y = 0.139;
  g.add(line);

  // right-hand grip (rounded from stacked slabs)
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.11, 0.1), matBox(shell2));
  grip.position.set(0.125, 0.08, 0.01);
  g.add(grip);
  const gripCap = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.02, 0.09), matBox(shell2));
  gripCap.position.set(0.123, 0.143, 0.01);
  g.add(gripCap);
  const gripSlope = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.03, 0.04), matBox(shell2));
  gripSlope.position.set(0.125, 0.135, 0.055);
  g.add(gripSlope);

  // big gunmetal-ringed lens assembly pointing +Z, scaled up like the reference
  const lens = buildLensAssembly();
  lens.position.set(-0.1, 0.095, 0.05);
  lens.scale.setScalar(1.22);
  g.add(lens);

  // viewfinder block + eyecup + eyepiece
  const vf = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.07), matBox(0x1c1f22));
  vf.position.set(0.06, 0.19, -0.02);
  g.add(vf);
  const eyecup = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.03, 0.022, 12), matBox(0x141619));
  eyecup.rotation.x = Math.PI / 2;
  eyecup.position.set(0.06, 0.19, -0.066);
  g.add(eyecup);
  const eyepiece = new THREE.Mesh(new THREE.CircleGeometry(0.02, 12), new THREE.MeshBasicMaterial({ color: 0x0a0c0e }));
  eyepiece.rotation.y = Math.PI;
  eyepiece.position.set(0.06, 0.19, -0.077);
  g.add(eyepiece);

  // top controls
  const top = buildTopControls();
  top.position.set(0, 0.161, 0);
  g.add(top);

  // REC led (blinks)
  const recLed = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.012, 0.02),
    new THREE.MeshBasicMaterial({ color: 0xff2a22 })
  );
  recLed.position.set(-0.155, 0.16, 0.02);
  g.add(recLed);

  // tape door seam + latch (right side)
  const tapeLine = new THREE.Mesh(new THREE.BoxGeometry(0.002, 0.085, 0.11), matBox(0x15171a));
  tapeLine.position.set(0.1805, 0.075, 0.01);
  g.add(tapeLine);
  const latch = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.03, 0.03), matBox(0x0f1113));
  latch.position.set(0.185, 0.09, 0.06);
  g.add(latch);

  // brand sticker on the front face (hero 3/4 menu view shows front + left
  // flank, like the reference photo) + one on the back for the intro fall view
  const sticker = new THREE.Mesh(
    new THREE.PlaneGeometry(0.15, 0.075),
    new THREE.MeshLambertMaterial({ map: makeCamSticker() })
  );
  sticker.rotation.y = Math.PI;
  sticker.position.set(0.07, 0.062, -0.0805);
  g.add(sticker);
  const stickerF = new THREE.Mesh(
    new THREE.PlaneGeometry(0.14, 0.07),
    new THREE.MeshLambertMaterial({ map: makeCamSticker() })
  );
  stickerF.position.set(0.1, 0.058, 0.0805);
  g.add(stickerF);

  // strap lugs
  for (const lx of [-0.175, 0.175]) {
    const lug = new THREE.Mesh(new THREE.TorusGeometry(0.012, 0.004, 6, 10), matBox(0x3a3e45));
    lug.rotation.y = Math.PI / 2;
    lug.position.set(lx, 0.115, -0.05);
    g.add(lug);
  }

  // battery pack under the back + contacts
  const battery = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.035, 0.1), matBox(0x1d2024));
  battery.position.set(0.03, 0.0175, -0.06);
  g.add(battery);
  for (const cx of [-0.01, 0.02]) {
    const contact = new THREE.Mesh(new THREE.CircleGeometry(0.007, 8), new THREE.MeshBasicMaterial({ color: 0x8a8570 }));
    contact.rotation.y = Math.PI;
    contact.position.set(cx, 0.02, -0.111);
    g.add(contact);
  }

  // flip-out LCD on the left SIDE of the body: hinged vertically, swung out
  // and twisted so the screen face looks back over its shoulder at the menu
  // camera (which frames the body front-left, lens in shot, reference style)
  const lcdHinge = buildLcdHinge(0.13);
  lcdHinge.position.set(-0.183, 0.1, 0.005);
  g.add(lcdHinge);
  const lcd = buildFlipOutLcd(feedTex);
  lcd.pivot.position.set(-0.183, 0.1, 0.005);
  lcd.pivot.rotation.set(-0.16, -1.12, 0); // menu pose: open toward the viewer
  g.add(lcd.pivot);

  return { group: g, recLed, recDot: lcd.recDot };
}

/**
 * First-person viewmodel camcorder (HC-V110 look), built in CAMERA space: lens
 * points forward (-Z), grip on the right (+X) for the right hand. Glossy black
 * body, big gunmetal-ringed lens, brand sticker on the top deck. The side-mounted
 * flip-out LCD starts CLOSED against the left flank; when the camcorder is
 * raised the game swings it straight at the operator's eye via `lcdPivot`
 * (Outlast style) while the whole unit glides toward the head - at full raise
 * the prop is hidden and the tape takes over the view.
 */
export function buildViewCamcorder(feedTex: THREE.Texture): {
  group: THREE.Group;
  recLed: THREE.Mesh;
  lcdPivot: THREE.Group;
} {
  const g = new THREE.Group();
  const shell = 0x1b1d21;
  const shell2 = 0x24272c;

  // main body + deck + panel line
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.115, 0.15), matBox(shell));
  body.position.set(0, 0.06, 0);
  g.add(body);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.022, 0.15), matBox(shell2));
  deck.position.set(0, 0.128, 0);
  g.add(deck);
  const line = new THREE.Mesh(new THREE.BoxGeometry(0.302, 0.005, 0.152), matBox(0x0e0f11));
  line.position.set(0, 0.119, 0);
  g.add(line);

  // right-hand grip (the hand wraps this - anchor stays at x 0.125)
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.115, 0.09), matBox(shell2));
  grip.position.set(0.125, -0.025, 0.02);
  g.add(grip);
  const gripCap = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.02, 0.08), matBox(shell2));
  gripCap.position.set(0.123, 0.038, 0.02);
  g.add(gripCap);

  // lens assembly pointing -Z
  const lens = buildLensAssembly();
  lens.rotation.y = Math.PI;
  lens.position.set(-0.085, 0.07, -0.06);
  g.add(lens);

  // viewfinder block + eyecup + eyepiece (toward the face, +Z)
  const vf = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.06), matBox(0x1c1f22));
  vf.position.set(0.04, 0.15, 0.055);
  g.add(vf);
  const eyecup = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.028, 0.02, 12), matBox(0x141619));
  eyecup.rotation.x = Math.PI / 2;
  eyecup.position.set(0.04, 0.152, 0.092);
  g.add(eyecup);
  const eyepiece = new THREE.Mesh(new THREE.CircleGeometry(0.019, 12), new THREE.MeshBasicMaterial({ color: 0x0a0c0e }));
  eyepiece.position.set(0.04, 0.152, 0.103);
  g.add(eyepiece);

  // top controls
  const top = buildTopControls();
  top.position.set(0, 0.139, 0);
  g.add(top);

  // REC led + tape door detail
  const recLed = new THREE.Mesh(
    new THREE.BoxGeometry(0.018, 0.011, 0.018),
    new THREE.MeshBasicMaterial({ color: 0xff2a22 })
  );
  recLed.position.set(-0.125, 0.14, 0.02);
  g.add(recLed);
  const tapeLine = new THREE.Mesh(new THREE.BoxGeometry(0.002, 0.07, 0.1), matBox(0x15171a));
  tapeLine.position.set(0.1505, 0.06, 0.005);
  g.add(tapeLine);
  const latch = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.026, 0.026), matBox(0x0f1113));
  latch.position.set(0.155, 0.075, 0.05);
  g.add(latch);

  // brand sticker on the top deck (reads when the camera is lowered)
  const sticker = new THREE.Mesh(
    new THREE.PlaneGeometry(0.11, 0.055),
    new THREE.MeshLambertMaterial({ map: makeCamSticker() })
  );
  sticker.rotation.x = -Math.PI / 2;
  sticker.position.set(0.02, 0.1395, 0.01);
  g.add(sticker);

  // flip-out LCD: hinged on the left flank, CLOSED against the body. The game
  // animates lcdPivot between LCD_CLOSED and LCD_OPEN (the panel ends up swung
  // straight at the operator's head, showing the live feed) while the unit
  // glides to the eye - then the prop is hidden and the tape takes over.
  const lcdHinge = buildLcdHinge(0.1);
  lcdHinge.position.set(-0.153, 0.06, 0.005);
  g.add(lcdHinge);
  const lcd = buildFlipOutLcd(feedTex);
  lcd.pivot.position.set(-0.153, 0.06, 0.005);
  lcd.pivot.rotation.set(LCD_CLOSED.x, LCD_CLOSED.y, 0);
  g.add(lcd.pivot);

  // back vents
  for (let i = 0; i < 3; i++) {
    const vent = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.012, 0.002), matBox(0x15171a));
    vent.position.set(-0.06, 0.03 + i * 0.02, 0.0755);
    g.add(vent);
  }

  // strap lugs
  for (const lx of [-0.145, 0.145]) {
    const lug = new THREE.Mesh(new THREE.TorusGeometry(0.011, 0.004, 6, 10), matBox(0x3a3e45));
    lug.rotation.y = Math.PI / 2;
    lug.position.set(lx, 0.11, 0.065);
    g.add(lug);
  }

  // battery pack + contacts (under the back)
  const battery = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.032, 0.09), matBox(0x1d2024));
  battery.position.set(0.02, 0.016, 0.055);
  g.add(battery);
  for (const cx of [-0.02, 0.01]) {
    const contact = new THREE.Mesh(new THREE.CircleGeometry(0.006, 8), new THREE.MeshBasicMaterial({ color: 0x8a8570 }));
    contact.position.set(cx, 0.018, 0.1005);
    g.add(contact);
  }

  return { group: g, recLed, lcdPivot: lcd.pivot };
}

/**
 * Gloved right hand gripping a vertical handle centered at the group origin
 * (palm on +X, fingers wrapping across to -X, forearm running down-right).
 */
export function buildHand(): THREE.Group {
  const g = new THREE.Group();
  const glove = 0x33363b;
  const glove2 = 0x2a2d32;

  // palm pressed against the grip's right face
  const palm = box(0.032, 0.08, 0.095, glove);
  palm.position.set(0.042, 0.0, 0.0);
  g.add(palm);
  // four fingers wrapping across the grip toward -X
  for (let i = 0; i < 4; i++) {
    const f = box(0.082, 0.017, 0.021, i % 2 ? glove2 : glove);
    f.position.set(-0.004, 0.03 - i * 0.021, 0.0);
    f.rotation.z = 0.04;
    g.add(f);
    // knuckle ridge
    const k = box(0.02, 0.017, 0.023, glove2);
    k.position.set(-0.042, 0.03 - i * 0.021, 0.0);
    g.add(k);
  }
  // thumb hooking the near side (+Z)
  const thumb = box(0.024, 0.05, 0.02, glove);
  thumb.position.set(0.012, -0.01, 0.05);
  thumb.rotation.x = 0.55;
  thumb.rotation.z = -0.3;
  g.add(thumb);
  // wrist + cuff
  const wrist = box(0.05, 0.06, 0.07, glove2);
  wrist.position.set(0.075, -0.03, 0.005);
  wrist.rotation.z = -0.35;
  g.add(wrist);
  // forearm heading down-right off screen
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.05, 0.34, 10), matBox(0x24262b));
  arm.position.set(0.17, -0.16, 0.02);
  arm.rotation.z = -0.95;
  arm.rotation.x = 0.12;
  g.add(arm);
  const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.052, 0.045, 10), matBox(0x1d1f23));
  cuff.position.set(0.115, -0.075, 0.02);
  cuff.rotation.z = -0.95;
  cuff.rotation.x = 0.12;
  g.add(cuff);

  return g;
}

export function buildRadio(): THREE.Group {
  const g = new THREE.Group();
  const body = box(0.34, 0.2, 0.12, 0x2e2b26);
  body.position.y = 0.1;
  g.add(body);
  const dial = box(0.14, 0.1, 0.01, 0xc9b98a, 0x6b5a2e);
  dial.position.set(-0.05, 0.12, -0.065);
  g.add(dial);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.4, 6), matBox(0x8a8a8a));
  antenna.position.set(0.13, 0.32, 0);
  antenna.rotation.z = -0.4;
  g.add(antenna);
  return g;
}

/** The stairwell exit door: textured steel slab in a recessed frame, push bar,
 *  hinges, closer, EXIT sign + status lamp (red -> green). Faces -Z. */
export function buildStairwellDoor(
  signTex: THREE.Texture,
  doorTex: TextureSet
): { group: THREE.Group; lamp: THREE.Mesh; sign: THREE.Mesh } {
  const g = new THREE.Group();

  const steel = (c: number): THREE.MeshLambertMaterial => matBox(c);

  // recessed frame: jambs + header + threshold
  const jambL = box(0.18, 2.5, 0.16, 0x3a3f42);
  jambL.position.set(-0.66, 1.25, -0.02);
  g.add(jambL);
  const jambR = box(0.18, 2.5, 0.16, 0x3a3f42);
  jambR.position.set(0.66, 1.25, -0.02);
  g.add(jambR);
  const header = box(1.5, 0.16, 0.16, 0x3a3f42);
  header.position.set(0, 2.42, -0.02);
  g.add(header);
  const threshold = box(1.32, 0.03, 0.2, 0x2c3032);
  threshold.position.set(0, 0.015, -0.04);
  g.add(threshold);

  // the slab: door texture on the visible (-Z) face, plain paint elsewhere
  const slabSide = steel(0x4a5155);
  const slabMats = [slabSide, slabSide, slabSide, slabSide, slabSide, new THREE.MeshLambertMaterial({ map: doorTex.map, bumpMap: doorTex.bump, bumpScale: 0.35 })];
  const slab = new THREE.Mesh(new THREE.BoxGeometry(1.14, 2.2, 0.1), slabMats);
  slab.position.set(0, 1.1, -0.07);
  g.add(slab);

  // kick plate (stainless) + push bar with brackets
  const kick = box(1.06, 0.28, 0.02, 0x8f9599);
  kick.position.set(0, 0.2, -0.13);
  g.add(kick);
  const bar = box(0.72, 0.075, 0.06, 0x24282a);
  bar.position.set(0, 1.05, -0.155);
  g.add(bar);
  for (const bx of [-0.3, 0.3]) {
    const br = box(0.05, 0.14, 0.05, 0x24282a);
    br.position.set(bx, 1.05, -0.125);
    g.add(br);
  }

  // hinges on the left edge + overhead closer
  for (const hy of [0.35, 1.1, 1.85]) {
    const hinge = box(0.05, 0.11, 0.035, 0x75797c);
    hinge.position.set(-0.56, hy, -0.125);
    g.add(hinge);
  }
  const closer = box(0.26, 0.09, 0.09, 0x565c60);
  closer.position.set(0.3, 2.28, -0.16);
  g.add(closer);
  const arm = box(0.24, 0.03, 0.03, 0x565c60);
  arm.position.set(0.06, 2.22, -0.16);
  arm.rotation.z = 0.5;
  g.add(arm);

  // conduit running from the header up to the ceiling
  const conduit = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.55, 6), matBox(0x3a3f42));
  conduit.position.set(0.62, 2.78, -0.02);
  g.add(conduit);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(0.9, 0.45),
    new THREE.MeshBasicMaterial({ map: signTex, transparent: false })
  );
  sign.position.set(0, 2.72, -0.08);
  g.add(sign);
  const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), new THREE.MeshBasicMaterial({ color: 0x991c14 }));
  lamp.position.set(0.62, 2.4, -0.1);
  g.add(lamp);
  return { group: g, lamp, sign };
}

/** The party door: chipped cream paint over wood, red frame, bunting on a
 *  sagging string, a row of dim string-light bulbs. Faces -Z. */
export function buildPartyDoor(
  signTex: THREE.Texture,
  doorTex: TextureSet
): { group: THREE.Group; door: THREE.Mesh } {
  const g = new THREE.Group();

  // red-painted frame with trim
  const jambL = box(0.17, 2.5, 0.14, 0xb0413a);
  jambL.position.set(-0.665, 1.25, -0.02);
  g.add(jambL);
  const jambR = box(0.17, 2.5, 0.14, 0xb0413a);
  jambR.position.set(0.665, 1.25, -0.02);
  g.add(jambR);
  const header = box(1.5, 0.15, 0.14, 0xb0413a);
  header.position.set(0, 2.425, -0.02);
  g.add(header);
  const trim = box(1.5, 0.05, 0.05, 0x8f322c);
  trim.position.set(0, 2.32, -0.06);
  g.add(trim);

  // slab: party texture on the visible (-Z) face
  const sideMat = matBox(0xd8c052);
  const slabMats = [sideMat, sideMat, sideMat, sideMat, sideMat, new THREE.MeshLambertMaterial({ map: doorTex.map, bumpMap: doorTex.bump, bumpScale: 0.4 })];
  const door = new THREE.Mesh(new THREE.BoxGeometry(1.16, 2.24, 0.1), slabMats);
  door.position.set(0, 1.14, -0.06);
  g.add(door);

  // brass knob + escutcheon
  const esc = box(0.07, 0.2, 0.015, 0xa8893c);
  esc.position.set(0.42, 1.1, -0.118);
  g.add(esc);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), matBox(0xc9a94f));
  knob.position.set(0.42, 1.1, -0.135);
  g.add(knob);

  // hinges on the left edge
  for (const hy of [0.36, 1.12, 1.88]) {
    const hinge = box(0.06, 0.1, 0.03, 0xa8893c);
    hinge.position.set(-0.57, hy, -0.12);
    g.add(hinge);
  }

  // bunting on a sagging string
  const string = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 1.3, 4), matBox(0x555044));
  string.rotation.z = Math.PI / 2;
  string.rotation.y = Math.PI / 2;
  string.position.set(0, 2.28, -0.12);
  g.add(string);
  for (let i = 0; i < 7; i++) {
    const flag = box(0.09, 0.12, 0.01, [0xc8574d, 0xd8c052, 0x6f9e7c][i % 3]);
    flag.position.set(-0.6 + i * 0.2, 2.2 - Math.abs(i - 3) * 0.05, -0.12);
    g.add(flag);
  }

  // string lights: dim colored bulbs along the header
  const bulbCols = [0xc8574d, 0xd8c052, 0x6f9e7c, 0x8a6a9c];
  for (let i = 0; i < 8; i++) {
    const bulb = new THREE.Mesh(
      new THREE.SphereGeometry(0.022, 6, 6),
      new THREE.MeshBasicMaterial({ color: bulbCols[i % 4] })
    );
    bulb.position.set(-0.6 + i * 0.17, 2.5 + Math.sin(i * 1.4) * 0.03, -0.1);
    g.add(bulb);
  }

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(0.9, 0.45),
    new THREE.MeshBasicMaterial({ map: signTex })
  );
  sign.position.set(0, 2.74, -0.08);
  g.add(sign);
  return { group: g, door };
}

export function buildBalloons(): THREE.Group {
  const g = new THREE.Group();
  const colors = [0xa33c36, 0xc7b04a, 0x5d7f6a, 0x8a6a9c, 0xb87f3f];
  for (let i = 0; i < 5; i++) {
    const b = new THREE.Mesh(
      new THREE.SphereGeometry(0.16, 10, 8),
      new THREE.MeshLambertMaterial({ color: colors[i], emissive: colors[i], emissiveIntensity: 0.12 })
    );
    b.scale.y = 1.18;
    b.position.set((i - 2) * 0.28 + Math.sin(i * 7) * 0.06, 2.2 + Math.sin(i * 3) * 0.12, Math.cos(i * 5) * 0.1);
    g.add(b);
    const str = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 1.4, 4), matBox(0x555044));
    str.position.set(b.position.x, b.position.y - 0.85, b.position.z);
    g.add(str);
  }
  return g;
}

/** Sign plane mounted on a free-standing pole (used in the hub). */
export function buildSignpost(tex: THREE.Texture, rotY: number): THREE.Group {
  const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 2.4, 8), matBox(0x4a4238));
  pole.position.y = 1.2;
  g.add(pole);
  const plane = new THREE.Mesh(
    new THREE.PlaneGeometry(1.5, 0.75),
    new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide })
  );
  plane.position.y = 2.15;
  plane.rotation.y = rotY;
  g.add(plane);
  const base = box(0.5, 0.08, 0.5, 0x3a352c);
  base.position.y = 0.04;
  g.add(base);
  return g;
}

export function buildWallSign(tex: THREE.Texture, w = 2.2, h = 1.1): THREE.Mesh {
  // transparent: the scrawl canvases have no background - paint floats on the wall
  return new THREE.Mesh(
    new THREE.PlaneGeometry(w, h),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true })
  );
}

export function buildPuddle(radius: number): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.CircleGeometry(radius, 18),
    new THREE.MeshBasicMaterial({ color: 0x0b0904, transparent: true, opacity: 0.5 })
  );
  m.rotation.x = -Math.PI / 2;
  return m;
}

/** Ceiling pipes for wet / electrical rooms. */
export function buildPipes(length: number): THREE.Group {
  const g = new THREE.Group();
  for (const [dz, r, col] of [[-0.22, 0.09, 0x46403a], [0.1, 0.06, 0x3a4044]] as [number, number, number][]) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(r, r, length, 8), matBox(col));
    p.rotation.z = Math.PI / 2;
    p.position.set(0, 2.82, dz);
    g.add(p);
  }
  return g;
}

export function buildTable(): { group: THREE.Group; collider: { w: number; d: number } } {
  const g = new THREE.Group();
  const top = box(0.9, 0.06, 0.9, 0x77664a);
  top.position.y = 0.72;
  g.add(top);
  const leg = box(0.1, 0.72, 0.1, 0x453b2c);
  leg.position.y = 0.36;
  g.add(leg);
  return { group: g, collider: { w: 0.9, d: 0.9 } };
}

// ---------------- The Hub ----------------

/**
 * The breach in the wallpaper: a torn hole with jagged plasterboard edges,
 * rusty rebar teeth, exposed lath and a debris skirt. The mouth sits at local
 * +Z ~0.5 and the void recedes toward local z=0 - mount it with rotation.y =
 * -PI/2 so the mouth lands flush on a wall's west face and the void sinks in.
 */
export function buildBreach(): { group: THREE.Group; hole: THREE.Mesh } {
  const g = new THREE.Group();
  const rand = Math.random;

  // the void itself (thin: it must hide inside the wall thickness)
  const hole = new THREE.Mesh(
    new THREE.BoxGeometry(1.05, 1.5, 0.3),
    new THREE.MeshBasicMaterial({ color: 0x050403 })
  );
  hole.position.set(0, 0.92, 0.365);
  g.add(hole);

  // exposed lath slats top + bottom of the recess
  for (let i = 0; i < 4; i++) {
    const slat = box(1.0, 0.045, 0.02, 0x6a5a40);
    slat.position.set(0, 0.28 + i * 0.055, 0.515);
    slat.rotation.z = (rand() - 0.5) * 0.2;
    g.add(slat);
    const slat2 = slat.clone();
    slat2.position.y = 1.5 + i * 0.055;
    g.add(slat2);
  }

  // jagged plaster rim: chunks around the opening
  const chunkCol = [0xb8ac6a, 0xa89c5e, 0xc4b878, 0x8f8552];
  const rim = (cx: number, cy: number, n: number, spread: number): void => {
    for (let i = 0; i < n; i++) {
      const w = 0.08 + rand() * 0.16;
      const h = 0.05 + rand() * 0.12;
      const ck = box(w, h, 0.05 + rand() * 0.06, chunkCol[Math.floor(rand() * chunkCol.length)]);
      ck.position.set(cx + (rand() - 0.5) * spread, cy + (rand() - 0.5) * 0.09, 0.5 - rand() * 0.04);
      ck.rotation.set((rand() - 0.5) * 0.8, (rand() - 0.5) * 0.6, (rand() - 0.5) * 0.9);
      g.add(ck);
    }
  };
  rim(-0.55, 0.95, 7, 0.22); // left edge
  rim(0.55, 0.95, 7, 0.22); // right edge
  rim(0, 1.68, 8, 1.0); // top edge
  rim(0, 0.2, 6, 0.9); // bottom lip

  // rebar teeth: rusty rods bent out of the hole
  for (let i = 0; i < 5; i++) {
    const len = 0.16 + rand() * 0.3;
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, len, 5), matBox(0x5c3626));
    rod.position.set(-0.4 + i * 0.2 + (rand() - 0.5) * 0.1, 1.3 + (rand() - 0.5) * 0.5, 0.52);
    rod.rotation.set(1.35 + (rand() - 0.5) * 0.5, rand() * Math.PI, (rand() - 0.5) * 1.4);
    g.add(rod);
  }

  // debris skirt on the floor
  for (let i = 0; i < 14; i++) {
    const s = 0.06 + rand() * 0.16;
    const ck = box(s, s * (0.3 + rand() * 0.5), s * (0.6 + rand() * 0.6), chunkCol[Math.floor(rand() * chunkCol.length)]);
    const a = rand() * Math.PI * 2;
    const r = 0.3 + rand() * 0.75;
    ck.position.set(Math.cos(a) * r * 0.9, s * 0.18, 0.45 + Math.abs(Math.sin(a)) * r * 0.8);
    ck.rotation.set(rand(), rand(), rand());
    g.add(ck);
  }
  return { group: g, hole };
}

/** Rubble choke: a collapsed tunnel stub (boxes of concrete + rebar). */
export function buildRubblePile(): THREE.Group {
  const g = new THREE.Group();
  const cols = [0x6f6b60, 0x7a766b, 0x5e5a52, 0x837f72];
  for (let i = 0; i < 22; i++) {
    const s = 0.12 + Math.random() * 0.3;
    const ck = box(s, s * (0.5 + Math.random() * 0.6), s * (0.7 + Math.random() * 0.7), cols[Math.floor(Math.random() * cols.length)]);
    ck.position.set((Math.random() - 0.5) * 2.0, s * 0.3 + Math.random() * 0.55, (Math.random() - 0.5) * 0.9);
    ck.rotation.set(Math.random() * 0.7, Math.random() * Math.PI, Math.random() * 0.7);
    g.add(ck);
  }
  for (let i = 0; i < 4; i++) {
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, 0.5 + Math.random() * 0.5, 5), matBox(0x5c3626));
    rod.position.set((Math.random() - 0.5) * 1.4, 0.5 + Math.random() * 0.5, (Math.random() - 0.5) * 0.5);
    rod.rotation.set(Math.PI / 2 + (Math.random() - 0.5) * 0.7, Math.random() * Math.PI, Math.random());
    g.add(rod);
  }
  return g;
}

/** Caged incandescent bulb on a short drop rod. Returns the emissive bulb mesh. */
export function buildCagedLamp(): { group: THREE.Group; bulb: THREE.Mesh } {
  const g = new THREE.Group();
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.3, 6), matBox(0x2e2c28));
  rod.position.y = -0.15;
  g.add(rod);
  const bulb = new THREE.Mesh(
    new THREE.SphereGeometry(0.075, 10, 8),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0 })
  );
  bulb.position.y = -0.36;
  g.add(bulb);
  const ring1 = new THREE.Mesh(new THREE.TorusGeometry(0.105, 0.008, 6, 14), matBox(0x3a3833));
  ring1.position.y = -0.36;
  ring1.rotation.x = Math.PI / 2;
  g.add(ring1);
  const ring2 = new THREE.Mesh(new THREE.TorusGeometry(0.105, 0.008, 6, 14), matBox(0x3a3833));
  // second ring tilted as the cage cross
  ring2.position.y = -0.36;
  ring2.rotation.set(0, Math.PI / 2, Math.PI / 2);
  g.add(ring2);
  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.065, 0.05, 8), matBox(0x3a3833));
  collar.position.y = -0.29;
  g.add(collar);
  return { group: g, bulb };
}

/** M.E.G. outpost flag: dark cloth plane with the stencil, on a lean pole. */
export function buildMEGFlag(tex: THREE.Texture): THREE.Group {
  const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 2.9, 8), matBox(0x4a4238));
  pole.position.y = 1.45;
  pole.rotation.z = 0.06;
  g.add(pole);
  const cloth = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 0.58),
    new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide })
  );
  cloth.position.set(0.62, 2.5, 0);
  cloth.rotation.y = 0.12;
  g.add(cloth);
  return g;
}

/**
 * Freight lift at the end of the Hub tunnel: steel frame with hazard stripes,
 * a half-open bar cage, warm interior light, call button and arrival lamp.
 * Faces -Z (front toward the approaching player).
 */
export function buildElevator(
  signTex: THREE.Texture,
  hazardTex: THREE.Texture
): { group: THREE.Group; button: THREE.Mesh; lampGreen: THREE.Mesh; cabinGlow: THREE.Mesh } {
  const g = new THREE.Group();

  // frame: jambs + header, brushed steel
  const jambL = box(0.24, 2.7, 0.3, 0x43484c);
  jambL.position.set(-1.05, 1.35, 0);
  g.add(jambL);
  const jambR = jambL.clone();
  jambR.position.x = 1.05;
  g.add(jambR);
  const header = box(2.34, 0.5, 0.3, 0x43484c);
  header.position.set(0, 2.85, 0);
  g.add(header);

  // hazard stripe plates on both jambs
  for (const sx of [-1.05, 1.05]) {
    const hz = new THREE.Mesh(
      new THREE.PlaneGeometry(0.24, 2.2),
      new THREE.MeshLambertMaterial({ map: hazardTex })
    );
    hz.position.set(sx, 1.1, -0.16);
    g.add(hz);
  }
  // hazard strip along the floor lip
  const lip = new THREE.Mesh(
    new THREE.PlaneGeometry(1.86, 0.3),
    new THREE.MeshLambertMaterial({ map: hazardTex })
  );
  lip.rotation.x = -Math.PI / 2;
  lip.position.set(0, 0.012, -0.32);
  g.add(lip);

  // shaft interior: dark, with a warm ceiling glow
  const shaft = box(2.0, 3.0, 1.6, 0x23252a);
  shaft.position.set(0, 1.5, 0.95);
  g.add(shaft);
  const cabinGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.5),
    new THREE.MeshBasicMaterial({ color: 0xffe9c0 })
  );
  cabinGlow.position.set(0, 2.62, 0.9);
  cabinGlow.rotation.x = Math.PI / 2;
  g.add(cabinGlow);

  // bar cage, half open (left panel closed, right side open)
  for (let i = 0; i < 6; i++) {
    const bar = box(0.035, 2.4, 0.035, 0x565c60);
    bar.position.set(-0.85 + i * 0.16, 1.25, -0.05);
    g.add(bar);
  }
  const crossTop = box(0.9, 0.05, 0.04, 0x565c60);
  crossTop.position.set(-0.45, 2.42, -0.05);
  g.add(crossTop);
  const crossBot = crossTop.clone();
  crossBot.position.y = 0.12;
  g.add(crossBot);
  // folded-open panel pushed to the right jamb
  for (let i = 0; i < 3; i++) {
    const bar = box(0.035, 2.4, 0.035, 0x565c60);
    bar.position.set(0.72 + i * 0.1, 1.25, -0.05);
    g.add(bar);
  }

  // sign + call button + arrival lamp
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.55), new THREE.MeshBasicMaterial({ map: signTex }));
  sign.position.set(0, 3.2, -0.1);
  g.add(sign);
  const btnBox = box(0.16, 0.26, 0.08, 0x2e2f33);
  btnBox.position.set(1.24, 1.25, -0.2);
  g.add(btnBox);
  const button = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), new THREE.MeshBasicMaterial({ color: 0xb32017 }));
  button.position.set(1.24, 1.31, -0.25);
  g.add(button);
  const lampGreen = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), new THREE.MeshBasicMaterial({ color: 0x1c3a1e }));
  lampGreen.position.set(-1.05, 2.52, -0.18);
  g.add(lampGreen);

  return { group: g, button, lampGreen, cabinGlow };
}
