// First-person player: pointer-lock / touch look, WASD motion, circle-vs-AABB
// collision, sprint stamina, head bob, footstep events and noise emission.

import * as THREE from 'three';
import { Level } from './level';
import { CELL, GRID } from './maze';

export interface PlayerInput {
  f: boolean;
  b: boolean;
  l: boolean;
  r: boolean;
  sprint: boolean;
  lookDX: number;
  lookDY: number;
}

export interface PlayerFrame {
  stepped: null | 'walk' | 'sprint';
  moved: boolean;
  sprinting: boolean;
  speed: number;
  stamina: number;
}

const WALK = 3.0;
const SPRINT = 5.15;
const RADIUS = 0.32;
const HEIGHT = 1.62;

export class Player {
  pos = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  stamina = 1;
  exhausted = false;
  private bobPhase = 0; // public-read via getter below (viewmodel sync)
  private lastStepPhase = 0;
  private regenDelay = 0;
  flashlightOn = false;
  flashlight: THREE.SpotLight;
  private flashTarget = new THREE.Object3D();
  input: PlayerInput = { f: false, b: false, l: false, r: false, sprint: false, lookDX: 0, lookDY: 0 };
  /** Mouse look multiplier (1 = tape-found default). Set from the options UI. */
  sens = 1;
  touchMove = { x: 0, y: 0 }; // analog override from virtual joystick
  controlsLocked = false;

  constructor(private camera: THREE.PerspectiveCamera) {
    this.flashlight = new THREE.SpotLight(0xfff2d0, 0, 16, 0.5, 0.55, 1.4);
    this.flashTarget.position.set(0, 0, -1);
    camera.add(this.flashTarget);
    this.flashlight.target = this.flashTarget;
    this.flashlight.position.set(0.12, -0.08, 0.05);
    camera.add(this.flashlight);
  }

  reset(x: number, z: number, yaw: number): void {
    this.pos.set(x, HEIGHT, z);
    this.yaw = yaw;
    this.pitch = 0;
    this.stamina = 1;
    this.exhausted = false;
    this.bobPhase = 0;
    this.lastStepPhase = 0;
  }

  toggleFlashlight(): void {
    this.flashlightOn = !this.flashlightOn;
    this.flashlight.intensity = this.flashlightOn ? 85 : 0;
  }

  /** Head-bob phase for viewmodel sync (read-only). */
  get bob(): number {
    return this.bobPhase;
  }

  look(dx: number, dy: number): void {
    const k = 0.0023 * this.sens;
    this.yaw -= dx * k;
    this.pitch -= dy * k;
    const lim = 1.45;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
  }

  private resolveCollisions(level: Level): void {
    const candidates = level.collidersNear(this.pos.x, this.pos.z);
    for (let iter = 0; iter < 2; iter++) {
      for (const b of candidates) {
        const cx = Math.max(b.minX, Math.min(this.pos.x, b.maxX));
        const cz = Math.max(b.minZ, Math.min(this.pos.z, b.maxZ));
        let dx = this.pos.x - cx;
        let dz = this.pos.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 >= RADIUS * RADIUS) continue;
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2);
          const push = RADIUS - d;
          this.pos.x += (dx / d) * push;
          this.pos.z += (dz / d) * push;
        } else {
          // center inside the box: push out along smallest penetration axis
          const penL = this.pos.x - b.minX + RADIUS;
          const penR = b.maxX - this.pos.x + RADIUS;
          const penT = this.pos.z - b.minZ + RADIUS;
          const penB = b.maxZ - this.pos.z + RADIUS;
          const m = Math.min(penL, penR, penT, penB);
          if (m === penL) this.pos.x = b.minX - RADIUS;
          else if (m === penR) this.pos.x = b.maxX + RADIUS;
          else if (m === penT) this.pos.z = b.minZ - RADIUS;
          else this.pos.z = b.maxZ + RADIUS;
        }
        dx = 0;
        dz = 0;
      }
    }
  }

  update(dt: number, level: Level): PlayerFrame {
    const inp = this.input;
    // consume look
    if (inp.lookDX !== 0 || inp.lookDY !== 0) {
      this.look(inp.lookDX, inp.lookDY);
      inp.lookDX = 0;
      inp.lookDY = 0;
    }

    let mx = 0;
    let mz = 0;
    if (inp.f) mz += 1;
    if (inp.b) mz -= 1;
    if (inp.l) mx -= 1;
    if (inp.r) mx += 1;
    if (this.touchMove.x !== 0 || this.touchMove.y !== 0) {
      mx += this.touchMove.x;
      mz += this.touchMove.y;
    }
    const mlen = Math.hypot(mx, mz);
    if (mlen > 1) {
      mx /= mlen;
      mz /= mlen;
    }

    const wantSprint = inp.sprint && mlen > 0.1 && mz > 0.15 && !this.exhausted;
    const sprinting = wantSprint && this.stamina > 0.02;

    // stamina
    if (sprinting) {
      this.stamina = Math.max(0, this.stamina - dt * 0.155);
      this.regenDelay = 0.9;
      if (this.stamina <= 0.001) this.exhausted = true;
    } else {
      this.regenDelay = Math.max(0, this.regenDelay - dt);
      if (this.regenDelay <= 0) {
        this.stamina = Math.min(1, this.stamina + dt * 0.085);
        if (this.stamina > 0.35) this.exhausted = false;
      }
    }

    const speed = sprinting ? SPRINT : WALK * Math.max(0.35, mlen);
    // camera basis
    const sin = Math.sin(this.yaw);
    const cos = Math.cos(this.yaw);
    // forward = (-sin, -cos) matches three.js -Z forward at yaw 0
    const vx = (-sin * mz + cos * mx) * speed;
    const vz = (-cos * mz - sin * mx) * speed;
    this.pos.x += vx * dt;
    this.pos.z += vz * dt;
    this.resolveCollisions(level);

    // hard map clamp (safety) - Level 0 only; The Hub lives far outside the grid
    const SIZE = CELL * GRID;
    if (this.pos.x < SIZE && this.pos.z < SIZE) {
      this.pos.x = Math.max(0.5, Math.min(SIZE - 0.5, this.pos.x));
      this.pos.z = Math.max(0.5, Math.min(SIZE - 0.5, this.pos.z));
    }

    // head bob + footsteps
    const moved = mlen > 0.1;
    const bobSpeed = sprinting ? 11.5 : 8.6;
    if (moved) this.bobPhase += dt * bobSpeed;
    const bobAmp = sprinting ? 0.052 : 0.032;
    const bobY = Math.sin(this.bobPhase) * bobAmp * (moved ? 1 : 0);
    const bobX = Math.cos(this.bobPhase * 0.5) * bobAmp * 0.6 * (moved ? 1 : 0);

    this.camera.position.set(this.pos.x + bobX * 0.4, this.pos.y + bobY, this.pos.z);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;
    this.camera.rotation.z = Math.sin(this.bobPhase * 0.5) * 0.004 * (moved ? 1 : 0);

    // footstep on each half bob cycle
    const phase = Math.floor(this.bobPhase / Math.PI);
    let stepped: null | 'walk' | 'sprint' = null;
    if (moved && phase !== this.lastStepPhase) {
      stepped = sprinting ? 'sprint' : 'walk';
      this.lastStepPhase = phase;
    }

    return {
      stepped,
      moved,
      sprinting,
      speed,
      stamina: this.stamina,
    };
  }

  /** Current noise radius emitted by movement state (meters). */
  noiseRadius(sprinting: boolean, moved: boolean): number {
    if (!moved) return 0;
    return sprinting ? 16 : 7;
  }
}
