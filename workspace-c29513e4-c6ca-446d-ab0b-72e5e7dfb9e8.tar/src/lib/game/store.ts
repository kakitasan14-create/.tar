// Tiny zustand store bridging the imperative game engine and React UI overlays.

import { create } from 'zustand';
import type { DialogueLine } from './content';

export type Screen = 'menu' | 'intro' | 'playing' | 'paused' | 'death' | 'endingA' | 'endingB' | 'endingC';
export type MenuPanel = 'root' | 'tapes' | 'options' | 'extras';

export interface GameUIState {
  screen: Screen;
  menuPanel: MenuPanel;
  exitToast: string | null;
  vhsLevel: number;
  objective: string;
  objectiveSub: string;
  prompt: string;
  stamina: number;
  exhausted: boolean;
  water: number;
  notes: number;
  notesTotal: number;
  hunted: boolean;
  flashOn: boolean;
  camRaised: boolean; // viewfinder at eye - drives OSD + Smiler visibility
  tracked: boolean; // lens interference: the Smiler is on-camera
  dialogue: DialogueLine | null;
  dialogueDone: boolean;
  noteOpen: { title: string; body: string } | null;
  fade: boolean;
  flashWhite: boolean;
  eyelids: boolean;
  elapsed: number;
  deaths: number;
  muted: boolean;
  sensLevel: number; // 0 slow · 1 normal · 2 fast
  touch: boolean;
  endingStats: { time: number; notes: number; water: number; deaths: number } | null;
  set: (partial: Partial<GameUIState>) => void;
}

export const useGameUI = create<GameUIState>((set) => ({
  screen: 'menu',
  menuPanel: 'root',
  exitToast: null,
  vhsLevel: 1,
  objective: 'FIND A WAY OUT',
  objectiveSub: 'collect pages - listen for the radio',
  prompt: '',
  stamina: 1,
  exhausted: false,
  water: 0,
  notes: 0,
  notesTotal: 11,
  hunted: false,
  flashOn: false,
  camRaised: true,
  tracked: false,
  dialogue: null,
  dialogueDone: false,
  noteOpen: null,
  fade: false,
  flashWhite: false,
  eyelids: false,
  elapsed: 0,
  deaths: 0,
  muted: false,
  sensLevel: 1,
  touch: false,
  endingStats: null,
  set: (partial) => set(partial),
}));
