// The Hub: a hand-authored concrete tunnel network far outside the Level 0
// maze (offset ~300m). Lore-faithful: poured concrete, caged bulbs, pipes, an
// abandoned M.E.G. outpost, a flooded pump gallery feeding a machine room
// (the lift's power is siphoned by the pump rig - shut it down), a survivor
// camp on the south line and a freight lift at the end of the tunnel. The
// Smiler cannot follow in here.

import * as THREE from 'three';
import type { GameTextures } from './textures';
import type { Interactable } from './level';
import * as P from './props';

const HUB_U = 2.2; // meters per concrete tile

interface GeoArrays {
  pos: number[];
  norm: number[];
  uv: number[];
  idx: number[];
}

function addFace(g: GeoArrays, verts: number[][], normal: number[], uvs: number[][]): void {
  const base = g.pos.length / 3;
  for (const v of verts) g.pos.push(v[0], v[1], v[2]);
  for (let i = 0; i < 4; i++) g.norm.push(normal[0], normal[1], normal[2]);
  for (const uv of uvs) g.uv.push(uv[0], uv[1]);
  g.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
}

function addBoxGeo(g: GeoArrays, cx: number, cy: number, cz: number, w: number, h: number, d: number): void {
  const x0 = cx - w / 2, x1 = cx + w / 2;
  const y0 = cy - h / 2, y1 = cy + h / 2;
  const z0 = cz - d / 2, z1 = cz + d / 2;
  const uw = w / HUB_U;
  const ud = d / HUB_U;
  const uh = h / HUB_U;
  addFace(g, [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], [0, 0, 1], [[0, 0], [uw, 0], [uw, uh], [0, uh]]);
  addFace(g, [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], [0, 0, -1], [[0, 0], [uw, 0], [uw, uh], [0, uh]]);
  addFace(g, [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], [1, 0, 0], [[0, 0], [ud, 0], [ud, uh], [0, uh]]);
  addFace(g, [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], [-1, 0, 0], [[0, 0], [ud, 0], [ud, uh], [0, uh]]);
  addFace(g, [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], [0, 1, 0], [[0, 0], [uw, 0], [uw, ud], [0, ud]]);
  addFace(g, [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], [0, -1, 0], [[0, 0], [uw, 0], [uw, ud], [0, ud]]);
}

export interface HubRefs {
  group: THREE.Group;
  /** Player arrival point (center of the entry chamber, facing down-tunnel). */
  entry: { x: number; z: number; yaw: number };
  outpost: THREE.Vector3;
  elevator: THREE.Vector3;
  /** Caged-bulb positions for the dynamic light pool. */
  lampPos: THREE.Vector3[];
  elevatorButton: THREE.Mesh;
  elevatorLamp: THREE.Mesh;
  /** Flooded gallery water plane (animated sheen). */
  water: THREE.Mesh;
  /** Pump rig (machine room, east wing): lever + status lamps + red glow. */
  machineLever: THREE.Mesh;
  machineLampOff: THREE.Mesh;
  machineLampOn: THREE.Mesh;
  machineLight: THREE.PointLight;
  machinePos: THREE.Vector3;
  /** Flooded gallery center: drip audio + wade zone anchor. */
  waterPos: THREE.Vector3;
  /** East wing mouth at the junction (first-approach hint trigger). */
  galleryMouth: THREE.Vector3;
}

type AddCollider = (minX: number, maxX: number, minZ: number, maxZ: number) => void;
type AddInteractable = (i: Interactable) => void;

export function buildHub(
  parent: THREE.Object3D,
  tex: GameTextures,
  addCollider: AddCollider,
  addInteractable: AddInteractable,
  addNote: (x: number, z: number, id: number) => void,
  addBottle: (x: number, z: number) => void
): HubRefs {
  const group = new THREE.Group();
  const lampPos: THREE.Vector3[] = [];
  const H = 2.7; // tunnel height - lower and tighter than Level 0

  const wall = (cx: number, cz: number, w: number, d: number, h = H): void => {
    addBoxGeo(geo, cx, h / 2, cz, w, h, d);
    addCollider(cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2);
  };

  // ---------- shell geometry (merged, concrete) ----------
  const geo: GeoArrays = { pos: [], norm: [], uv: [], idx: [] };

  // entry chamber x 298.3..301.7, z 298.3..301.7
  wall(300, 298.3, 3.7, 0.3); // north (behind arrival - rubble chokes it)
  wall(298.3, 300, 0.3, 3.7);
  wall(301.7, 300, 0.3, 3.7);

  // tunnel A x 298.7..301.3, z 301.7..321.7
  wall(298.7, 311.7, 0.3, 20.3);
  wall(301.3, 311.7, 0.3, 20.3);

  // junction x 297..303, z 321.7..326.7 (north wall leaves the tunnel opening)
  wall(297.85, 321.7, 2.0, 0.3);
  wall(302.15, 321.7, 2.0, 0.3);
  wall(297, 324.2, 0.3, 5.3);
  // east wall with the stub opening z 323.2..325.2
  wall(303, 322.45, 0.3, 1.8);
  wall(303, 325.95, 0.3, 1.8);
  // south wall leaves the tunnel B opening x 298.7..301.3
  wall(297.85, 326.7, 2.0, 0.3);
  wall(302.15, 326.7, 2.0, 0.3);

  // pump gallery (east wing) x 303..313.5, z 323.35..325.05
  wall(308.4, 323.2, 10.8, 0.3); // north
  wall(308.4, 325.2, 10.8, 0.3); // south

  // machine room x 313.5..318.6, z 321.35..327.05
  wall(316.05, 321.35, 5.4, 0.3);
  wall(316.05, 327.05, 5.4, 0.3);
  wall(318.45, 324.2, 0.3, 6.2);
  wall(313.65, 322.4, 0.3, 1.9); // west, north of the gallery opening
  wall(313.65, 326.2, 0.3, 1.7); // west, south of the gallery opening

  // tunnel B x 298.7..301.3, z 326.7..338.7
  wall(298.7, 332.7, 0.3, 12.3);
  wall(301.3, 332.7, 0.3, 12.3);

  // elevator alcove x 297.8..302.2, z 338.7..343.3
  wall(297.8, 341, 0.3, 4.9);
  wall(302.2, 341, 0.3, 4.9);
  wall(298.25, 338.7, 1.2, 0.3);
  wall(301.75, 338.7, 1.2, 0.3);
  // south wall leaves the 2.2m lift opening x 298.9..301.1
  wall(298.35, 343.3, 1.4, 0.3);
  wall(301.65, 343.3, 1.4, 0.3);

  // floor + ceiling slabs (top / bottom faces carry the concrete)
  addBoxGeo(geo, 300.5, -0.1, 320.75, 9.4, 0.2, 49.8);
  addBoxGeo(geo, 308.4, -0.1, 324.2, 11.0, 0.2, 3.0); // pump gallery slab
  addBoxGeo(geo, 316.05, -0.1, 324.2, 5.6, 0.2, 6.3); // machine room slab
  addBoxGeo(geo, 300.5, H + 0.1, 320.75, 9.4, 0.2, 49.8);
  addBoxGeo(geo, 308.4, H + 0.1, 324.2, 11.0, 0.2, 3.0); // gallery ceiling
  addBoxGeo(geo, 316.05, H + 0.1, 324.2, 5.6, 0.2, 6.3); // machine room ceiling

  const solid = new THREE.BufferGeometry();
  solid.setAttribute('position', new THREE.Float32BufferAttribute(geo.pos, 3));
  solid.setAttribute('normal', new THREE.Float32BufferAttribute(geo.norm, 3));
  solid.setAttribute('uv', new THREE.Float32BufferAttribute(geo.uv, 2));
  solid.setIndex(geo.idx);
  group.add(
    new THREE.Mesh(
      solid,
      new THREE.MeshStandardMaterial({
        map: tex.concrete.map,
        bumpMap: tex.concrete.bump,
        bumpScale: 0.4,
        roughnessMap: tex.concrete.rough,
        roughness: 1.0,
        metalness: 0.0,
      })
    )
  );

  // ---------- caged bulbs ----------
  const bulbPositions: [number, number][] = [
    [300, 300], // entry
    [300, 305.5],
    [300, 311.5],
    [300, 317.5], // tunnel A
    [300, 324.2], // junction
    [306.5, 324.2], // pump gallery
    [316.1, 324.2], // machine room
    [300, 330],
    [300, 335.5], // tunnel B
    [300, 341], // lift alcove
  ];
  for (const [lx, lz] of bulbPositions) {
    const lamp = P.buildCagedLamp();
    lamp.group.position.set(lx, H, lz);
    group.add(lamp.group);
    lampPos.push(new THREE.Vector3(lx, H - 0.36, lz));
  }

  // ---------- pipes along the tunnel walls (hub ceiling is lower) ----------
  const pipeRun = (x: number, z0: number, z1: number, y: number, r: number, col: number): void => {
    const len = z1 - z0;
    const p = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 8), new THREE.MeshLambertMaterial({ color: col }));
    p.rotation.x = Math.PI / 2;
    p.position.set(x, y, (z0 + z1) / 2);
    group.add(p);
    for (let z = z0 + 1.2; z < z1; z += 2.6) {
      const b = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.16, 0.07),
        new THREE.MeshLambertMaterial({ color: 0x3a3833 })
      );
      b.position.set(x, y - 0.12, z);
      group.add(b);
    }
  };
  pipeRun(301.05, 302.5, 321, 2.32, 0.085, 0x46403a);
  pipeRun(300.86, 302.5, 321, 2.08, 0.055, 0x3a4044);
  pipeRun(298.95, 327.5, 338, 2.32, 0.075, 0x40484c);

  // ---------- entry chamber: stencil + sealed way back ----------
  const stencil = new THREE.Mesh(
    new THREE.PlaneGeometry(1.7, 0.85),
    new THREE.MeshBasicMaterial({ map: tex.signs.arrowHub, transparent: true })
  );
  stencil.position.set(301.52, 1.7, 300.4);
  stencil.rotation.y = -Math.PI / 2; // faces the arriving player
  group.add(stencil);

  const backRubble = P.buildRubblePile();
  backRubble.position.set(300, 0, 298.75);
  group.add(backRubble);
  addCollider(299.0, 301.0, 298.4, 299.2);

  // ---------- pump gallery: flood water + a traveler's scrawl ----------
  // cloned bump: the game scrolls THIS copy for the sheen drift without
  // sliding the bump on the shared tunnel walls
  const waterBump = tex.concrete.bump.clone();
  waterBump.needsUpdate = true;
  waterBump.wrapS = THREE.RepeatWrapping;
  waterBump.wrapT = THREE.RepeatWrapping;
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(10.2, 1.42),
    new THREE.MeshStandardMaterial({
      color: 0x10171a,
      roughness: 0.14,
      metalness: 0.5,
      bumpMap: waterBump,
      bumpScale: 0.05,
      transparent: true,
      opacity: 0.88,
    })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.set(308.4, 0.05, 324.2);
  group.add(water);

  const galleryRubble = P.buildRubblePile();
  galleryRubble.position.set(308.7, 0, 324.85);
  galleryRubble.scale.set(0.75, 0.8, 0.7);
  group.add(galleryRubble);
  addCollider(308.35, 309.05, 324.6, 325.05);

  const stubSign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.8),
    new THREE.MeshBasicMaterial({ map: tex.signs.humLies, transparent: true })
  );
  stubSign.position.set(306.3, 1.75, 323.42);
  group.add(stubSign);

  // ---------- M.E.G. outpost (junction, west side) ----------
  const table = P.buildTable();
  table.group.position.set(297.95, 0, 323.5);
  group.add(table.group);
  addCollider(297.5, 298.4, 323.05, 323.95);

  const radio = P.buildRadio();
  radio.position.set(297.95, 0.75, 323.55);
  group.add(radio);
  addInteractable({
    id: 'radioOutpost',
    kind: 'radioOutpost',
    pos: new THREE.Vector3(297.95, 0.85, 323.55),
    radius: 2.3,
    prompt: 'OUTPOST RADIO - LISTEN',
    active: true,
    mesh: radio,
  });

  const crates = P.buildCrateStack({ map: tex.crateWood.map, bumpMap: tex.crateWood.bump });
  crates.group.position.set(297.85, 0, 326.0);
  crates.group.rotation.y = 0.5;
  group.add(crates.group);
  addCollider(297.3, 298.4, 325.5, 326.5);

  const crates2 = P.buildCrateStack({ map: tex.crateWood.map, bumpMap: tex.crateWood.bump });
  crates2.group.position.set(298.9, 0, 326.1);
  crates2.group.rotation.y = -0.3;
  crates2.group.scale.setScalar(0.8);
  group.add(crates2.group);
  addCollider(298.45, 299.35, 325.7, 326.5);

  const flag = P.buildMEGFlag(tex.signs.megFlag);
  flag.position.set(297.55, 0, 322.2);
  flag.rotation.y = 0.5;
  group.add(flag);

  const lampOut = new THREE.PointLight(0xffd9a0, 2.6, 6.5, 1.6);
  lampOut.position.set(298.4, 2.25, 324.2);
  group.add(lampOut);

  addNote(298.6, 324.9, 12);
  addBottle(298.3, 322.9);
  addBottle(298.0, 325.6);

  // ---------- pump rig (machine room, east wall) ----------
  const rig = new THREE.Group();
  rig.position.set(317.75, 0, 324.2);
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(1.35, 1.55, 2.1),
    new THREE.MeshLambertMaterial({ color: 0x394043 })
  );
  body.position.y = 0.775;
  rig.add(body);
  const top = new THREE.Mesh(
    new THREE.BoxGeometry(1.0, 0.18, 1.7),
    new THREE.MeshLambertMaterial({ color: 0x2e3436 })
  );
  top.position.y = 1.64;
  rig.add(top);
  const motor = new THREE.Mesh(
    new THREE.CylinderGeometry(0.26, 0.26, 0.62, 10),
    new THREE.MeshLambertMaterial({ color: 0x45403a })
  );
  motor.rotation.x = Math.PI / 2;
  motor.position.y = 2.02;
  rig.add(motor);
  for (const dz of [-0.5, 0.5]) {
    const pipe = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.06, 1.0, 8),
      new THREE.MeshLambertMaterial({ color: 0x40484c })
    );
    pipe.position.set(-0.3, 2.2, dz);
    rig.add(pipe);
  }
  // gauge: dark bezel + pale face, aimed at the operator
  const gaugeRim = new THREE.Mesh(
    new THREE.CylinderGeometry(0.13, 0.13, 0.05, 12),
    new THREE.MeshLambertMaterial({ color: 0x1d2123 })
  );
  gaugeRim.rotation.z = Math.PI / 2;
  gaugeRim.position.set(-0.72, 1.42, -0.58);
  rig.add(gaugeRim);
  const gaugeFace = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 0.06, 12),
    new THREE.MeshBasicMaterial({ color: 0xc9c2ad })
  );
  gaugeFace.rotation.z = Math.PI / 2;
  gaugeFace.position.set(-0.73, 1.42, -0.58);
  rig.add(gaugeFace);
  // status lamps: red while the pump drinks the mains, green after shutdown
  const lampOff = new THREE.Mesh(
    new THREE.BoxGeometry(0.03, 0.07, 0.07),
    new THREE.MeshBasicMaterial({ color: 0x571512 })
  );
  lampOff.position.set(-0.7, 1.75, 0.62);
  rig.add(lampOff);
  const lampOn = new THREE.Mesh(
    new THREE.BoxGeometry(0.03, 0.07, 0.07),
    new THREE.MeshBasicMaterial({ color: 0x38ff62 })
  );
  lampOn.position.set(-0.7, 1.75, 0.62);
  lampOn.visible = false;
  rig.add(lampOn);
  // the lever: big red pump-mains handle, flips on shutdown
  const leverBase = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.52, 0.24),
    new THREE.MeshLambertMaterial({ color: 0x23282a })
  );
  leverBase.position.set(-0.71, 1.05, 0.65);
  rig.add(leverBase);
  const lever = new THREE.Mesh(
    new THREE.BoxGeometry(0.075, 0.46, 0.06),
    new THREE.MeshStandardMaterial({ color: 0xb03a2e, roughness: 0.6 })
  );
  lever.geometry.translate(0, 0.23, 0);
  lever.position.set(-0.75, 1.28, 0.65);
  lever.rotation.x = 0.95; // leaning down-south: pump RUNNING
  rig.add(lever);
  group.add(rig);
  addCollider(317.05, 318.6, 323.1, 325.3);

  const machineLight = new THREE.PointLight(0xff5040, 1.15, 5.2, 1.7);
  machineLight.position.set(316.85, 1.9, 324.2);
  group.add(machineLight);

  const hazardStrip = new THREE.Mesh(
    new THREE.PlaneGeometry(1.9, 0.55),
    new THREE.MeshLambertMaterial({ map: tex.hazard })
  );
  hazardStrip.rotation.x = -Math.PI / 2;
  hazardStrip.position.set(316.55, 0.012, 324.2);
  group.add(hazardStrip);

  addInteractable({
    id: 'hubLever',
    kind: 'hubLever',
    pos: new THREE.Vector3(316.9, 1.3, 324.85),
    radius: 2.2,
    prompt: 'SHUT DOWN THE PUMP RIG',
    active: true,
  });
  addNote(317.9, 322.2, 13);

  // ---------- survivor camp (tunnel B, west side) ----------
  const camp = new THREE.Group();
  camp.position.set(299.15, 0, 331.4);
  const mat = new THREE.Mesh(
    new THREE.BoxGeometry(0.6, 0.045, 1.8),
    new THREE.MeshLambertMaterial({ color: 0x2f4232 })
  );
  mat.position.y = 0.0225;
  camp.add(mat);
  const roll = new THREE.Mesh(
    new THREE.CylinderGeometry(0.085, 0.085, 0.55, 8),
    new THREE.MeshLambertMaterial({ color: 0x6a6458 })
  );
  roll.rotation.z = Math.PI / 2;
  roll.position.set(0, 0.09, -0.78);
  camp.add(roll);
  const pack = new THREE.Mesh(
    new THREE.BoxGeometry(0.32, 0.4, 0.24),
    new THREE.MeshLambertMaterial({ color: 0x4a3f2e })
  );
  pack.position.set(-0.2, 0.2, 0.7);
  pack.rotation.y = -0.25;
  camp.add(pack);
  group.add(camp);
  addCollider(298.75, 299.15, 331.9, 332.3);

  const campCrate = P.buildCrateStack({ map: tex.crateWood.map, bumpMap: tex.crateWood.bump });
  campCrate.group.position.set(299.05, 0, 333.6);
  campCrate.group.rotation.y = -0.4;
  group.add(campCrate.group);
  addCollider(298.65, 299.45, 333.2, 334.0);

  const campSign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.8),
    new THREE.MeshBasicMaterial({ map: tex.signs.dontStop, transparent: true })
  );
  campSign.position.set(298.86, 1.75, 331.6);
  campSign.rotation.y = Math.PI / 2;
  group.add(campSign);

  addNote(299.3, 332.2, 14);
  addBottle(299.5, 330.9);

  // ---------- freight lift (alcove south wall) ----------
  const lift = P.buildElevator(tex.signs.lift, tex.hazard);
  lift.group.position.set(300, 0, 343.3);
  group.add(lift.group);
  addCollider(298.9, 301.1, 343.15, 343.5); // threshold: the cage is the exit
  const lampLift = new THREE.PointLight(0xffe2b0, 2.4, 6, 1.6);
  lampLift.position.set(300, 2.3, 344);
  group.add(lampLift);
  addInteractable({
    id: 'elevator',
    kind: 'elevator',
    pos: new THREE.Vector3(300, 1.25, 342.6),
    radius: 2.6,
    prompt: 'CALL THE FREIGHT LIFT',
    active: true,
  });

  parent.add(group);

  return {
    group,
    entry: { x: 300, z: 300.3, yaw: Math.PI }, // facing +Z, down-tunnel
    outpost: new THREE.Vector3(297.95, 0, 323.5),
    elevator: new THREE.Vector3(300, 1.25, 342.6),
    lampPos,
    elevatorButton: lift.button,
    elevatorLamp: lift.lampGreen,
    water,
    machineLever: lever,
    machineLampOff: lampOff,
    machineLampOn: lampOn,
    machineLight,
    machinePos: new THREE.Vector3(317.3, 0, 324.2),
    waterPos: new THREE.Vector3(308.4, 0, 324.2),
    galleryMouth: new THREE.Vector3(303, 0, 324.2),
  };
}
