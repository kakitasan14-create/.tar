// Custom VHS post-processing: renders the scene to a low-res target, then a
// fullscreen quad pass adds barrel distortion, chromatic aberration, luma
// bleed, scanlines, rolling band, tape weave, noise patches, edge-enhancement
// halo, grain, dropouts, head-switch noise, tear glitches and a vignette.
// Pure GLSL - no EffectComposer dependency.

import * as THREE from 'three';

const FRAG = /* glsl */ `
precision highp float;
uniform sampler2D tDiffuse;
uniform float uTime;
uniform float uStatic;   // 0..1 extra noise (entity proximity / death)
uniform float uTear;     // 0..1 glitch slice displacement
uniform float uFx;       // 0.55 LOW / 1 MED / 1.5 HIGH tape degradation
uniform vec2 uRes;
varying vec2 vUv;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

void main() {
  vec2 uv = vUv;
  vec2 c = uv - 0.5;
  float r2 = dot(c, c);
  float line = floor(uv.y * uRes.y);

  // barrel distortion (CRT pickup tube bulge) with a barely-there breathing
  float breathe = 0.045 + 0.003 * sin(uTime * 0.7);
  uv = 0.5 + c * (1.0 + breathe * r2);

  // slow horizontal tape weave (unstable capstan)
  uv.x += sin(uv.y * 9.0 + uTime * 1.7) * 0.00032 * uFx;
  uv.x += sin(uv.y * 23.0 - uTime * 3.1) * 0.00016 * uFx;

  // per-frame line jitter (tracking error), worse with static
  // kept small: heavy per-line jitter reads as the whole frame shredding
  float jAmp = (0.00028 + uStatic * 0.0012) * uFx;
  uv.x += (hash(vec2(line, floor(uTime * 60.0))) - 0.5) * jAmp;

  // tear glitch: horizontal slice displacement (event stings only - kept
  // punchy but not screen-destroying)
  if (uTear > 0.001) {
    float slice = floor(uv.y * 42.0);
    float n = hash(vec2(slice, floor(uTime * 24.0)));
    uv.x += (n - 0.5) * uTear * 0.085;
    float bigJump = step(0.975 - uTear * 0.15, hash(vec2(floor(uTime * 7.0), 3.7)));
    uv.y += bigJump * (hash(vec2(floor(uTime * 7.0), 9.1)) - 0.5) * 0.03 * uTear;
  }

  // interlace comb offset
  uv.x += (mod(line, 2.0) - 0.5) * 0.0008;

  // tracking band that rolls down - slow, and it drifts in/out of visibility
  // instead of scrolling permanently (was: constant line rain)
  float bandSpeed = 0.025 + uStatic * 0.16;
  float band = fract(uv.y - uTime * bandSpeed);
  float bandMask = smoothstep(0.0, 0.02, band) * smoothstep(0.05, 0.022, band);
  bandMask *= smoothstep(0.25, 0.75, 0.5 + 0.5 * sin(uTime * 0.17 + 1.7));

  // dirty-tape noise patches: rare ragged streaks, changing slowly
  // (quiet tape: ~1% of row bands; hunts pull the threshold down hard)
  float patchRow = hash(vec2(floor(uv.y * 22.0), floor(uTime * 2.3)));
  float tapePatch = smoothstep(0.988 - uStatic * 0.05, 1.0, patchRow) * uFx;

  // out of bounds = static
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
    float n = hash(uv * uRes + uTime * 100.0);
    gl_FragColor = vec4(vec3(n * 0.6), 1.0);
    return;
  }

  // chromatic aberration (radial + static driven)
  float ab = (0.0009 + uStatic * 0.0028 + r2 * 0.0016) * uFx;
  vec2 off = normalize(c + vec2(1e-5)) * ab;
  float rr = texture2D(tDiffuse, uv + off).r;
  float gg = texture2D(tDiffuse, uv).g;
  float bb = texture2D(tDiffuse, uv - off).b;

  // vertical chroma smear: real VHS records chroma at a fraction of luma
  // resolution, so color bleeds across scanlines - two extra taps per channel
  float px = 1.4 / uRes.y;
  float rUp = texture2D(tDiffuse, uv + off + vec2(0.0, px)).r;
  float rDn = texture2D(tDiffuse, uv + off - vec2(0.0, px)).r;
  float bUp = texture2D(tDiffuse, uv - off + vec2(0.0, px)).b;
  float bDn = texture2D(tDiffuse, uv - off - vec2(0.0, px)).b;
  rr = mix(rr, (rr + rUp + rDn) * 0.3333, 0.55);
  bb = mix(bb, (bb + bUp + bDn) * 0.3333, 0.55);

  // luma bleed (horizontal smear on green)
  float gl = texture2D(tDiffuse, uv + vec2(0.0016, 0.0)).g;
  float gr = texture2D(tDiffuse, uv - vec2(0.0016, 0.0)).g;
  gg = gg * 0.6 + (gl + gr) * 0.2;

  vec3 col = vec3(rr, gg, bb);

  // camcorder edge-enhancement halo (the sharpness circuit overshoot)
  float edgeR = texture2D(tDiffuse, uv + vec2(1.6 / uRes.x, 0.0)).g;
  col += clamp(gg - edgeR, -0.35, 0.35) * 0.085 * uFx;

  // scanlines
  float scan = 0.9 + 0.1 * sin(uv.y * uRes.y * 3.14159 * 0.82);
  col *= mix(1.0, scan, 0.72 * uFx);

  // rolling tracking band brightening (subtle)
  col += bandMask * (0.02 + 0.02 * uFx);
  col = mix(col, vec3(dot(col, vec3(0.333))) * 1.4 + 0.2, bandMask * 0.05 * uFx);

  // tape noise patches: crumbling signal
  if (tapePatch > 0.001) {
    float pn = hash(uv * uRes * 0.7 + vec2(uTime * 91.0, uTime * 57.0));
    col = mix(col, vec3(pn * 0.7), clamp(tapePatch, 0.0, 0.26));
  }

  // grain
  float g = hash(uv * uRes * vec2(0.9, 1.1) + vec2(uTime * 63.0, uTime * 31.0));
  col += (g - 0.5) * (0.03 + uStatic * 0.15) * uFx;

  // chroma noise (color underlines shimmer per line)
  float chN1 = hash(vec2(line * 1.7, floor(uTime * 47.0))) - 0.5;
  float chN2 = hash(vec2(line * 2.3, floor(uTime * 47.0) + 7.0)) - 0.5;
  col.r += chN1 * 0.011 * uFx;
  col.b += chN2 * 0.011 * uFx;

  // dropout lines (more with static) - rare single-row dropouts, dimmed
  // (was 3.5% static-coupled: looked like white lines raining down)
  float rowN = hash(vec2(line, floor(uTime * 13.0)));
  if (rowN > 1.0 - (0.0007 + uStatic * 0.008) * uFx) {
    col = mix(col, vec3(0.6), 0.35);
  }

  // snow flecks: big bright specks that pop in and out
  float fleck = hash(floor(uv * uRes * 0.35) + floor(uTime * 24.0));
  if (fleck > 0.9996 - uStatic * 0.0015) col += vec3(0.3);

  // head-switch noise bar at the bottom (height jitters per frame)
  float hsH = 0.017 + hash(vec2(floor(uTime * 30.0), 4.2)) * 0.009;
  if (uv.y < hsH) {
    float n = hash(vec2(uv.x * 320.0, floor(uTime * 30.0)));
    col = mix(col, vec3(n * 0.5), 0.7);
  }

  // color grade: slight desat, warm VHS tint, lifted blacks
  float luma = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(col, vec3(luma), 0.1);
  col *= vec3(1.045, 1.0, 0.9);
  col = col * 0.97 + 0.045;

  // vignette (pickup tube falloff)
  float vig = smoothstep(1.05, 0.35, length(c) * 1.45);
  col *= mix(0.78, 1.0, vig);

  gl_FragColor = vec4(col, 1.0);

  // scene was rendered linear into the RT - encode for the sRGB canvas
  #include <colorspace_fragment>
}
`;

const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

export class VHSPass {
  private rt: THREE.WebGLRenderTarget;
  private scene = new THREE.Scene();
  private cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private material: THREE.ShaderMaterial;

  constructor(width: number, height: number) {
    this.rt = new THREE.WebGLRenderTarget(width, height, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: true,
    });
    this.material = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: this.rt.texture },
        uTime: { value: 0 },
        uStatic: { value: 0 },
        uTear: { value: 0 },
        uFx: { value: 1 },
        uRes: { value: new THREE.Vector2(width, height) },
      },
      vertexShader: VERT,
      fragmentShader: FRAG,
      depthTest: false,
      depthWrite: false,
    });
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
    quad.frustumCulled = false;
    this.scene.add(quad);
  }

  setSize(width: number, height: number): void {
    this.rt.setSize(width, height);
    (this.material.uniforms.uRes.value as THREE.Vector2).set(width, height);
  }

  /** Tape degradation preset: 0 = LOW, 1 = MED (default), 2 = HIGH. */
  setLevel(level: number): void {
    this.material.uniforms.uFx.value = [0.55, 1, 1.55][Math.max(0, Math.min(2, level))];
  }

  set(time: number, statik: number, tear: number): void {
    this.material.uniforms.uTime.value = time;
    this.material.uniforms.uStatic.value = statik;
    this.material.uniforms.uTear.value = tear;
  }

  render(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.Camera,
    overlay?: () => void
  ): void {
    renderer.setRenderTarget(this.rt);
    renderer.clear();
    renderer.render(scene, camera);
    // optional viewmodel pass: depth-cleared so hands never clip into walls
    // (the overlay manages autoClear/background itself)
    if (overlay) overlay();
    renderer.setRenderTarget(null);
    renderer.render(this.scene, this.cam);
  }

  dispose(): void {
    this.rt.dispose();
    this.material.dispose();
  }
}
