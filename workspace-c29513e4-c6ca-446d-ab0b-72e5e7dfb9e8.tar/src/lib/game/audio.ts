// Fully procedural WebAudio engine: fluorescent hum, room tone, footsteps,
// entity growls, heartbeat, radio garble, music box and sting cues.
// No audio files - every sound is synthesized.

type Ctx = AudioContext;

export type StingName =
  | 'detect'
  | 'catch'
  | 'flicker'
  | 'powerdown'
  | 'powerup'
  | 'pickup'
  | 'drink'
  | 'paper'
  | 'lever'
  | 'doorCreak'
  | 'thud'
  | 'whisper'
  | 'slam'
  | 'party'
  | 'uiTick'
  | 'uiConfirm';

export class AudioEngine {
  ctx: Ctx | null = null;
  private master!: GainNode;
  private noiseBuf!: AudioBuffer;
  private brownBuf!: AudioBuffer;

  private humGain!: GainNode;
  private humOsc1!: OscillatorNode;
  private humOsc2!: OscillatorNode;
  private humTarget = 1;

  private roomSrc!: AudioBufferSourceNode;
  private roomGain!: GainNode;

  private growlGain!: GainNode;
  private growlPan!: StereoPannerNode;
  private growlLevel = 0;

  private staticGain!: GainNode;
  private staticSrc!: AudioBufferSourceNode;
  private staticLevel = 0;

  private radioGain!: GainNode;

  private musicOn = false;
  private musicGain!: GainNode;
  private musicPan!: StereoPannerNode;
  private musicNext = 0;
  private musicIdx = 0;

  private heartNext = 0;
  private stepAlt = 0;

  // --- Hub: pump-room machinery hum bed ---
  private hum2Gain!: GainNode;
  private hum2Pan!: StereoPannerNode;

  // --- Hub: freight-lift rumble bed (ending C) ---
  private rumbleGain!: GainNode;
  private rumbleOn = false;
  private rumbleNext = 0;

  // --- Hub: water drip scheduler ---
  private dripNext = 0;

  muted = false;

  /** Must be called from a user gesture (click). */
  init(): void {
    if (this.ctx) return;
    const AC: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    this.ctx = ctx;

    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.9;
    this.master.connect(ctx.destination);

    // noise buffers
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const nd = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) nd[i] = Math.random() * 2 - 1;
    this.brownBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const bd = this.brownBuf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02;
      bd[i] = last * 3.5;
    }

    // --- fluorescent hum layer ---
    this.humGain = ctx.createGain();
    this.humGain.gain.value = 0.0;
    this.humGain.connect(this.master);
    this.humOsc1 = ctx.createOscillator();
    this.humOsc1.type = 'sawtooth';
    this.humOsc1.frequency.value = 120;
    const humF1 = ctx.createBiquadFilter();
    humF1.type = 'bandpass';
    humF1.frequency.value = 120;
    humF1.Q.value = 6;
    this.humOsc1.connect(humF1).connect(this.humGain);
    this.humOsc2 = ctx.createOscillator();
    this.humOsc2.type = 'sine';
    this.humOsc2.frequency.value = 240;
    const humG2 = ctx.createGain();
    humG2.gain.value = 0.5;
    this.humOsc2.connect(humG2).connect(this.humGain);
    this.humOsc1.start();
    this.humOsc2.start();

    // --- room tone (brown noise) ---
    this.roomGain = ctx.createGain();
    this.roomGain.gain.value = 0.0;
    const roomF = ctx.createBiquadFilter();
    roomF.type = 'lowpass';
    roomF.frequency.value = 300;
    this.roomSrc = ctx.createBufferSource();
    this.roomSrc.buffer = this.brownBuf;
    this.roomSrc.loop = true;
    this.roomSrc.connect(roomF).connect(this.roomGain).connect(this.master);
    this.roomSrc.start();

    // --- entity growl bed ---
    this.growlGain = ctx.createGain();
    this.growlGain.gain.value = 0;
    this.growlPan = ctx.createStereoPanner();
    const gf = ctx.createBiquadFilter();
    gf.type = 'lowpass';
    gf.frequency.value = 240;
    const g1 = ctx.createOscillator();
    g1.type = 'sawtooth';
    g1.frequency.value = 47;
    const g2 = ctx.createOscillator();
    g2.type = 'sawtooth';
    g2.frequency.value = 49.7;
    g1.connect(gf);
    g2.connect(gf);
    gf.connect(this.growlGain).connect(this.growlPan).connect(this.master);
    g1.start();
    g2.start();

    // --- VHS static bed ---
    this.staticGain = ctx.createGain();
    this.staticGain.gain.value = 0;
    const sf = ctx.createBiquadFilter();
    sf.type = 'highpass';
    sf.frequency.value = 1800;
    this.staticSrc = ctx.createBufferSource();
    this.staticSrc.buffer = this.noiseBuf;
    this.staticSrc.loop = true;
    this.staticSrc.connect(sf).connect(this.staticGain).connect(this.master);
    this.staticSrc.start();

    // --- radio static bed (for dialogue) ---
    this.radioGain = ctx.createGain();
    this.radioGain.gain.value = 0;
    const rf = ctx.createBiquadFilter();
    rf.type = 'bandpass';
    rf.frequency.value = 1400;
    rf.Q.value = 0.6;
    const rSrc = ctx.createBufferSource();
    rSrc.buffer = this.noiseBuf;
    rSrc.loop = true;
    rSrc.connect(rf).connect(this.radioGain).connect(this.master);
    rSrc.start();

    // --- music box bus ---
    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = 0.9;
    this.musicPan = ctx.createStereoPanner();
    this.musicGain.connect(this.musicPan).connect(this.master);

    // --- pump-room machinery hum bed (The Hub, east gallery) ---
    this.hum2Gain = ctx.createGain();
    this.hum2Gain.gain.value = 0;
    this.hum2Pan = ctx.createStereoPanner();
    const mf = ctx.createBiquadFilter();
    mf.type = 'lowpass';
    mf.frequency.value = 130;
    const m1 = ctx.createOscillator();
    m1.type = 'triangle';
    m1.frequency.value = 52;
    const m2 = ctx.createOscillator();
    m2.type = 'triangle';
    m2.frequency.value = 53.4; // slow beating
    const m3 = ctx.createOscillator();
    m3.type = 'sawtooth';
    m3.frequency.value = 104;
    const mg3 = ctx.createGain();
    mg3.gain.value = 0.35;
    m1.connect(mf);
    m2.connect(mf);
    m3.connect(mg3).connect(mf);
    mf.connect(this.hum2Gain).connect(this.hum2Pan).connect(this.master);
    m1.start();
    m2.start();
    m3.start();

    // --- freight-lift rumble bed (ending C: heavy cage machinery) ---
    this.rumbleGain = ctx.createGain();
    this.rumbleGain.gain.value = 0;
    const rf2 = ctx.createBiquadFilter();
    rf2.type = 'lowpass';
    rf2.frequency.value = 85;
    const rn = ctx.createBufferSource();
    rn.buffer = this.brownBuf;
    rn.loop = true;
    rn.connect(rf2).connect(this.rumbleGain);
    const rOsc = ctx.createOscillator();
    rOsc.type = 'sine';
    rOsc.frequency.value = 31;
    const rOscG = ctx.createGain();
    rOscG.gain.value = 0.6;
    rOsc.connect(rOscG).connect(this.rumbleGain);
    rn.start();
    rOsc.start();
    this.rumbleGain.connect(this.master);
  }

  resume(): void {
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setMuted(m: boolean): void {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
    }
  }

  dispose(): void {
    if (this.ctx) {
      void this.ctx.close().catch(() => undefined);
      this.ctx = null;
    }
  }

  private env(node: AudioNode, vol: number, attack: number, decay: number, pan = 0): void {
    const ctx = this.ctx as Ctx;
    const t = ctx.currentTime;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
    const p = ctx.createStereoPanner();
    p.pan.value = Math.max(-1, Math.min(1, pan));
    node.connect(g).connect(p).connect(this.master);
  }

  private noiseSrc(): AudioBufferSourceNode {
    const s = (this.ctx as Ctx).createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = true;
    s.playbackRate.value = 0.7 + Math.random() * 0.6;
    return s;
  }

  // ---------- ambience control ----------

  setAmbience(hum: number, room: number): void {
    if (!this.ctx) return;
    this.humTarget = hum;
    this.humGain.gain.setTargetAtTime(hum * 0.05, this.ctx.currentTime, 0.4);
    this.roomGain.gain.setTargetAtTime(room * 0.045, this.ctx.currentTime, 0.6);
  }

  setStatic(level: number): void {
    if (!this.ctx) return;
    this.staticLevel = level;
    this.staticGain.gain.setTargetAtTime(Math.min(0.16, level * 0.14), this.ctx.currentTime, 0.12);
  }

  setGrowl(level: number, pan: number): void {
    if (!this.ctx) return;
    this.growlLevel = level;
    this.growlGain.gain.setTargetAtTime(level * 0.14, this.ctx.currentTime, 0.18);
    this.growlPan.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), this.ctx.currentTime, 0.12);
  }

  /** Pump-room machinery bed; level 0..1, pan -1..1 (The Hub). */
  setMachineHum(level: number, pan = 0): void {
    if (!this.ctx) return;
    this.hum2Gain.gain.setTargetAtTime(level * 0.085, this.ctx.currentTime, 0.35);
    this.hum2Pan.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), this.ctx.currentTime, 0.2);
  }

  /** Per-frame water drip scheduler; level 0..1 proximity to the flooded gallery. */
  updateDrips(level: number, pan = 0): void {
    if (!this.ctx || level <= 0.02) return;
    const ctx = this.ctx;
    if (ctx.currentTime < this.dripNext) return;
    this.dripNext = ctx.currentTime + 0.28 + (1 - level) * 1.5 + Math.random() * 0.5;
    const p = Math.max(-1, Math.min(1, pan + (Math.random() * 0.7 - 0.35)));
    // the plip: short noise tick, highpassed
    const s = this.noiseSrc();
    const f = ctx.createBiquadFilter();
    f.type = 'highpass';
    f.frequency.value = 2800;
    this.env(s.connect(f) as AudioNode, 0.028 + level * 0.03, 0.003, 0.03, p);
    s.start();
    s.stop(ctx.currentTime + 0.1);
    // the resonant drop: sine ping falling in pitch (water cavity)
    const o = ctx.createOscillator();
    o.type = 'sine';
    const base = 1350 + Math.random() * 900;
    const g = ctx.createGain();
    const t = ctx.currentTime + 0.012;
    o.frequency.setValueAtTime(base, t);
    o.frequency.exponentialRampToValueAtTime(base * 0.55, t + 0.14);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.045 + level * 0.05, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.17);
    const pn = ctx.createStereoPanner();
    pn.pan.value = p;
    o.connect(g).connect(pn).connect(this.master);
    o.start(t);
    o.stop(t + 0.25);
  }

  /** Ending C: start the heavy freight-cage rumble + cable creaks. */
  startLiftRumble(): void {
    if (!this.ctx) return;
    this.rumbleOn = true;
    this.rumbleNext = this.ctx.currentTime + 0.4;
    this.rumbleGain.gain.setTargetAtTime(0.34, this.ctx.currentTime, 0.5);
  }

  stopLiftRumble(): void {
    if (!this.ctx) return;
    this.rumbleOn = false;
    this.rumbleGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.4);
  }

  /** Per-frame cable-creak scheduler while the rumble runs. */
  updateRumble(): void {
    if (!this.ctx || !this.rumbleOn) return;
    const ctx = this.ctx;
    if (ctx.currentTime < this.rumbleNext) return;
    this.rumbleNext = ctx.currentTime + 0.85 + Math.random() * 0.9;
    this.cableCreak(Math.random() * 1.2 - 0.6);
    if (Math.random() < 0.35) this.clank(Math.random() * 1.2 - 0.6, 0.5);
  }

  /** Heavy steel-on-steel clank (cage doors, cage walls). */
  clank(pan = 0, vol = 1): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    for (const [fq, v, d] of [
      [214, 0.16 * vol, 0.19],
      [322, 0.11 * vol, 0.13],
      [517, 0.06 * vol, 0.08],
    ] as const) {
      const o = ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = fq * (0.96 + Math.random() * 0.08);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(v, t + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      const pn = ctx.createStereoPanner();
      pn.pan.value = Math.max(-1, Math.min(1, pan));
      o.connect(g).connect(pn).connect(this.master);
      o.start(t);
      o.stop(t + d + 0.05);
    }
    const s = this.noiseSrc();
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 430;
    f.Q.value = 1.4;
    this.env(s.connect(f) as AudioNode, 0.1 * vol, 0.003, 0.07, pan);
    s.start();
    s.stop(t + 0.2);
  }

  /** Rusty cable creak under load: groaning saw sweep. */
  private cableCreak(pan = 0): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    const f0 = 130 + Math.random() * 70;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f0 * (0.45 + Math.random() * 0.2), t + 0.45);
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 240;
    f.Q.value = 5;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.05, t + 0.08);
    g.gain.setValueAtTime(0.05, t + 0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.52);
    const pn = ctx.createStereoPanner();
    pn.pan.value = Math.max(-1, Math.min(1, pan));
    o.connect(f).connect(g).connect(pn).connect(this.master);
    o.start(t);
    o.stop(t + 0.6);
  }

  setRadio(on: boolean): void {
    if (!this.ctx) return;
    this.radioGain.gain.setTargetAtTime(on ? 0.02 : 0, this.ctx.currentTime, 0.15);
  }

  radioGarble(dur = 0.5): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const s = this.noiseSrc();
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 900 + Math.random() * 900;
    f.Q.value = 1.4;
    this.env(s.connect(f) as AudioNode, 0.05, 0.02, dur);
    s.start();
    s.stop(ctx.currentTime + dur + 0.1);
    for (let i = 0; i < 3; i++) {
      const o = ctx.createOscillator();
      o.type = 'square';
      o.frequency.value = 500 + Math.random() * 700;
      const g = ctx.createGain();
      const t = ctx.currentTime + 0.05 + i * (dur / 3);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.03, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 0.08);
    }
  }

  /** Fluorescent flicker clicks; intensity 0..1 */
  flickerBurst(intensity = 1): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const n = 2 + Math.floor(Math.random() * 3 * intensity);
    for (let i = 0; i < n; i++) {
      const s = this.noiseSrc();
      const f = ctx.createBiquadFilter();
      f.type = 'highpass';
      f.frequency.value = 2500;
      this.env(s.connect(f) as AudioNode, 0.04 * intensity, 0.004, 0.03);
      s.start(ctx.currentTime + i * 0.05);
      s.stop(ctx.currentTime + i * 0.05 + 0.08);
    }
  }

  // ---------- one-shots ----------

  step(kind: 'walk' | 'sprint' | 'entity', pan = 0, vol = 1): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    this.stepAlt ^= 1;
    const s = this.noiseSrc();
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    if (kind === 'entity') {
      f.frequency.value = 52 + Math.random() * 22;
      f.Q.value = 1.2;
      this.env(s.connect(f) as AudioNode, 0.5 * vol, 0.006, 0.22, pan);
    } else {
      const sprint = kind === 'sprint';
      f.frequency.value = (sprint ? 95 : 80) + Math.random() * 40 + this.stepAlt * 12;
      f.Q.value = 0.9;
      this.env(s.connect(f) as AudioNode, (sprint ? 0.16 : 0.09) * vol, 0.004, sprint ? 0.12 : 0.09, pan);
    }
    const t = ctx.currentTime;
    s.start(t);
    s.stop(t + 0.5);
  }

  heartbeat(level: number): void {
    if (!this.ctx || level <= 0.01) return;
    const ctx = this.ctx;
    if (ctx.currentTime < this.heartNext) return;
    const interval = 0.95 - level * 0.5;
    this.heartNext = ctx.currentTime + interval;
    const thump = (delay: number, vol: number) => {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = 52;
      const g = ctx.createGain();
      const t = ctx.currentTime + delay;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 0.2);
    };
    thump(0, 0.10 + level * 0.14);
    thump(0.16, 0.07 + level * 0.1);
  }

  private note(freq: number, when: number, dur: number, vol: number, pan: number): void {
    const ctx = this.ctx as Ctx;
    const o = ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.value = freq;
    const o2 = ctx.createOscillator();
    o2.type = 'sine';
    o2.frequency.value = freq * 1.007;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(vol, when + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    const p = ctx.createStereoPanner();
    p.pan.value = Math.max(-1, Math.min(1, pan));
    o.connect(g);
    o2.connect(g);
    g.connect(p).connect(this.musicPan);
    o.start(when);
    o2.start(when);
    o.stop(when + dur + 0.1);
    o2.stop(when + dur + 0.1);
  }

  private melody = [
    659.25, 493.88, 523.25, 440.0, 659.25, 493.88, 523.25, 392.0, 659.25, 493.88, 523.25, 440.0, 587.33, 493.88, 415.3, 329.63,
  ];

  setMusicBox(on: boolean, pan = 0): void {
    this.musicOn = on;
    if (this.musicPan && this.ctx) {
      this.musicPan.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), this.ctx.currentTime, 0.3);
    }
  }

  updateMusicBox(pan: number): void {
    if (!this.ctx || !this.musicOn) return;
    const ctx = this.ctx;
    if (ctx.currentTime >= this.musicNext) {
      const t = Math.max(ctx.currentTime, this.musicNext) + 0.02;
      const f = this.melody[this.musicIdx % this.melody.length];
      this.note(f, t, 1.1, 0.045, pan);
      if (Math.random() < 0.12) this.note(f * 0.5, t + 0.02, 1.3, 0.02, pan); // ghost echo
      this.musicIdx++;
      this.musicNext = t + (0.34 + (Math.random() < 0.1 ? 0.3 : 0));
    }
  }

  sting(name: StingName, pan = 0): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    switch (name) {
      case 'detect': {
        const o = ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(170, t);
        o.frequency.exponentialRampToValueAtTime(720, t + 0.4);
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 1600;
        this.env(o.connect(f) as AudioNode, 0.22, 0.01, 0.55, pan);
        o.start(t);
        o.stop(t + 0.7);
        const s = this.noiseSrc();
        const nf = ctx.createBiquadFilter();
        nf.type = 'bandpass';
        nf.frequency.value = 2200;
        this.env(s.connect(nf) as AudioNode, 0.12, 0.01, 0.4, pan);
        s.start(t);
        s.stop(t + 0.6);
        break;
      }
      case 'catch': {
        const o = ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(95, t);
        o.frequency.exponentialRampToValueAtTime(32, t + 0.9);
        this.env(o as AudioNode, 0.4, 0.005, 1.0, pan);
        o.start(t);
        o.stop(t + 1.1);
        const s = this.noiseSrc();
        this.env(s as AudioNode, 0.35, 0.004, 0.5);
        s.start(t);
        s.stop(t + 0.8);
        break;
      }
      case 'powerdown': {
        this.humOsc1.frequency.setValueAtTime(120, t);
        this.humOsc1.frequency.exponentialRampToValueAtTime(28, t + 1.1);
        this.humGain.gain.setValueAtTime(this.humTarget * 0.05, t);
        this.humGain.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
        const o = ctx.createOscillator();
        o.type = 'sine';
        o.frequency.setValueAtTime(300, t);
        o.frequency.exponentialRampToValueAtTime(55, t + 0.9);
        this.env(o as AudioNode, 0.12, 0.01, 0.9);
        o.start(t);
        o.stop(t + 1.1);
        break;
      }
      case 'powerup': {
        this.humOsc1.frequency.setValueAtTime(40, t);
        this.humOsc1.frequency.linearRampToValueAtTime(120, t + 0.7);
        this.humGain.gain.setValueAtTime(0.0001, t);
        this.humGain.gain.linearRampToValueAtTime(this.humTarget * 0.05, t + 0.8);
        this.flickerBurst(1.4);
        break;
      }
      case 'flicker':
        this.flickerBurst(1);
        break;
      case 'pickup': {
        for (let i = 0; i < 2; i++) {
          const o = ctx.createOscillator();
          o.type = 'sine';
          o.frequency.setValueAtTime(300 - i * 40, t + i * 0.14);
          o.frequency.exponentialRampToValueAtTime(130, t + i * 0.14 + 0.12);
          this.env(o as AudioNode, 0.09, 0.01, 0.14);
          o.start(t + i * 0.14);
          o.stop(t + i * 0.14 + 0.2);
        }
        break;
      }
      case 'drink': {
        for (let i = 0; i < 3; i++) {
          const o = ctx.createOscillator();
          o.type = 'sine';
          o.frequency.setValueAtTime(340 - i * 60, t + i * 0.16);
          o.frequency.exponentialRampToValueAtTime(120, t + i * 0.16 + 0.13);
          this.env(o as AudioNode, 0.11, 0.012, 0.15);
          o.start(t + i * 0.16);
          o.stop(t + i * 0.16 + 0.25);
        }
        const s = this.noiseSrc();
        const hf = ctx.createBiquadFilter();
        hf.type = 'bandpass';
        hf.frequency.value = 600;
        this.env(s.connect(hf) as AudioNode, 0.03, 0.02, 0.5);
        s.start(t);
        s.stop(t + 0.7);
        break;
      }
      case 'paper': {
        const s = this.noiseSrc();
        const f = ctx.createBiquadFilter();
        f.type = 'highpass';
        f.frequency.value = 3000;
        this.env(s.connect(f) as AudioNode, 0.07, 0.02, 0.2);
        s.start(t);
        s.stop(t + 0.35);
        break;
      }
      case 'lever': {
        const o = ctx.createOscillator();
        o.type = 'square';
        o.frequency.value = 82;
        this.env(o as AudioNode, 0.12, 0.004, 0.09);
        o.start(t);
        o.stop(t + 0.15);
        const s = this.noiseSrc();
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 500;
        this.env(s.connect(f) as AudioNode, 0.16, 0.004, 0.16);
        s.start(t);
        s.stop(t + 0.3);
        break;
      }
      case 'doorCreak': {
        const o = ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(190, t);
        o.frequency.linearRampToValueAtTime(85, t + 1.2);
        const lfo = ctx.createOscillator();
        lfo.frequency.value = 7;
        const lg = ctx.createGain();
        lg.gain.value = 22;
        lfo.connect(lg).connect(o.frequency);
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 900;
        this.env(o.connect(f) as AudioNode, 0.06, 0.08, 1.2, pan);
        o.start(t);
        lfo.start(t);
        o.stop(t + 1.5);
        lfo.stop(t + 1.5);
        break;
      }
      case 'slam': {
        const s = this.noiseSrc();
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 130;
        this.env(s.connect(f) as AudioNode, 0.5, 0.004, 0.5);
        s.start(t);
        s.stop(t + 0.8);
        break;
      }
      case 'party': {
        // whistling party horn, warped
        const o = ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(520, t);
        o.frequency.linearRampToValueAtTime(390, t + 0.5);
        const lfo = ctx.createOscillator();
        lfo.frequency.value = 11;
        const lg = ctx.createGain();
        lg.gain.value = 40;
        lfo.connect(lg).connect(o.frequency);
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 1200;
        this.env(o.connect(f) as AudioNode, 0.14, 0.05, 0.8, pan);
        o.start(t);
        lfo.start(t);
        o.stop(t + 1);
        lfo.stop(t + 1);
        break;
      }
      case 'thud': {
        const s = this.noiseSrc();
        const f = ctx.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 110;
        this.env(s.connect(f) as AudioNode, 0.14, 0.01, 0.5, pan);
        s.start(t);
        s.stop(t + 0.7);
        break;
      }
      case 'whisper': {
        const s = this.noiseSrc();
        const f = ctx.createBiquadFilter();
        f.type = 'bandpass';
        f.frequency.setValueAtTime(700, t);
        f.frequency.exponentialRampToValueAtTime(2600, t + 1.1);
        f.Q.value = 8;
        this.env(s.connect(f) as AudioNode, 0.035, 0.25, 0.9, pan);
        s.start(t);
        s.stop(t + 1.4);
        break;
      }
      case 'uiTick': {
        // tape-deck key blip: tiny filtered click, quiet enough to spam
        const o = ctx.createOscillator();
        o.type = 'square';
        o.frequency.value = 1850;
        const f = ctx.createBiquadFilter();
        f.type = 'highpass';
        f.frequency.value = 900;
        this.env(o.connect(f) as AudioNode, 0.05, 0.004, 0.02, 0);
        o.start(t);
        o.stop(t + 0.05);
        break;
      }
      case 'uiConfirm': {
        // mechanical tape-button thunk: low knock + contact click
        const o = ctx.createOscillator();
        o.type = 'square';
        o.frequency.setValueAtTime(220, t);
        o.frequency.exponentialRampToValueAtTime(120, t + 0.06);
        this.env(o, 0.16, 0.003, 0.1, 0);
        o.start(t);
        o.stop(t + 0.2);
        const s = this.noiseSrc();
        const hf = ctx.createBiquadFilter();
        hf.type = 'highpass';
        hf.frequency.value = 2400;
        this.env(s.connect(hf) as AudioNode, 0.05, 0.002, 0.06, 0);
        s.start(t);
        s.stop(t + 0.06);
        break;
      }
    }
  }
}
