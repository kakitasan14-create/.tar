// Procedural canvas textures: damp yellow wallpaper, moldy commercial carpet,
// stained ceiling tiles, light panels, entity grin, paper props and wall signs.

import * as THREE from 'three';
import { mulberry32, PeriodicNoise } from './rng';

function toTexture(c: HTMLCanvasElement, repeatX = 1, repeatY = 1): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 8;
  return t;
}

/** Data map (roughness / bump): linear color space, never sRGB. */
function toDataTexture(c: HTMLCanvasElement): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.NoColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d') as CanvasRenderingContext2D;
  return [c, ctx];
}

/** Deterministic 2-int hash for per-stitch / per-tile jitter. */
function hash2(ix: number, iy: number): number {
  const s = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

/** Color + roughness + bump, generated together so every layer agrees. */
export interface TextureSet {
  map: THREE.CanvasTexture;
  rough: THREE.CanvasTexture;
  bump: THREE.CanvasTexture;
}

export interface GameTextures {
  wallpaper: TextureSet;
  carpet: TextureSet;
  ceiling: THREE.CanvasTexture;
  lightPanel: THREE.CanvasTexture;
  grin: THREE.CanvasTexture;
  paper: THREE.CanvasTexture[];
  signs: Record<string, THREE.CanvasTexture>;
  bottleLabel: THREE.CanvasTexture;
  concrete: TextureSet;
  /** Shipping crate: aged pine planks, nails, M.E.G. supply stencil. */
  crateWood: TextureSet;
  hazard: THREE.CanvasTexture;
  /** Stairwell exit door: grey painted steel, scuffed + stenciled. */
  doorMetal: TextureSet;
  /** Party door: chipped cream paint over wood with crayon greetings. */
  doorParty: TextureSet;
  /** Soft warm radial falloff for light glow halos + floor pools. */
  glow: THREE.CanvasTexture;
}

/**
 * The canonical Level 0 wallpaper, reproduced from the real pattern: mono-yellow
 * print with wide vertical bands, thin pinstripes, dash columns and the iconic
 * double-chevron motifs staggered between the stripes. Clean print (no mold, no
 * water damage - just gentle age), three maps in one pass so color / roughness /
 * bump agree per pixel. One canvas tile covers 2.4m x 3.05m of wall.
 */
export function makeWallpaper(seed: number): TextureSet {
  const S = 1024;
  const [c, ctx] = makeCanvas(S, S);
  const [rc, rctx] = makeCanvas(S, S);
  const [bc, bctx] = makeCanvas(S, S);
  const noise = new PeriodicNoise(seed);
  const rand = mulberry32(seed ^ 0x9e3779b9);

  // ---- measured pattern geometry (reference scan mapped onto the tile) ----
  const HP = S / 6; // horizontal print period: 170.67px = 0.4m
  const VP = S / 3; // chevron column period: 341.33px, staggered half a period
  const STRIPE_W = 50; // wide band width
  const THIN0 = HP - 22, THIN1 = HP - 14; // thin pinstripe left of each band
  const DASHL0 = HP - 44, DASHL1 = HP - 30; // dash column left of each band
  const DASHR0 = 66, DASHR1 = 80; // dash column right of each band
  const CH_CX = 110; // chevron column center within the period
  const CH_HS = 45, CH_RISE = 35, CH_T = 80; // big chevron: half-span, rise, thickness
  const CH2_HS = 36, CH2_RISE = 28, CH2_T = 30, CH2_GAP = 114; // small chevron below
  const STAG = VP / 2; // stagger between adjacent columns

  // palette sampled from the real wallpaper (inks nudged darker so the print
  // keeps its presence under the dim in-game lighting)
  const BASE = [180, 176, 95];
  const INK = [156, 149, 70]; // stripes + chevrons
  const INK2 = [142, 135, 57]; // dashes + thin lines

  const img = ctx.createImageData(S, S);
  const rimg = rctx.createImageData(S, S);
  const bimg = bctx.createImageData(S, S);
  const d = img.data;
  const rd = rimg.data;
  const bd = bimg.data;

  for (let y = 0; y < S; y++) {
    const v = y / S;
    for (let x = 0; x < S; x++) {
      const u = x / S;
      const m = noise.fbm(u, v, 6, 4); // gentle age mottle
      const grain = noise.value(u, v, 240); // fine paper tooth

      // pattern space (wrapped -> seamless by construction)
      const col = Math.floor(x / HP);
      let px = x - col * HP;
      const stag = col % 2 === 1 ? STAG : 0;
      let dx = px - CH_CX;
      if (dx > HP / 2) dx -= HP;
      if (dx < -HP / 2) dx += HP;
      const adx = Math.abs(dx);

      // local phase within the chevron column period
      let ky = (y - stag) % VP;
      if (ky < 0) ky += VP;

      // ---- motif classification ----
      let ink = 0; // 1 = stripe/chevron ink, 2 = dash/thin ink
      if (px < STRIPE_W) ink = 1;
      else if (px >= THIN0 && px < THIN1) ink = 2;

      // dash columns: alternating long/short vertical dashes
      const dashCycle = 44;
      const dy = y % dashCycle;
      const longDash = dy < 26;
      const shortDash = dy >= 36 && dy < 42;
      const leftPhase = ((y + 22) % dashCycle);
      const longDashL = leftPhase < 26;
      const shortDashL = leftPhase >= 36 && leftPhase < 42;
      if (ink === 0) {
        if (px >= DASHR0 && px < DASHR1 && (longDash || shortDash)) ink = 2;
        else if (px >= DASHL0 && px < DASHL1 && (longDashL || shortDashL)) ink = 2;
      }

      // double chevron: thick V-band print (constant vertical thickness)
      // NOTE: compare LOCAL phase ky against the band edges - apex sits at ky 0
      const edge = CH_RISE * (adx / CH_HS);
      if (adx < CH_HS && ky >= edge && ky < edge + CH_T) ink = ink || 1;
      const edge2 = CH2_GAP + CH2_RISE * (adx / CH2_HS);
      if (adx < CH2_HS && ky >= edge2 && ky < edge2 + CH2_T) ink = ink || 1;

      // ---- color ----
      let tr = BASE[0];
      let tg = BASE[1];
      let tb = BASE[2];
      if (ink) {
        const src = ink === 1 ? INK : INK2;
        // slight print misregistration softening via the mottle
        tr = src[0];
        tg = src[1];
        tb = src[2];
      }
      const mb = 0.95 + m * 0.08 + grain * 0.05;
      tr *= mb;
      tg *= mb;
      tb *= mb;
      // gentle AO where wall meets ceiling; baseboard zone darkens below
      if (v < 0.06) {
        const ao = 0.86 + 0.22 * (v / 0.06);
        tr *= ao;
        tg *= ao;
        tb *= ao;
      }
      if (v > 0.9) {
        const ao = 1 - ((v - 0.9) / 0.1) * 0.18;
        tr *= ao;
        tg *= ao;
        tb *= ao;
      }

      // ---- roughness: matte paper, printed ink a touch sheenier ----
      let ro = 238 + (grain - 0.5) * 18 - (ink === 1 ? 14 : ink === 2 ? 10 : 0);

      // ---- bump: paper tooth, print sits slightly proud ----
      let bp = 120 + grain * 44 + m * 22 + (ink ? 10 : 0);

      const i = (y * S + x) * 4;
      d[i] = tr;
      d[i + 1] = tg;
      d[i + 2] = tb;
      d[i + 3] = 255;
      rd[i] = rd[i + 1] = rd[i + 2] = Math.max(0, Math.min(255, ro));
      rd[i + 3] = 255;
      bd[i] = bd[i + 1] = bd[i + 2] = Math.max(0, Math.min(255, bp));
      bd[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  rctx.putImageData(rimg, 0, 0);
  bctx.putImageData(bimg, 0, 0);

  // wallpaper roll seams every 2 print periods (0.8m rolls)
  for (let x = 0; x < S; x += S / 3) {
    ctx.fillStyle = 'rgba(40,30,8,0.22)';
    ctx.fillRect(x, 0, 2, S);
    ctx.fillStyle = 'rgba(255,240,180,0.06)';
    ctx.fillRect(x + 2, 0, 1, S);
    rctx.fillStyle = 'rgba(0,0,0,0.25)';
    rctx.fillRect(x, 0, 2, S);
    bctx.fillStyle = 'rgba(0,0,0,0.6)';
    bctx.fillRect(x, 0, 2, S);
    bctx.fillStyle = 'rgba(255,255,255,0.2)';
    bctx.fillRect(x + 2, 0, 1, S);
  }
  // faint horizontal roll splice
  ctx.fillStyle = 'rgba(40,30,8,0.1)';
  ctx.fillRect(0, S >> 1, S, 1);
  bctx.fillStyle = 'rgba(0,0,0,0.26)';
  bctx.fillRect(0, S >> 1, S, 1);

  // light scuffs near the floor (age, not stains)
  for (let i = 0; i < 40; i++) {
    const y = S - 40 - rand() * 260;
    const x = rand() * S;
    const w = 12 + rand() * 60;
    const light = rand() > 0.45;
    ctx.fillStyle = light ? `rgba(214,196,132,${0.06 + rand() * 0.1})` : `rgba(46,36,12,${0.07 + rand() * 0.13})`;
    ctx.fillRect(x, y, w, 1 + rand() * 1.4);
    bctx.fillStyle = `rgba(255,255,255,${light ? 0.16 : 0.08})`;
    bctx.fillRect(x, y, w, 1.3);
  }

  // scuffed baseboard (canvas bottom = wall bottom)
  const B0 = S - 34;
  ctx.fillStyle = '#6a5a28';
  ctx.fillRect(0, B0, S, 34);
  for (let i = 0; i < 70; i++) {
    ctx.fillStyle = `rgba(30,22,6,${0.07 + rand() * 0.14})`;
    ctx.fillRect(rand() * S, B0 + rand() * 34, 1.4, 8 + rand() * 26);
  }
  ctx.fillStyle = 'rgba(0,0,0,0.42)';
  ctx.fillRect(0, B0, S, 3);
  ctx.fillStyle = 'rgba(255,235,170,0.16)';
  ctx.fillRect(0, B0 + 3, S, 2);
  for (let i = 0; i < 26; i++) {
    // paint chips
    ctx.fillStyle = `rgba(158,138,86,${0.5 + rand() * 0.4})`;
    ctx.fillRect(rand() * S, B0 + 4 + rand() * 26, 1.5 + rand() * 3, 1.5 + rand() * 2.5);
  }
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = `rgba(16,11,3,${0.16 + rand() * 0.26})`;
    ctx.fillRect(rand() * S, B0 + rand() * 33, 2 + rand() * 10, 1.5);
  }
  rctx.fillStyle = 'rgba(140,140,140,1)';
  rctx.fillRect(0, B0, S, 34);
  bctx.fillStyle = 'rgba(150,150,150,1)';
  bctx.fillRect(0, B0 + 4, S, 30);
  bctx.fillStyle = 'rgba(255,255,255,0.85)';
  bctx.fillRect(0, B0, S, 3);
  bctx.fillStyle = 'rgba(0,0,0,0.9)';
  bctx.fillRect(0, B0 - 2, S, 2);

  return { map: toTexture(c), rough: toDataTexture(rc), bump: toDataTexture(bc) };
}

/**
 * Clean commercial carpet, three maps in one pass: a real per-stitch knit weave
 * (offset rows of knots with per-knot dye lots), carpet-tile quadrants, broad
 * tonal drift and gentle traffic wear. No stains, no blotches, no debris -
 * just well-kept 1996 office carpet that still catches the light pools.
 */
export function makeCarpet(seed: number): TextureSet {
  const S = 1024;
  const [c, ctx] = makeCanvas(S, S);
  const [rc, rctx] = makeCanvas(S, S);
  const [bc, bctx] = makeCanvas(S, S);
  const noise = new PeriodicNoise(seed + 77);

  const img = ctx.createImageData(S, S);
  const rimg = rctx.createImageData(S, S);
  const bimg = bctx.createImageData(S, S);
  const d = img.data;
  const rd = rimg.data;
  const bd = bimg.data;

  const CW = 4; // stitch width px
  const CH = 6; // stitch height px

  for (let y = 0; y < S; y++) {
    const v = y / S;
    const row = Math.floor(y / CH);
    const oy = y - row * CH;
    const fy = oy / CH;
    for (let x = 0; x < S; x++) {
      const u = x / S;
      const ox = (row % 2) * (CW / 2); // offset knit rows
      const sx = x + ox;
      const col = Math.floor(sx / CW);
      const fx = (sx - col * CW) / CW;
      const knot = Math.sin(fx * Math.PI) * Math.sin(fy * Math.PI); // dome profile
      const ktone = hash2(col, row); // per-knot dye lot
      const fiber = noise.fbm(u, v, 110, 2);
      const drift = noise.fbm(u + 0.23, v + 0.11, 3, 2); // broad tonal drift
      const tq = hash2(Math.floor(u * 2) + 7, Math.floor(v * 2) + 13); // carpet tile quadrant

      let tone = (0.76 + ktone * 0.32) * (0.68 + 0.5 * knot) * (0.86 + fiber * 0.26) * (0.95 + tq * 0.1);
      tone *= 0.97 + drift * 0.06; // gentle large-scale shading, not a stain
      let r = 122 * tone;
      let g = 109 * tone * 0.99;
      let b = 58 * tone * 0.92;

      // traffic wear: two broad, very subtle lightened corridors
      const w1 = Math.exp(-Math.pow((u - v * 0.7 - 0.22) * 3.0, 2));
      const w2 = Math.exp(-Math.pow((u - v * 0.7 - 0.78) * 3.0, 2));
      const wear = (w1 + w2) * 0.05;
      r *= 1 + wear;
      g *= 1 + wear;
      b *= 1 + wear * 1.5;

      let ro = 246 - fiber * 12 - wear * 60 + (drift - 0.5) * 16;
      let bp = 84 + knot * 112 + ktone * 30 + fiber * 26;

      const i = (y * S + x) * 4;
      d[i] = r;
      d[i + 1] = g;
      d[i + 2] = b;
      d[i + 3] = 255;
      rd[i] = rd[i + 1] = rd[i + 2] = Math.max(0, Math.min(255, ro));
      rd[i + 3] = 255;
      bd[i] = bd[i + 1] = bd[i + 2] = Math.max(0, Math.min(255, bp));
      bd[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  rctx.putImageData(rimg, 0, 0);
  bctx.putImageData(bimg, 0, 0);

  return { map: toTexture(c), rough: toDataTexture(rc), bump: toDataTexture(bc) };
}

/** Acoustic drop-ceiling tiles: 2x2 tiles per texture, seams, water rings, speckles. */
export function makeCeiling(seed: number): THREE.CanvasTexture {
  const S = 512;
  const T = S / 2;
  const [c, ctx] = makeCanvas(S, S);
  const rand = mulberry32(seed ^ 0x55aa11);

  ctx.fillStyle = '#cdc6ad';
  ctx.fillRect(0, 0, S, S);

  // Acoustic speckles
  for (let i = 0; i < 2600; i++) {
    const x = rand() * S;
    const y = rand() * S;
    ctx.fillStyle = rand() > 0.5 ? 'rgba(90,84,64,0.35)' : 'rgba(240,234,210,0.3)';
    ctx.fillRect(x, y, 1.6, 1.6);
  }

  // Water stain rings on ~2 random tiles
  for (let k = 0; k < 3; k++) {
    const tx = Math.floor(rand() * 2) * T;
    const ty = Math.floor(rand() * 2) * T;
    const cx = tx + T * (0.3 + rand() * 0.4);
    const cy = ty + T * (0.3 + rand() * 0.4);
    const rings = 2 + Math.floor(rand() * 3);
    for (let r = 0; r < rings; r++) {
      const rad = 18 + r * (14 + rand() * 12);
      ctx.strokeStyle = `rgba(122,92,40,${0.16 + rand() * 0.12})`;
      ctx.lineWidth = 2 + rand() * 3;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rad, rad * (0.7 + rand() * 0.3), rand() * 3, 0, Math.PI * 2);
      ctx.stroke();
    }
    const g = ctx.createRadialGradient(cx, cy, 4, cx, cy, 60);
    g.addColorStop(0, 'rgba(110,82,36,0.22)');
    g.addColorStop(1, 'rgba(110,82,36,0)');
    ctx.fillStyle = g;
    ctx.fillRect(tx, ty, T, T);
  }

  // Tile seams + soft bevel
  for (let i = 0; i <= 2; i++) {
    const p = i * T;
    ctx.fillStyle = 'rgba(60,56,44,0.85)';
    ctx.fillRect(p - 2, 0, 4, S);
    ctx.fillRect(0, p - 2, S, 4);
    ctx.fillStyle = 'rgba(255,250,230,0.16)';
    ctx.fillRect(p + 2, 0, 2, S);
    ctx.fillRect(0, p + 2, S, 2);
  }

  return toTexture(c);
}

/**
 * Poured concrete for The Hub's tunnels: warm gray with formwork panel seams,
 * tie holes, hairline cracks and gentle mottling. Clean (no grime - the Hub is
 * maintained), three maps in one pass. One tile covers 2.2m x 2.2m.
 */
export function makeConcrete(seed: number): TextureSet {
  const S = 512;
  const [c, ctx] = makeCanvas(S, S);
  const [rc, rctx] = makeCanvas(S, S);
  const [bc, bctx] = makeCanvas(S, S);
  const noise = new PeriodicNoise(seed + 431);

  const img = ctx.createImageData(S, S);
  const rimg = rctx.createImageData(S, S);
  const bimg = bctx.createImageData(S, S);
  const d = img.data;
  const rd = rimg.data;
  const bd = bimg.data;

  // formwork seam positions (u,v in 0..1, wraps at 0 and 0.5)
  const seamDist = (p: number): number => {
    const m = Math.abs(((p % 0.5) + 0.5) % 0.5); // distance below the next seam
    return Math.min(m, 0.5 - m);
  };
  // tie holes inset from the panel corners
  const ties: [number, number][] = [
    [0.115, 0.115],
    [0.615, 0.115],
    [0.115, 0.615],
    [0.615, 0.615],
  ];

  for (let y = 0; y < S; y++) {
    const v = y / S;
    for (let x = 0; x < S; x++) {
      const u = x / S;
      const grain = noise.fbm(u, v, 90, 2); // fine aggregate grain
      const mottle = noise.fbm(u + 0.31, v + 0.53, 5, 3); // broad tonal drift

      // base concrete tone
      let tone = 0.9 + grain * 0.14 + mottle * 0.12;
      let r = 128 * tone;
      let g = 124 * tone;
      let b = 112 * tone;

      // formwork seams: dark groove + slight ridge just beside it
      const su = seamDist(u);
      const sv = seamDist(v);
      const seam = Math.min(su, sv);
      const groove = Math.exp(-Math.pow(seam * S * 1.35, 2)); // ~4px groove
      const ridge = Math.exp(-Math.pow((seam * S - 7) * 0.55, 2)); // proud edge ~7px away
      r *= 1 - groove * 0.42 + ridge * 0.06;
      g *= 1 - groove * 0.42 + ridge * 0.06;
      b *= 1 - groove * 0.44 + ridge * 0.06;

      // tie holes: dark circular depressions with a faint cone shadow
      let tie = 0;
      for (const [tu, tv] of ties) {
        const dx = u - tu;
        const dy = v - tv;
        const dist = Math.sqrt(dx * dx + dy * dy) * S;
        tie = Math.max(tie, Math.exp(-Math.pow(dist * 0.55, 2)));
      }
      r *= 1 - tie * 0.55;
      g *= 1 - tie * 0.55;
      b *= 1 - tie * 0.55;

      // maps: matte concrete with patchy sheen variation
      const ro = 196 + grain * 26 + mottle * 18 - ridge * 22 - tie * 30;
      const bp = 118 + grain * 66 - groove * 90 - tie * 110 + ridge * 30;

      const i = (y * S + x) * 4;
      d[i] = r;
      d[i + 1] = g;
      d[i + 2] = b;
      d[i + 3] = 255;
      rd[i] = rd[i + 1] = rd[i + 2] = Math.max(0, Math.min(255, ro));
      rd[i + 3] = 255;
      bd[i] = bd[i + 1] = bd[i + 2] = Math.max(0, Math.min(255, bp));
      bd[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  rctx.putImageData(rimg, 0, 0);
  bctx.putImageData(bimg, 0, 0);

  // hairline cracks: short dark random-walk strokes on color + bump
  const rand = mulberry32(seed ^ 0xc0ac);
  for (let k = 0; k < 7; k++) {
    let x = rand() * S;
    let y = rand() * S;
    let ang = rand() * Math.PI * 2;
    ctx.strokeStyle = 'rgba(58,54,48,0.5)';
    bctx.strokeStyle = 'rgba(30,30,30,0.85)';
    ctx.lineWidth = 1;
    bctx.lineWidth = 1.4;
    ctx.beginPath();
    bctx.beginPath();
    ctx.moveTo(x, y);
    bctx.moveTo(x, y);
    const segs = 10 + Math.floor(rand() * 18);
    for (let s2 = 0; s2 < segs; s2++) {
      ang += (rand() - 0.5) * 1.1;
      x += Math.cos(ang) * 7;
      y += Math.sin(ang) * 7;
      ctx.lineTo(x, y);
      bctx.lineTo(x, y);
    }
    ctx.stroke();
    bctx.stroke();
  }

  return { map: toTexture(c), rough: toDataTexture(rc), bump: toDataTexture(bc) };
}

/**
 * Shipping-crate plywood: weathered pine planks with long grain streaks, dark
 * seam gaps, rusted nails at the plank ends, corner chafing, one faint water
 * ring and a worn M.E.G. supply stencil. Three maps in one pass so color /
 * roughness / bump agree per pixel. One tile covers a single crate face (the
 * crates map it 1:1 per side).
 */
export function makeCrateWood(seed: number): TextureSet {
  const S = 256;
  const [c, ctx] = makeCanvas(S, S);
  const [rc, rctx] = makeCanvas(S, S);
  const [bc, bctx] = makeCanvas(S, S);
  const noise = new PeriodicNoise(seed + 917);
  const rand = mulberry32(seed ^ 0xca7e);

  // 4 horizontal pine boards; seams land on the tile edges so it wraps clean
  const PLANKS = 4;
  const PH = S / PLANKS;
  const plankTone: number[] = [];
  for (let p = 0; p < PLANKS; p++) plankTone.push(0.92 + rand() * 0.16);

  const img = ctx.createImageData(S, S);
  const rimg = rctx.createImageData(S, S);
  const bimg = bctx.createImageData(S, S);
  const d = img.data;
  const rd = rimg.data;
  const bd = bimg.data;

  for (let y = 0; y < S; y++) {
    const v = y / S;
    const plank = Math.min(PLANKS - 1, (y / PH) | 0);
    const inPlank = y - plank * PH;
    const edge = Math.min(inPlank, PH - inPlank); // px to the nearest seam
    for (let x = 0; x < S; x++) {
      const u = x / S;
      const mottle = noise.fbm(u, v, 5, 3); // broad tonal drift
      const streak = noise.fbm(u, v * 8, 6, 3); // long horizontal grain
      const tooth = noise.fbm(u, v * 24, 16, 2); // fine fiber tooth

      // warm aged pine (base #8a7148): plank-to-plank tone + grain variation
      const tone =
        plankTone[plank] *
        (0.9 + mottle * 0.14 + (streak - 0.5) * 0.2 + (tooth - 0.5) * 0.07);
      let r = 138 * tone;
      let g = 113 * tone;
      let b = 72 * tone;

      // plank seams: dark groove that wraps at the tile edge, chamfer beside it
      const gap = Math.exp(-Math.pow(edge * 0.85, 2));
      const ridge = Math.exp(-Math.pow((edge - 5) * 0.6, 2));
      r *= 1 - gap * 0.5 + ridge * 0.05;
      g *= 1 - gap * 0.5 + ridge * 0.05;
      b *= 1 - gap * 0.54 + ridge * 0.05;

      // matte aged wood; grain grooves read slightly rougher
      const ro = 200 + (mottle - 0.5) * 26 + (tooth - 0.5) * 16 + gap * 18;
      const bp = 122 + (streak - 0.5) * 56 + (tooth - 0.5) * 40 - gap * 105 + ridge * 26;

      const i = (y * S + x) * 4;
      d[i] = r;
      d[i + 1] = g;
      d[i + 2] = b;
      d[i + 3] = 255;
      rd[i] = rd[i + 1] = rd[i + 2] = Math.max(0, Math.min(255, ro));
      rd[i + 3] = 255;
      bd[i] = bd[i + 1] = bd[i + 2] = Math.max(0, Math.min(255, bp));
      bd[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  rctx.putImageData(rimg, 0, 0);
  bctx.putImageData(bimg, 0, 0);

  // crisp seam lines over the soft loop grooves (top edge wraps to the bottom)
  for (let p = 0; p < PLANKS; p++) {
    const yb = p * PH;
    ctx.fillStyle = 'rgba(24,16,7,0.5)';
    ctx.fillRect(0, yb - 1, S, 2);
    ctx.fillStyle = 'rgba(255,232,190,0.07)';
    ctx.fillRect(0, yb + 1, S, 1);
    bctx.fillStyle = 'rgba(0,0,0,0.75)';
    bctx.fillRect(0, yb - 1, S, 2);
    bctx.fillStyle = 'rgba(255,255,255,0.22)';
    bctx.fillRect(0, yb + 1, S, 1);
  }

  // rusted nail heads near the plank ends: pressed ring, rusty steel, glint
  for (let p = 0; p < PLANKS; p++) {
    const cy = p * PH + PH / 2 + (rand() - 0.5) * 8;
    for (const nx of [11 + rand() * 4, S - 15 + rand() * 4]) {
      ctx.fillStyle = 'rgba(30,22,12,0.55)';
      ctx.beginPath();
      ctx.arc(nx, cy, 3.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = `rgb(${Math.floor(96 + rand() * 26)},${Math.floor(74 + rand() * 20)},${Math.floor(48 + rand() * 14)})`;
      ctx.beginPath();
      ctx.arc(nx, cy, 2.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(235,228,210,0.75)';
      ctx.beginPath();
      ctx.arc(nx - 0.8, cy - 0.8, 0.9, 0, Math.PI * 2);
      ctx.fill();
      bctx.fillStyle = 'rgba(255,255,255,0.9)'; // nails sit proud
      bctx.beginPath();
      bctx.arc(nx, cy, 2.4, 0, Math.PI * 2);
      bctx.fill();
      rctx.fillStyle = 'rgba(120,120,120,0.8)'; // bare metal: shinier
      rctx.beginPath();
      rctx.arc(nx, cy, 2.3, 0, Math.PI * 2);
      rctx.fill();
    }
  }

  // corner chafing: abraded pale raw-wood specks, some grime, slightly shinier
  const chafe = (cx: number, cy: number, spread: number, n: number): void => {
    for (let i = 0; i < n; i++) {
      const x = cx + (rand() - 0.5) * spread;
      const y = cy + (rand() - 0.5) * spread * 0.7;
      const w = 1 + rand() * 3;
      const h = 1 + rand() * 1.6;
      if (rand() < 0.72) {
        ctx.fillStyle = `rgba(214,196,158,${0.06 + rand() * 0.14})`;
        ctx.fillRect(x, y, w, h);
        bctx.fillStyle = `rgba(255,255,255,${0.06 + rand() * 0.1})`;
        bctx.fillRect(x, y, w * 0.8, h);
      } else {
        ctx.fillStyle = `rgba(52,40,22,${0.08 + rand() * 0.12})`;
        ctx.fillRect(x, y, w, h);
      }
      rctx.fillStyle = `rgba(130,130,130,${0.12 + rand() * 0.2})`;
      rctx.fillRect(x, y, w, h);
    }
  };
  chafe(6, 6, 46, 60);
  chafe(S - 6, 6, 46, 60);
  chafe(6, S - 6, 46, 60);
  chafe(S - 6, S - 6, 46, 60);

  // one faint dark water ring stain (tide line + translucent interior)
  const wx = 150 + rand() * 70;
  const wy = 140 + rand() * 80;
  const wr = 20 + rand() * 12;
  ctx.strokeStyle = 'rgba(66,48,22,0.22)';
  ctx.lineWidth = 3 + rand() * 3;
  ctx.beginPath();
  ctx.ellipse(wx, wy, wr, wr * (0.72 + rand() * 0.3), rand() * Math.PI, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = 'rgba(66,48,22,0.07)';
  ctx.beginPath();
  ctx.ellipse(wx, wy, wr, wr * 0.85, 0, 0, Math.PI * 2);
  ctx.fill();
  rctx.strokeStyle = 'rgba(150,150,150,0.3)'; // tide line a touch glossier
  rctx.lineWidth = 4;
  rctx.beginPath();
  rctx.arc(wx, wy, wr, 0, Math.PI * 2);
  rctx.stroke();
  bctx.strokeStyle = 'rgba(0,0,0,0.18)';
  bctx.lineWidth = 4;
  bctx.beginPath();
  bctx.arc(wx, wy, wr, 0, Math.PI * 2);
  bctx.stroke();

  // worn M.E.G. supply stencil: arrow up + THIS SIDE UP + corner code. Speckle
  // erosion via destination-out like the door stencil (opaque materials ignore
  // the punched alpha, the ink RGB is what gets chewed up).
  const stencilRects: [number, number, number, number][] = [];
  for (let i = 0; i < 150; i++) {
    stencilRects.push([rand() * S, 78 + rand() * 92, 1 + rand() * 3, 1 + rand() * 2.4]);
  }
  for (let i = 0; i < 44; i++) {
    stencilRects.push([6 + rand() * 100, S - 26 + rand() * 18, 1 + rand() * 2.5, 1 + rand() * 2]);
  }
  const stencilShape = (g: CanvasRenderingContext2D): void => {
    g.beginPath();
    g.moveTo(S / 2, 140);
    g.lineTo(S / 2, 102);
    g.stroke();
    g.beginPath();
    g.moveTo(S / 2 - 14, 112);
    g.lineTo(S / 2, 88);
    g.lineTo(S / 2 + 14, 112);
    g.closePath();
    g.fill();
    g.font = 'bold 17px "Courier New", monospace';
    g.textAlign = 'center';
    g.textBaseline = 'alphabetic';
    g.fillText('THIS SIDE UP', S / 2, 168);
    g.font = 'bold 11px "Courier New", monospace';
    g.textAlign = 'left';
    g.fillText('M.E.G. SUPPLY 12', 10, S - 12);
  };
  const stampStencil = (
    g: CanvasRenderingContext2D,
    ink: string,
    alpha: number
  ): void => {
    g.save();
    g.globalAlpha = alpha;
    g.fillStyle = ink;
    g.strokeStyle = ink;
    g.lineWidth = 7;
    stencilShape(g);
    g.globalCompositeOperation = 'destination-out';
    g.globalAlpha = 1;
    for (const [ex, ey, ew, eh] of stencilRects) g.fillRect(ex, ey, ew, eh);
    g.restore();
  };
  stampStencil(ctx, '#32291c', 0.55); // worn dark paint
  stampStencil(bctx, '#ffffff', 0.16); // ink sits a hair proud
  stampStencil(rctx, '#5a5a5a', 0.45); // paint sheens off the raw wood

  return { map: toTexture(c), rough: toDataTexture(rc), bump: toDataTexture(bc) };
}

/** Yellow/black hazard chevron strip for the freight lift frame. */
export function makeHazard(): THREE.CanvasTexture {
  const S = 128;
  const [c, ctx] = makeCanvas(S, S);
  ctx.fillStyle = '#17150f';
  ctx.fillRect(0, 0, S, S);
  ctx.fillStyle = '#c7a832';
  const W = 26;
  for (let i = -S; i < S * 2; i += W * 2) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + W, 0);
    ctx.lineTo(i + W - S, S);
    ctx.lineTo(i - S, S);
    ctx.closePath();
    ctx.fill();
  }
  // scuff the paint a little
  const rand = mulberry32(0x4a7a);
  for (let i = 0; i < 240; i++) {
    ctx.fillStyle = rand() > 0.5 ? 'rgba(23,21,15,0.25)' : 'rgba(199,168,50,0.18)';
    ctx.fillRect(rand() * S, rand() * S, 2.5, 1.5);
  }
  return toTexture(c);
}

/**
 * Soft warm radial falloff used by the lighting rig: panel glow halos, floor
 * light pools and ceiling spill. Hot core -> wide feathered edge.
 */
export function makeGlow(): THREE.CanvasTexture {
  const S = 256;
  const [c, ctx] = makeCanvas(S, S);
  const g = ctx.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,246,222,1)');
  g.addColorStop(0.22, 'rgba(255,240,205,0.82)');
  g.addColorStop(0.45, 'rgba(255,232,185,0.4)');
  g.addColorStop(0.7, 'rgba(250,222,168,0.13)');
  g.addColorStop(1, 'rgba(240,210,150,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  // faint dithering so the additive blend never bands
  for (let i = 0; i < 2200; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * (S / 2);
    ctx.fillStyle = `rgba(255,240,210,${0.015 + Math.random() * 0.02})`;
    ctx.fillRect(S / 2 + Math.cos(a) * r, S / 2 + Math.sin(a) * r, 1.4, 1.4);
  }
  return toTexture(c);
}

/** Fluorescent light panel face (prismatic diffuser with two tube hot-spots). */
export function makeLightPanel(seed: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 128);
  const rand = mulberry32(seed ^ 0xf11e);

  const g = ctx.createLinearGradient(0, 0, 0, 128);
  g.addColorStop(0, '#efe7c8');
  g.addColorStop(0.5, '#fff8dd');
  g.addColorStop(1, '#efe7c8');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 128);

  for (const cx of [64, 192]) {
    const tg = ctx.createLinearGradient(cx - 40, 0, cx + 40, 0);
    tg.addColorStop(0, 'rgba(255,255,240,0)');
    tg.addColorStop(0.5, 'rgba(255,255,250,0.95)');
    tg.addColorStop(1, 'rgba(255,255,240,0)');
    ctx.fillStyle = tg;
    ctx.fillRect(cx - 40, 14, 80, 100);
  }
  // diffusion grid
  ctx.strokeStyle = 'rgba(160,150,110,0.18)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= 256; x += 12) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 128);
    ctx.stroke();
  }
  for (let y = 0; y <= 128; y += 12) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
  }
  // frame
  ctx.strokeStyle = '#6f6a58';
  ctx.lineWidth = 8;
  ctx.strokeRect(0, 0, 256, 128);
  if (rand() > 2) ctx.fillRect(0, 0, 1, 1); // keep rand referenced

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** The Smiler: pitch dark face with an over-wide glowing crescent grin and eye slits. */
export function makeGrin(): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, 256, 256);

  ctx.shadowColor = 'rgba(255,255,240,0.9)';
  ctx.shadowBlur = 18;
  ctx.strokeStyle = '#f5f2e0';
  ctx.lineWidth = 11;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(128, 118, 74, 0.18 * Math.PI, 0.82 * Math.PI);
  ctx.stroke();
  // teeth notches
  ctx.shadowBlur = 6;
  ctx.strokeStyle = 'rgba(0,0,0,0.85)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 9; i++) {
    const a = 0.22 * Math.PI + (i / 8) * 0.56 * Math.PI;
    const x1 = 128 + Math.cos(a) * 62;
    const y1 = 118 + Math.sin(a) * 62;
    const x2 = 128 + Math.cos(a) * 86;
    const y2 = 118 + Math.sin(a) * 86;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }
  // eyes: thin slits
  ctx.shadowBlur = 14;
  ctx.strokeStyle = '#f5f2e0';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(76, 66);
  ctx.lineTo(112, 74);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(180, 66);
  ctx.lineTo(144, 74);
  ctx.stroke();
  ctx.shadowBlur = 0;

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** A scribbled page prop (unreadable handwriting squiggles + stains). */
export function makePaper(seed: number): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(256, 340);
  const rand = mulberry32(seed ^ 0xabe1);

  ctx.fillStyle = '#e6dfc8';
  ctx.fillRect(0, 0, 256, 340);
  for (let i = 0; i < 5; i++) {
    const x = rand() * 256;
    const y = rand() * 340;
    const r = 12 + rand() * 40;
    const g = ctx.createRadialGradient(x, y, 2, x, y, r);
    g.addColorStop(0, 'rgba(120,96,40,0.2)');
    g.addColorStop(1, 'rgba(120,96,40,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // squiggle lines of "handwriting"
  let y = 44;
  while (y < 310) {
    const indent = 14 + rand() * 30;
    const w = 228 - indent - rand() * 60;
    ctx.strokeStyle = 'rgba(40,34,26,0.85)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    let x = indent;
    ctx.moveTo(x, y);
    while (x < indent + w) {
      x += 4 + rand() * 5;
      ctx.lineTo(x, y + (rand() - 0.5) * 5);
    }
    ctx.stroke();
    y += 17 + rand() * 7;
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Marker-pen wall sign with transparent background. */
export function makeSign(text: string, color: string, big = false): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(512, 256);
  ctx.clearRect(0, 0, 512, 256);
  ctx.fillStyle = color;
  ctx.font = `bold ${big ? 120 : 72}px "Courier New", monospace`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.5)';
  ctx.shadowBlur = 4;
  const lines = text.split('\n');
  lines.forEach((ln, i) => {
    ctx.fillText(ln, 256, 128 + (i - (lines.length - 1) / 2) * (big ? 128 : 84));
  });
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/**
 * Stairwell exit door: institutional grey painted steel. Brushed streaks,
 * paint chips over dark primer, scuff arcs, rust bleeding from the bottom,
 * faded stencil lettering and a darker push zone. 512x1024 covers 1.14x2.2m.
 */
export function makeDoorMetal(seed: number): TextureSet {
  const W = 512;
  const H = 1024;
  const [c, ctx] = makeCanvas(W, H);
  const [bc, bctx] = makeCanvas(W, H);
  const [rc, rctx] = makeCanvas(W, H);
  const rand = mulberry32(seed ^ 0xd00b);

  // base coat
  const base = ctx.createLinearGradient(0, 0, W, 0);
  base.addColorStop(0, '#4c5357');
  base.addColorStop(0.5, '#565e63');
  base.addColorStop(1, '#474e52');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, W, H);
  bctx.fillStyle = '#7a7a7a';
  bctx.fillRect(0, 0, W, H);
  rctx.fillStyle = '#b8b8b8';
  rctx.fillRect(0, 0, W, H);

  // vertical brushed streaks
  for (let i = 0; i < 220; i++) {
    const x = rand() * W;
    const y = rand() * H;
    const len = 30 + rand() * 150;
    const a = rand() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.045)';
    ctx.strokeStyle = a;
    ctx.lineWidth = 1 + rand() * 1.5;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rand() - 0.5) * 6, y + len);
    ctx.stroke();
  }

  // panel seams: two recessed panels like a flush steel door
  const panel = (x0: number, y0: number, x1: number, y1: number): void => {
    ctx.strokeStyle = 'rgba(0,0,0,0.28)';
    ctx.lineWidth = 4;
    ctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
    ctx.strokeStyle = 'rgba(255,255,255,0.10)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x0 + 4, y0 + 4, x1 - x0 - 8, y1 - y0 - 8);
    bctx.strokeStyle = '#2a2a2a';
    bctx.lineWidth = 6;
    bctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
  };
  panel(64, 92, W - 64, 470);
  panel(64, 520, W - 64, 810);

  // paint chips: primer/dark metal showing at edges + random clusters
  const chip = (x: number, y: number, r: number): void => {
    ctx.fillStyle = `rgba(30,32,34,${0.5 + rand() * 0.4})`;
    ctx.beginPath();
    const pts = 5 + ((rand() * 3) | 0);
    for (let i = 0; i < pts; i++) {
      const a = (i / pts) * Math.PI * 2;
      const rr = r * (0.6 + rand() * 0.7);
      const px = x + Math.cos(a) * rr;
      const py = y + Math.sin(a) * rr * 0.8;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    bctx.fillStyle = '#3a3a3a';
    bctx.beginPath();
    bctx.arc(x, y, r * 0.9, 0, Math.PI * 2);
    bctx.fill();
    rctx.fillStyle = '#e8e8e8';
    rctx.beginPath();
    rctx.arc(x, y, r, 0, Math.PI * 2);
    rctx.fill();
  };
  for (let i = 0; i < 26; i++) chip(rand() * W, 810 + rand() * 190, 3 + rand() * 9); // bottom wear band
  for (let i = 0; i < 14; i++) chip(30 + rand() * 60, 120 + rand() * 800, 2 + rand() * 6); // edge chips
  for (let i = 0; i < 10; i++) chip(W - 30 - rand() * 60, 120 + rand() * 800, 2 + rand() * 6);

  // scuff arcs (shoe kicks at push height, cart scrapes low)
  for (let i = 0; i < 16; i++) {
    const y = 620 + rand() * 380;
    ctx.strokeStyle = `rgba(${rand() < 0.5 ? '220,220,215' : '20,20,20'},${0.08 + rand() * 0.14})`;
    ctx.lineWidth = 2 + rand() * 4;
    ctx.beginPath();
    ctx.ellipse(140 + rand() * 240, y, 18 + rand() * 46, 5 + rand() * 12, (rand() - 0.5) * 0.7, 0, Math.PI * 2);
    ctx.stroke();
  }

  // rust streaks from the bottom hem + a couple of rivet heads
  for (let i = 0; i < 14; i++) {
    const x = rand() * W;
    const w0 = 3 + rand() * 9;
    const g = ctx.createLinearGradient(0, H - 200 - rand() * 60, 0, H);
    g.addColorStop(0, 'rgba(96,52,24,0)');
    g.addColorStop(1, `rgba(${92 + rand() * 30 | 0},${44 + rand() * 18 | 0},18,${0.28 + rand() * 0.3})`);
    ctx.fillStyle = g;
    ctx.fillRect(x, H - 260, w0, 260);
  }
  for (const [rx, ry] of [[24, 40], [W - 24, 40], [24, H - 40], [W - 24, H - 40]]) {
    ctx.fillStyle = '#3b4145';
    ctx.beginPath();
    ctx.arc(rx, ry, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(rx - 1.5, ry - 1.5, 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // faded stencil: E7 on the upper panel + ARROW
  ctx.save();
  ctx.globalAlpha = 0.5;
  ctx.fillStyle = '#d8d4c4';
  ctx.font = 'bold 150px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('E7', W / 2, 340);
  // stencil gaps across the letters
  ctx.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 5; i++) ctx.fillRect(W / 2 - 90, 240 + i * 34, 180, 9);
  ctx.globalCompositeOperation = 'source-over';
  ctx.restore();

  // grime at the hem + a dirty halo around the push zone
  const grime = ctx.createLinearGradient(0, H - 220, 0, H);
  grime.addColorStop(0, 'rgba(20,16,10,0)');
  grime.addColorStop(1, 'rgba(20,16,10,0.4)');
  ctx.fillStyle = grime;
  ctx.fillRect(0, H - 220, W, 220);
  const pushGlow = ctx.createRadialGradient(W / 2, 700, 20, W / 2, 700, 190);
  pushGlow.addColorStop(0, 'rgba(35,32,28,0.34)');
  pushGlow.addColorStop(1, 'rgba(35,32,28,0)');
  ctx.fillStyle = pushGlow;
  ctx.fillRect(W / 2 - 200, 520, 400, 380);

  // bump: seams push out, chips/recesses push in
  bctx.globalAlpha = 1;

  return {
    map: toTexture(c),
    bump: toDataTexture(bc),
    rough: toDataTexture(rc),
  };
}

/**
 * Party door: cream-yellow painted wood gone shabby. Wood grain under chipped
 * paint, wobbly crayon doodles, a big red "=)" and party grime. 512x1024.
 */
export function makeDoorParty(seed: number): TextureSet {
  const W = 512;
  const H = 1024;
  const [c, ctx] = makeCanvas(W, H);
  const [bc, bctx] = makeCanvas(W, H);
  const [rc, rctx] = makeCanvas(W, H);
  const rand = mulberry32(seed ^ 0xf00d2d);

  // wood base
  ctx.fillStyle = '#6b4f30';
  ctx.fillRect(0, 0, W, H);
  bctx.fillStyle = '#8a8a8a';
  bctx.fillRect(0, 0, W, H);
  rctx.fillStyle = '#cfcfcf';
  rctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 130; i++) {
    const x = rand() * W;
    ctx.strokeStyle = `rgba(${40 + rand() * 30 | 0},${28 + rand() * 20 | 0},12,${0.16 + rand() * 0.2})`;
    ctx.lineWidth = 1 + rand() * 3;
    ctx.beginPath();
    ctx.moveTo(x, -10);
    let cy = -10;
    let cx = x;
    while (cy < H + 10) {
      cy += 40 + rand() * 60;
      cx += (rand() - 0.5) * 14;
      ctx.lineTo(cx, cy);
    }
    ctx.stroke();
    bctx.strokeStyle = 'rgba(60,60,60,0.35)';
    bctx.lineWidth = 1.5;
    bctx.beginPath();
    bctx.moveTo(x, 0);
    bctx.lineTo(x + (rand() - 0.5) * 8, H);
    bctx.stroke();
  }

  // chipped cream paint: layered strokes so grain ghosts through
  const paintLayer = (col: string, alpha: number, n: number): void => {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = col;
    for (let i = 0; i < n; i++) {
      const x = rand() * W;
      const y = rand() * H;
      const w0 = 30 + rand() * 90;
      const h0 = 60 + rand() * 200;
      ctx.beginPath();
      ctx.ellipse(x, y, w0 / 2, h0 / 2, (rand() - 0.5) * 0.3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  };
  paintLayer('#d3b84a', 0.85, 60);
  paintLayer('#dcc458', 0.75, 50);

  // chips: paint missing -> wood shows
  const chip = (x: number, y: number, r: number): void => {
    ctx.fillStyle = 'rgba(96,70,40,0.9)';
    ctx.beginPath();
    const pts = 5 + ((rand() * 4) | 0);
    for (let i = 0; i < pts; i++) {
      const a = (i / pts) * Math.PI * 2;
      const rr = r * (0.5 + rand() * 0.8);
      ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.85);
    }
    ctx.closePath();
    ctx.fill();
    bctx.fillStyle = '#4a4a4a';
    bctx.beginPath();
    bctx.arc(x, y, r, 0, Math.PI * 2);
    bctx.fill();
    rctx.fillStyle = '#e0e0e0';
    rctx.beginPath();
    rctx.arc(x, y, r * 1.2, 0, Math.PI * 2);
    rctx.fill();
  };
  for (let i = 0; i < 34; i++) chip(rand() * W, 800 + rand() * 220, 3 + rand() * 10);
  for (let i = 0; i < 18; i++) chip(rand() * W, rand() * 500, 2 + rand() * 6);
  for (let i = 0; i < 10; i++) chip(20 + rand() * 50, 100 + rand() * 860, 2 + rand() * 7);

  // two recessed panels (painted moldings)
  const molding = (x0: number, y0: number, x1: number, y1: number): void => {
    ctx.strokeStyle = 'rgba(60,44,16,0.65)';
    ctx.lineWidth = 10;
    ctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
    ctx.strokeStyle = 'rgba(255,246,200,0.30)';
    ctx.lineWidth = 3;
    ctx.strokeRect(x0 + 8, y0 + 8, x1 - x0 - 16, y1 - y0 - 16);
    bctx.strokeStyle = '#333333';
    bctx.lineWidth = 8;
    bctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
  };
  molding(58, 90, W - 58, 450);
  molding(58, 510, W - 58, 800);

  // crayon doodles: confetti squiggles, streamers
  const crayons = ['#c8272f', '#3d7a4e', '#8a5aa0', '#d07a2c'];
  for (let i = 0; i < 26; i++) {
    const col = crayons[(rand() * crayons.length) | 0];
    ctx.strokeStyle = col;
    ctx.globalAlpha = 0.55 + rand() * 0.3;
    ctx.lineWidth = 2.5 + rand() * 2;
    ctx.lineCap = 'round';
    const x = 40 + rand() * (W - 80);
    const y = 100 + rand() * (H - 240);
    if (rand() < 0.5) {
      // squiggle
      ctx.beginPath();
      ctx.moveTo(x, y);
      for (let s = 1; s <= 4; s++) ctx.lineTo(x + s * 9, y + Math.sin(s * 1.7 + x) * 7);
      ctx.stroke();
    } else {
      // dot / star
      ctx.beginPath();
      ctx.arc(x, y, 2 + rand() * 3.5, 0, Math.PI * 2);
      ctx.fillStyle = col;
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  // the greeting: big wobbling red "=)" across the lower panel
  ctx.save();
  ctx.translate(W / 2, 640);
  ctx.rotate(-0.06 + rand() * 0.1);
  ctx.strokeStyle = 'rgba(178,30,36,0.92)';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(-58, 0, 34, 0.25 * Math.PI, 0.75 * Math.PI);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(-58, 0, 62, 0.25 * Math.PI, 0.75 * Math.PI);
  ctx.stroke();
  // the eyes of the smiley + parentheses
  ctx.beginPath();
  ctx.arc(64, -34, 13, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(178,30,36,0.92)';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(112, 0, 62, -0.42, 0.42);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(112, 0, 62, Math.PI - 0.42, Math.PI + 0.42);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(112, 10, 34, 0.2 * Math.PI, 0.8 * Math.PI);
  ctx.stroke();
  ctx.restore();

  // wobbly PARTY above the smiley
  ctx.save();
  ctx.translate(W / 2, 350);
  ctx.rotate(-0.03);
  ctx.fillStyle = 'rgba(60,90,60,0.75)';
  ctx.font = 'bold 64px "Comic Sans MS", "Segoe Print", cursive';
  ctx.textAlign = 'center';
  ctx.fillText('PARTY', 0, 0);
  ctx.restore();

  // grime + sticky rings (spilled punch?)
  for (let i = 0; i < 5; i++) {
    const x = 60 + rand() * (W - 120);
    const y = 700 + rand() * 280;
    ctx.strokeStyle = 'rgba(90,60,20,0.25)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(x, y, 8 + rand() * 16, 0, Math.PI * 2);
    ctx.stroke();
  }
  const grime = ctx.createLinearGradient(0, H - 200, 0, H);
  grime.addColorStop(0, 'rgba(30,20,8,0)');
  grime.addColorStop(1, 'rgba(30,20,8,0.38)');
  ctx.fillStyle = grime;
  ctx.fillRect(0, H - 200, W, 200);

  return {
    map: toTexture(c),
    bump: toDataTexture(bc),
    rough: toDataTexture(rc),
  };
}

export function buildTextures(seed: number): GameTextures {
  const signs: Record<string, THREE.CanvasTexture> = {
    smile: makeSign('=)', '#c8272f', true),
    exit: makeSign('EXIT', '#e8e4d2'),
    stairwell: makeSign('STAIRWELL\nE7', '#e8e4d2'),
    dontStop: makeSign("DON'T STOP", '#8c1f24', true),
    humLies: makeSign('THE HUM LIES', '#2c2416'),
    hears: makeSign('IT HEARS RUNNING', '#8c1f24'),
    arrowStair: makeSign('STAIRWELL >', '#e8e4d2'),
    arrowFun: makeSign('FUN =) >', '#c8272f'),
    arrowSpawn: makeSign('< SPAWN', '#e8e4d2'),
    arrowHub: makeSign('THE HUB >', '#e8e4d2'),
    hollow: makeSign('SOME WALLS HERE\nARE HOLLOW', '#2c2416'),
    megFlag: makeSign('M.E.G.\nOUTPOST ECHO-4', '#c8b878', true),
    lift: makeSign('FREIGHT\nLIFT', '#e8e4d2', true),
  };
  const papers = [makePaper(seed), makePaper(seed + 13), makePaper(seed + 991)];
  return {
    wallpaper: makeWallpaper(seed),
    carpet: makeCarpet(seed),
    ceiling: makeCeiling(seed),
    lightPanel: makeLightPanel(seed),
    grin: makeGrin(),
    paper: papers,
    signs,
    bottleLabel: makeBottleLabel(seed),
    concrete: makeConcrete(seed),
    crateWood: makeCrateWood(seed),
    hazard: makeHazard(),
    doorMetal: makeDoorMetal(seed),
    doorParty: makeDoorParty(seed),
    glow: makeGlow(),
  };
}

/** Almond Water label: aged paper band with printed branding, stains and fine print. */
export function makeBottleLabel(seed: number): THREE.CanvasTexture {
  const W = 512;
  const H = 130;
  const [c, ctx] = makeCanvas(W, H);
  const rand = mulberry32(seed ^ 0x6a6e);

  // aged paper base with a faint fiber texture
  ctx.fillStyle = '#e9e2cc';
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 900; i++) {
    const x = rand() * W;
    const y = rand() * H;
    ctx.fillStyle = `rgba(${140 + rand() * 60},${130 + rand() * 55},${95 + rand() * 45},${0.04 + rand() * 0.06})`;
    ctx.fillRect(x, y, 1 + rand() * 2, 1);
  }

  // top + bottom brand bars
  ctx.fillStyle = '#4a3d24';
  ctx.fillRect(0, 0, W, 12);
  ctx.fillRect(0, H - 12, W, 12);
  ctx.fillStyle = '#e9e2cc';
  ctx.font = 'bold 8px "Courier New", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('M.E.G. RATION CERTIFIED - LEVEL 0 SUPPLY', W / 2, 6.5);
  ctx.fillText('500 mL - SHAKE WELL - AVOID THE HUM', W / 2, H - 6.5);

  // brand name on one line
  ctx.fillStyle = '#2e2818';
  ctx.font = 'bold 30px "Courier New", monospace';
  ctx.fillText('A L M O N D   W A T E R', W / 2, 40);

  // fine print under the brand
  ctx.font = '9px "Courier New", monospace';
  ctx.fillStyle = 'rgba(46,40,24,0.85)';
  ctx.fillText('restores the body - confuses the smile', W / 2, 62);

  // little almond motif
  ctx.save();
  ctx.translate(W / 2, 92);
  ctx.fillStyle = '#a3813f';
  ctx.beginPath();
  ctx.ellipse(0, 0, 13, 8, 0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#5c4a24';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, 0, 13, 0.5, 0.5 + Math.PI);
  ctx.stroke();
  ctx.restore();

  // thin double border frame
  ctx.strokeStyle = 'rgba(74,61,36,0.8)';
  ctx.lineWidth = 2;
  ctx.strokeRect(6, 17, W - 12, H - 34);
  ctx.lineWidth = 0.7;
  ctx.strokeRect(10, 20, W - 20, H - 40);

  // coffee-ring stain
  const sx = 60 + rand() * 390;
  const sy = 30 + rand() * 70;
  ctx.strokeStyle = 'rgba(120,90,40,0.28)';
  ctx.lineWidth = 3 + rand() * 3;
  ctx.beginPath();
  ctx.arc(sx, sy, 14 + rand() * 9, 0, Math.PI * 2);
  ctx.stroke();

  // scuffs / fold lines
  for (let i = 0; i < 6; i++) {
    const x = rand() * W;
    ctx.strokeStyle = `rgba(90,75,40,${0.1 + rand() * 0.14})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, 14);
    ctx.lineTo(x + (rand() - 0.5) * 20, H - 14);
    ctx.stroke();
  }

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
