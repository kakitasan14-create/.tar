// Builds the playable Level 0 scene from maze data: merged wall geometry with
// world-scaled UVs, floor/ceiling, instanced fluorescent panels, furniture,
// signage, collision spatial-hash and the interactable registry.

import * as THREE from 'three';
import {
  MazeData, GRID, CELL, WALL_H, WALL_T, RoomKind,
} from './maze';
import { GameTextures } from './textures';
import * as P from './props';
import { mulberry32 } from './rng';
import { buildHub } from './hub';
import { LightingFX } from './lighting';

export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface Interactable {
  id: string;
  kind: 'note' | 'water' | 'lever' | 'doorStair' | 'doorParty' | 'radio' | 'doorHub' | 'radioOutpost' | 'elevator' | 'hubLever';
  pos: THREE.Vector3;
  radius: number;
  prompt: string;
  active: boolean;
  mesh?: THREE.Object3D;
  data?: unknown;
}

interface GeoArrays {
  pos: number[];
  norm: number[];
  uv: number[];
  idx: number[];
}

const TEX_U = 2.4; // meters per wallpaper tile horizontally

function addFace(g: GeoArrays, verts: number[][], normal: number[], uvs: number[][]): void {
  const base = g.pos.length / 3;
  for (const v of verts) g.pos.push(v[0], v[1], v[2]);
  for (let i = 0; i < 4; i++) g.norm.push(normal[0], normal[1], normal[2]);
  for (const uv of uvs) g.uv.push(uv[0], uv[1]);
  g.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
}

function addBoxGeo(g: GeoArrays, cx: number, cy: number, cz: number, w: number, h: number, d: number): void {
  const x0 = cx - w / 2, x1 = cx + w / 2;
  const y0 = cy - h / 2, y1 = cy + h / 2;
  const z0 = cz - d / 2, z1 = cz + d / 2;
  const uw = w / TEX_U;
  const ud = d / TEX_U;
  // +Z face (front)
  addFace(g, [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], [0, 0, 1], [[0, 0], [uw, 0], [uw, 1], [0, 1]]);
  // -Z
  addFace(g, [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], [0, 0, -1], [[0, 0], [uw, 0], [uw, 1], [0, 1]]);
  // +X
  addFace(g, [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], [1, 0, 0], [[0, 0], [ud, 0], [ud, 1], [0, 1]]);
  // -X
  addFace(g, [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], [-1, 0, 0], [[0, 0], [ud, 0], [ud, 1], [0, 1]]);
  // +Y
  addFace(g, [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], [0, 1, 0], [[0, 0], [uw, 0], [uw, ud], [0, ud]]);
  // -Y
  addFace(g, [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], [0, -1, 0], [[0, 0], [uw, 0], [uw, ud], [0, ud]]);
}

export interface LevelRefs {
  interactables: Interactable[];
  lightMats: {
    steady: THREE.MeshBasicMaterial;
    dead: THREE.MeshBasicMaterial;
    /** One emissive material per flicker group (independent blink phases). */
    flickerGroups: THREE.MeshBasicMaterial[];
  };
  /** The alive-lighting rig (glow halos, floor pools, ceiling spill). */
  lightFX: LightingFX;
  stairwellLamp: THREE.Mesh;
  breakerLever: THREE.Mesh;
  breakerLampOn: THREE.Mesh;
  stairwellDoor: THREE.Group;
  partyDoor: THREE.Group;
  bottles: THREE.Group[];
  notePos: THREE.Vector3[];
  partyDoorPos: THREE.Vector3;
  stairwellDoorPos: THREE.Vector3;
  breakerPos: THREE.Vector3;
  radioPos: THREE.Vector3;
  hubPos: THREE.Vector3;
  breachPos: THREE.Vector3;
  hubEntry: { x: number; z: number; yaw: number };
  hubOutpost: THREE.Vector3;
  hubElevator: THREE.Vector3;
  hubLiftLamp: THREE.Mesh;
  hubLiftButton: THREE.Mesh;
  hubWater: THREE.Mesh | null;
  hubMachineLever: THREE.Mesh | null;
  hubMachineLampOff: THREE.Mesh | null;
  hubMachineLampOn: THREE.Mesh | null;
  hubMachineLight: THREE.PointLight | null;
  hubMachinePos: THREE.Vector3 | null;
  hubWaterPos: THREE.Vector3 | null;
  hubGalleryMouth: THREE.Vector3 | null;
}

export class Level {
  maze: MazeData;
  private colliders: AABB[] = [];
  private cellHash = new Map<number, number[]>();
  interactables: Interactable[] = [];
  lightMats!: LevelRefs['lightMats'];
  refs!: LevelRefs;
  lightFX!: LightingFX;
  /**
   * Ceiling panel world positions per light group. Group 0 (steady) also
   * receives The Hub's caged bulbs so the tunnel network gets pool lights.
   */
  panelPos: { steady: THREE.Vector3[]; dead: THREE.Vector3[]; flickerGroups: THREE.Vector3[][] } = {
    steady: [],
    dead: [],
    flickerGroups: [[], [], []],
  };
  /** Per-cell light level 0..1 (static; multiplied by powerLevel at query). */
  cellLight: Float32Array = new Float32Array(GRID * GRID);
  /** Mains power 0..1 - 0 during the blackout (drives lightAt queries). */
  powerLevel = 1;
  /** Shared PBR wall material (all wall chunks) - kept for debugging tools. */
  wallMat!: THREE.MeshStandardMaterial;
  private rand: () => number;

  constructor(private scene: THREE.Object3D, maze: MazeData, private tex: GameTextures, seed: number) {
    this.maze = maze;
    this.rand = mulberry32(seed ^ 0xbeef01);
  }

  // ---------- collision ----------

  private addCollider(minX: number, maxX: number, minZ: number, maxZ: number): void {
    const box: AABB = { minX, maxX, minZ, maxZ };
    const id = this.colliders.push(box) - 1;
    // unbounded cell keys: The Hub sits at x ~ 300, far outside the maze grid
    const cx0 = Math.floor(minX / CELL);
    const cx1 = Math.floor(maxX / CELL);
    const cy0 = Math.floor(minZ / CELL);
    const cy1 = Math.floor(maxZ / CELL);
    for (let cy = cy0; cy <= cy1; cy++) {
      for (let cx = cx0; cx <= cx1; cx++) {
        const key = (cy + 512) * 4096 + (cx + 512);
        let arr = this.cellHash.get(key);
        if (!arr) {
          arr = [];
          this.cellHash.set(key, arr);
        }
        arr.push(id);
      }
    }
  }

  // scratch state for collidersNear: reused array + generation stamps instead
  // of a fresh Set+array every call (this runs every frame for the player)
  private nearScratch: AABB[] = [];
  private nearStamp = new Int32Array(64);
  private nearGen = 0;

  collidersNear(x: number, z: number): AABB[] {
    const cx = Math.floor(x / CELL);
    const cy = Math.floor(z / CELL);
    const out = this.nearScratch;
    out.length = 0;
    const gen = ++this.nearGen;
    if (this.nearStamp.length < this.colliders.length) {
      this.nearStamp = new Int32Array(this.colliders.length + 256);
    }
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const arr = this.cellHash.get((cy + dy + 512) * 4096 + (cx + dx + 512));
        if (!arr) continue;
        for (let i = 0; i < arr.length; i++) {
          const id = arr[i];
          if (this.nearStamp[id] !== gen) {
            this.nearStamp[id] = gen;
            out.push(this.colliders[id]);
          }
        }
      }
    }
    return out;
  }

  private addInteractable(i: Interactable): void {
    this.interactables.push(i);
  }

  // ---------- build ----------

  build(): LevelRefs {
    const m = this.maze;
    const SIZE = GRID * CELL;

    // --- walls (spatially chunked merges) ---
    // Geometry is merged per ~4x4-cell region instead of one whole-map mesh:
    // same material + same vertex count, but each chunk gets its own bounding
    // sphere so three.js frustum-culls everything you are not looking at.
    // Down a corridor that skips ~90% of wall vertices every frame.
    const CHUNK_CELLS = 4;
    const CHUNKS = Math.ceil(GRID / CHUNK_CELLS);
    const CHUNK_W = CHUNK_CELLS * CELL;
    const chunkGeos = new Map<number, GeoArrays>();
    const geoFor = (wx: number, wz: number): GeoArrays => {
      const kx = Math.min(CHUNKS - 1, Math.max(0, Math.floor(wx / CHUNK_W)));
      const kz = Math.min(CHUNKS - 1, Math.max(0, Math.floor(wz / CHUNK_W)));
      const key = kz * CHUNKS + kx;
      let g = chunkGeos.get(key);
      if (!g) {
        g = { pos: [], norm: [], uv: [], idx: [] };
        chunkGeos.set(key, g);
      }
      return g;
    };
    // horizontal runs (wallsN rows)
    for (let ey = 0; ey <= GRID; ey++) {
      let x = 0;
      while (x < GRID) {
        if (m.wallsN[ey * GRID + x]) {
          let x1 = x;
          while (x1 + 1 < GRID && m.wallsN[ey * GRID + x1 + 1]) x1++;
          const length = (x1 + 1 - x) * CELL + WALL_T;
          const cx = (x + (x1 + 1 - x) / 2) * CELL;
          // long runs cross chunk borders - split them per chunk so bounds stay tight
          let sx = x;
          while (sx <= x1) {
            const sc = Math.floor(sx / CHUNK_CELLS);
            const ex = Math.min(x1, (sc + 1) * CHUNK_CELLS - 1);
            const segLen = (ex + 1 - sx) * CELL + WALL_T;
            const segCx = (sx + (ex + 1 - sx) / 2) * CELL;
            addBoxGeo(geoFor(segCx, ey * CELL), segCx, WALL_H / 2, ey * CELL, segLen, WALL_H, WALL_T);
            sx = ex + 1;
          }
          this.addCollider(cx - length / 2, cx + length / 2, ey * CELL - WALL_T / 2, ey * CELL + WALL_T / 2);
          x = x1 + 1;
        } else x++;
      }
    }
    // vertical runs (wallsW cols)
    for (let ex = 0; ex <= GRID; ex++) {
      let y = 0;
      while (y < GRID) {
        if (m.wallsW[y * (GRID + 1) + ex]) {
          let y1 = y;
          while (y1 + 1 < GRID && m.wallsW[(y1 + 1) * (GRID + 1) + ex]) y1++;
          const length = (y1 + 1 - y) * CELL + WALL_T;
          const cz = (y + (y1 + 1 - y) / 2) * CELL;
          let sy = y;
          while (sy <= y1) {
            const sc = Math.floor(sy / CHUNK_CELLS);
            const ey2 = Math.min(y1, (sc + 1) * CHUNK_CELLS - 1);
            const segLen = (ey2 + 1 - sy) * CELL + WALL_T;
            const segCz = (sy + (ey2 + 1 - sy) / 2) * CELL;
            addBoxGeo(geoFor(ex * CELL, segCz), ex * CELL, WALL_H / 2, segCz, WALL_T, WALL_H, segLen);
            sy = ey2 + 1;
          }
          this.addCollider(ex * CELL - WALL_T / 2, ex * CELL + WALL_T / 2, cz - length / 2, cz + length / 2);
          y = y1 + 1;
        } else y++;
      }
    }
    // pillars
    for (const p of m.pillars) {
      addBoxGeo(geoFor(p.x, p.z), p.x, WALL_H / 2, p.z, 0.85, WALL_H, 0.85);
      this.addCollider(p.x - 0.425, p.x + 0.425, p.z - 0.425, p.z + 0.425);
    }
    // PBR walls: bump + roughness maps react to the pooled point lights
    const wallMat = new THREE.MeshStandardMaterial({
      map: this.tex.wallpaper.map,
      bumpMap: this.tex.wallpaper.bump,
      bumpScale: 0.55,
      roughnessMap: this.tex.wallpaper.rough,
      roughness: 1.0,
      metalness: 0.0,
    });
    this.wallMat = wallMat;
    const wallGroup = new THREE.Group();
    wallGroup.name = 'wallChunks';
    for (const g of chunkGeos.values()) {
      const geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.Float32BufferAttribute(g.pos, 3));
      geom.setAttribute('normal', new THREE.Float32BufferAttribute(g.norm, 3));
      geom.setAttribute('uv', new THREE.Float32BufferAttribute(g.uv, 2));
      geom.setIndex(g.idx);
      const chunk = new THREE.Mesh(geom, wallMat);
      chunk.matrixAutoUpdate = false; // static geometry - skip per-frame matrix updates
      wallGroup.add(chunk);
    }
    this.scene.add(wallGroup);

    // --- floor & ceiling ---
    const REP = SIZE / 1.8;
    const carpet = this.tex.carpet;
    carpet.map.repeat.set(REP, REP);
    carpet.rough.repeat.set(REP, REP);
    carpet.bump.repeat.set(REP, REP);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(SIZE, SIZE),
      new THREE.MeshStandardMaterial({
        map: carpet.map,
        bumpMap: carpet.bump,
        bumpScale: 0.4,
        roughnessMap: carpet.rough,
        roughness: 1.0,
        metalness: 0.0,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(SIZE / 2, 0, SIZE / 2);
    this.scene.add(floor);

    const ceil = new THREE.Mesh(
      new THREE.PlaneGeometry(SIZE, SIZE),
      new THREE.MeshLambertMaterial({ map: this.tex.ceiling })
    );
    (ceil.material as THREE.MeshLambertMaterial).map!.repeat.set(SIZE / 3.6, SIZE / 3.6);
    ceil.rotation.x = Math.PI / 2;
    ceil.position.set(SIZE / 2, WALL_H, SIZE / 2);
    this.scene.add(ceil);

    // --- fluorescent panels (instanced; steady/dead share a material, the
    // three flicker groups each get their own emissive material so they can
    // blink independently like real separate lighting circuits) ---
    // Rooms roll a power mood: most stay lit, some buzz on a flicker group,
    // and a handful go fully dead - those dark pockets belong to the Smiler.
    const panelGeo = new THREE.BoxGeometry(1.9, 0.05, 0.95);
    const mkMat = (color: number) =>
      new THREE.MeshBasicMaterial({ map: this.tex.lightPanel, color });
    const steadyMat = mkMat(0xfff3cf);
    const deadMat = mkMat(0x24200f);
    const flickerMats = [mkMat(0xfff3cf), mkMat(0xfff3cf), mkMat(0xfff3cf)];
    this.lightMats = { steady: steadyMat, dead: deadMat, flickerGroups: flickerMats };
    const steadyMats: THREE.Matrix4[] = [];
    const deadMats: THREE.Matrix4[] = [];
    const flickerMatsByGroup: THREE.Matrix4[][] = [[], [], []];
    const dummy = new THREE.Matrix4();
    const pos = new THREE.Vector3();
    const quat = new THREE.Quaternion();
    const scl = new THREE.Vector3(1, 1, 1);
    // per-room power roll for special rooms
    const roomPower = new Map<number, 'steady' | 'flicker' | 'dead'>();
    for (let ri = 0; ri < m.roomAt.length; ri++) {
      const kind = m.roomAt[ri].kind;
      let power: 'steady' | 'flicker' | 'dead';
      if (kind === 'spawn' || kind === 'hub' || kind === 'electrical' || kind === 'stairwell' || kind === 'lounge') power = 'steady';
      else if (kind === 'party' || kind === 'utility') power = 'flicker';
      else if (kind === 'wet' || kind === 'red') power = 'dead';
      else if (kind === 'closet') power = this.rand() < 0.55 ? 'dead' : 'flicker';
      else power = this.rand() < 0.2 ? 'dead' : this.rand() < 0.35 ? 'flicker' : 'steady';
      roomPower.set(ri, power);
    }
    const flickerGroupOf = (x: number, y: number): number => (x * 7 + y * 13) % 3;
    // contiguous DARK ZONES across the corridors: clusters of dead fixtures -
    // the Smiler's territory, and the reason the light map has real contrast
    const darkZones: { x: number; y: number; r: number }[] = [];
    for (let tries = 0; tries < 200 && darkZones.length < 8; tries++) {
      const zx = 2 + Math.floor(this.rand() * (GRID - 4));
      const zy = 2 + Math.floor(this.rand() * (GRID - 4));
      if (m.roomId[zy * GRID + zx] >= 0) continue; // keep zone seeds off special rooms
      if (darkZones.some((z) => Math.hypot(z.x - zx, z.y - zy) < 9)) continue;
      darkZones.push({ x: zx, y: zy, r: 3.5 + this.rand() * 3.5 });
    }
    const darkAt = (x: number, y: number): number => {
      let d = Infinity;
      for (const z of darkZones) d = Math.min(d, Math.hypot(z.x - x, z.y - y) - z.r);
      return d; // <0 inside a zone, >0 outside
    };
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        const rid = m.roomId[y * GRID + x];
        const inRoom = rid >= 0;
        const kind: RoomKind = inRoom ? m.roomAt[rid].kind : 'none';
        const isPillars = kind === 'pillars';
        if (kind === 'red') continue; // the red room keeps its own crimson light
        let place: boolean;
        let power: 'steady' | 'flicker' | 'dead';
        if (inRoom) {
          const rp = roomPower.get(rid) ?? 'steady';
          power = rp;
          // fixtures inside rooms: regular grid, denser than corridors
          place = isPillars ? x % 2 === 0 && y % 2 === 0 : (x + y) % 2 === 0;
          if (power === 'dead') place = place || (x + y) % 2 === 1; // dark rooms keep dead fixtures everywhere
        } else {
          const dz = darkAt(x, y);
          if (dz < 0) {
            // inside a dark zone: fixtures are dead (or one stuttering survivor)
            place = this.rand() < 0.62;
            power = this.rand() < 0.12 ? 'flicker' : 'dead';
          } else {
            place = (x + y * 2) % 3 === 0 && this.rand() < 0.82;
            const roll = this.rand();
            power = roll < 0.14 ? 'dead' : roll < 0.4 ? 'flicker' : 'steady';
          }
        }
        if (!place) continue;
        pos.set((x + 0.5) * CELL, WALL_H - 0.035, (y + 0.5) * CELL);
        quat.setFromAxisAngle(new THREE.Vector3(0, 1, 0), (x + y) % 2 ? Math.PI / 2 : 0);
        dummy.compose(pos, quat, scl);
        if (power === 'steady') {
          steadyMats.push(dummy.clone());
          this.panelPos.steady.push(pos.clone());
        } else if (power === 'dead') {
          deadMats.push(dummy.clone());
          this.panelPos.dead.push(pos.clone());
        } else {
          const gi = flickerGroupOf(x, y);
          flickerMatsByGroup[gi].push(dummy.clone());
          this.panelPos.flickerGroups[gi].push(pos.clone());
        }
      }
    }
    const emit = (mats: THREE.Matrix4[], mat: THREE.Material): void => {
      if (mats.length === 0) return;
      const inst = new THREE.InstancedMesh(panelGeo, mat, mats.length);
      mats.forEach((m2, i) => inst.setMatrixAt(i, m2));
      inst.instanceMatrix.needsUpdate = true;
      this.scene.add(inst);
    };
    emit(steadyMats, steadyMat);
    emit(deadMats, deadMat);
    for (let gi = 0; gi < 3; gi++) emit(flickerMatsByGroup[gi], flickerMats[gi]);

    // --- alive-lighting rig: glow halos, floor pools, ceiling spill ---
    this.lightFX = new LightingFX(this.scene, {
      steady: this.panelPos.steady,
      flickerGroups: this.panelPos.flickerGroups,
    }, this.tex.glow);

    // --- room furnishing ---
    this.furnishRooms();

    // --- The Hub: maze-side breach + concrete tunnel network (also fills
    // panelPos.steady with the caged bulbs AFTER the lighting rig is built,
    // so the tunnels get pool lights but no Level 0 glow quads) ---
    this.buildBreachAndHub();

    // --- static light field for the Smiler's dark routes ---
    this.computeCellLight();

    // refs are finalized AFTER the hub exists (hubEntry/outpost/elevator/lift)
    this.refs_final(this._notePos, this._bottles);

    return this.refs;
  }

  /**
   * Static per-cell light level from all live panels (steady 1.0, flicker
   * 0.65). Cells outside the grid (The Hub) are skipped. Multiplied by
   * powerLevel at query time so blackouts read as total darkness. Falloff is
   * kept tight so dark zones stay genuinely dark.
   */
  private computeCellLight(): void {
    const arr = this.cellLight;
    arr.fill(0);
    const SIZE = GRID * CELL;
    const addPanel = (px: number, pz: number, amt: number): void => {
      if (px < 0 || pz < 0 || px >= SIZE || pz >= SIZE) return; // The Hub lamps live far outside
      const cx = px / CELL - 0.5;
      const cz = pz / CELL - 0.5;
      const R = 1.7; // influence in cells (tight: keeps dark pockets dark)
      const x0 = Math.max(0, Math.floor(cx - R));
      const x1 = Math.min(GRID - 1, Math.ceil(cx + R));
      const y0 = Math.max(0, Math.floor(cz - R));
      const y1 = Math.min(GRID - 1, Math.ceil(cz + R));
      for (let cy = y0; cy <= y1; cy++) {
        for (let cx2 = x0; cx2 <= x1; cx2++) {
          const d = Math.hypot(cx2 - cx, cy - cz);
          if (d > R) continue;
          const w = 1 - d / R;
          arr[cy * GRID + cx2] += amt * w * w;
        }
      }
    };
    for (const p of this.panelPos.steady) addPanel(p.x, p.z, 1.25);
    for (const grp of this.panelPos.flickerGroups) {
      for (const p of grp) addPanel(p.x, p.z, 0.72);
    }
    for (let i = 0; i < arr.length; i++) arr[i] = Math.min(1, arr[i]);
  }

  /** Light level at world position (0..1); 0 when the power is out. */
  lightAt(x: number, z: number): number {
    const cx = Math.floor(x / CELL);
    const cy = Math.floor(z / CELL);
    if (cx < 0 || cy < 0 || cx >= GRID || cy >= GRID) return 0;
    return this.cellLight[cy * GRID + cx] * this.powerLevel;
  }

  private roomWorld(r: { x: number; y: number; w: number; h: number }): { x: number; z: number; w: number; h: number } {
    return { x: (r.x + r.w / 2) * CELL, z: (r.y + r.h / 2) * CELL, w: r.w * CELL, h: r.h * CELL };
  }

  private placeProp(group: THREE.Group, x: number, z: number, rotY: number, collider?: { w: number; d: number }): void {
    group.position.set(x, 0, z);
    group.rotation.y = rotY;
    this.scene.add(group);
    if (collider) {
      const cos = Math.abs(Math.cos(rotY));
      const sin = Math.abs(Math.sin(rotY));
      const w = collider.w * cos + collider.d * sin;
      const d = collider.w * sin + collider.d * cos;
      this.addCollider(x - w / 2, x + w / 2, z - d / 2, z + d / 2);
    }
  }

  /** Shared note placement (maze + The Hub outpost). */
  private _notePos: THREE.Vector3[] = [];
  addNoteAt(x: number, z: number, id: number): void {
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.3, 0.4),
      new THREE.MeshBasicMaterial({ map: this.tex.paper[id % this.tex.paper.length] })
    );
    mesh.rotation.x = -Math.PI / 2;
    mesh.rotation.z = this.rand() * Math.PI * 2;
    mesh.position.set(x, 0.02, z);
    this.scene.add(mesh);
    this._notePos.push(mesh.position.clone());
    this.addInteractable({
      id: `note-${id}`,
      kind: 'note',
      pos: mesh.position.clone(),
      radius: 1.9,
      prompt: 'READ PAGE',
      active: true,
      mesh,
      data: { id },
    });
  }

  /** Shared almond-water placement (maze + The Hub outpost). */
  addBottleAt(x: number, z: number): void {
    const g = P.buildBottle(this.tex.bottleLabel);
    g.position.set(x, 0, z);
    this.scene.add(g);
    this._bottles.push(g);
    this.addInteractable({
      id: `water-${this._bottles.length - 1}`,
      kind: 'water',
      pos: new THREE.Vector3(x, 0.15, z),
      radius: 1.8,
      prompt: 'TAKE ALMOND WATER',
      active: true,
      mesh: g,
      data: { taken: false },
    });
  }

  /**
   * Maze-side breach dressing (torn hole, scrawl, memo page, fourth signpost)
   * plus the whole Hub tunnel network via buildHub().
   */
  private buildBreachAndHub(): void {
    const bw = this.maze.breachWall;
    const wallX = bw.edgeX * CELL;
    const holeZ = (bw.cy + 0.5) * CELL;
    const faceX = wallX - WALL_T / 2; // west face of the breach wall (room side)

    const breach = P.buildBreach();
    breach.group.position.set(faceX + 0.52, 0, holeZ); // mouth lands on the west face
    breach.group.rotation.y = -Math.PI / 2; // void sinks east, into the wall
    this.scene.add(breach.group);
    const breachPos = new THREE.Vector3(faceX - 0.35, 1.1, holeZ);
    this.addInteractable({
      id: 'doorHub',
      kind: 'doorHub',
      pos: breachPos.clone(),
      radius: 2.4,
      prompt: 'CRAWL THROUGH THE HOLE',
      active: true,
    });

    // scrawl above the hole + a torn memo on the carpet
    const scrawl = P.buildWallSign(this.tex.signs.hollow, 1.9, 0.95);
    scrawl.position.set(faceX - 0.04, 2.3, holeZ);
    scrawl.rotation.y = -Math.PI / 2; // plane +Z -> -X
    this.scene.add(scrawl);
    this.addNoteAt(faceX - 1.15, holeZ + 0.75, 11);

    // fourth signpost in the junction room: THE HUB >
    {
      const r = this.maze.roomAt.find((rr) => rr.kind === 'hub')!;
      const w = this.roomWorld(r);
      const tx = (bw.edgeX + 0.5) * CELL;
      const tz = (bw.cy + 0.5) * CELL;
      const rotY = Math.atan2(tx - w.x, tz - w.z);
      const sp = P.buildSignpost(this.tex.signs.arrowHub, rotY);
      this.placeProp(sp, w.x + w.w / 2 - 0.7, w.z + w.h / 2 - 0.7, 0, { w: 0.5, d: 0.5 });
    }

    const hub = buildHub(
      this.scene,
      this.tex,
      (minX, maxX, minZ, maxZ) => this.addCollider(minX, maxX, minZ, maxZ),
      (i) => this.addInteractable(i),
      (x, z, id) => this.addNoteAt(x, z, id),
      (x, z) => this.addBottleAt(x, z)
    );
    for (const p of hub.lampPos) this.panelPos.steady.push(p);
    this._hub = hub;
  }

  private _hub: ReturnType<typeof buildHub> | null = null;

  private furnishRooms(): void {
    const m = this.maze;
    const roomBy = (kind: string) => m.roomAt.find((r) => r.kind === kind)!;
    // spawn room: table, radio, guaranteed first page, crate
    {
      const r = roomBy('spawn');
      const w = this.roomWorld(r);
      const t = P.buildTable();
      this.placeProp(t.group, w.x - 0.8, w.z, 0, t.collider);
      const radio = P.buildRadio();
      radio.position.set(w.x - 0.8, 0.75, w.z + 0.05);
      this.scene.add(radio);
      this.addInteractable({
        id: 'radio',
        kind: 'radio',
        pos: radio.position.clone(),
        radius: 2.0,
        prompt: 'RADIO: LISTEN',
        active: true,
        mesh: radio,
      });
      this.addNoteAt(w.x + 0.9, w.z + 0.7, 0);
      const c = P.buildCrateStack({ map: this.tex.crateWood.map, bumpMap: this.tex.crateWood.bump });
      // front-left corner: never photobombs the menu hero shot of the camcorder
      this.placeProp(c.group, w.x - w.w / 2 + 0.8, w.z + w.h / 2 - 0.8, 0.4, c.collider);
    }

    // office
    {
      const r = roomBy('office');
      const w = this.roomWorld(r);
      const d = P.buildDesk();
      this.placeProp(d.group, w.x, w.z - 0.5, 0, d.collider);
      const ch = P.buildChair();
      this.placeProp(ch.group, w.x, w.z + 0.55, Math.PI, ch.collider);
      this.addNoteAt(w.x, w.z - 0.45, 1);
    }

    // storage x2
    const storageRooms = m.roomAt.filter((rr) => rr.kind === 'storage');
    for (let i = 0; i < storageRooms.length; i++) {
      const r = storageRooms[i];
      const w = this.roomWorld(r);
      const s1 = P.buildShelf();
      this.placeProp(s1.group, w.x - w.w / 2 + 1.2, w.z - w.h / 2 + 0.45, 0, s1.collider);
      const s2 = P.buildShelf();
      this.placeProp(s2.group, w.x + w.w / 2 - 1.2, w.z + w.h / 2 - 0.45, Math.PI, s2.collider);
      this.addBottleAt(w.x, w.z);
      if (i === 0) this.addNoteAt(w.x - 0.8, w.z + 0.9, 3);
      else this.addNoteAt(w.x + 0.7, w.z - 0.7, 4);
    }

    // wet room
    {
      const r = roomBy('wet');
      const w = this.roomWorld(r);
      const pipes = P.buildPipes(w.w - 1.2);
      pipes.position.set(w.x, 0, w.z);
      this.scene.add(pipes);
      this.addNoteAt(w.x + 0.9, w.z + 0.6, 5);
    }

    // electrical: breaker on north wall
    {
      const r = roomBy('electrical');
      const w = this.roomWorld(r);
      const br = P.buildBreaker();
      br.group.position.set(w.x, 0, r.y * CELL + WALL_T / 2 + 0.1);
      br.group.rotation.y = Math.PI;
      this.scene.add(br.group);
      const pipes = P.buildPipes(w.w - 1);
      pipes.position.set(w.x, 0, w.z + 0.8);
      this.scene.add(pipes);
      this.addInteractable({
        id: 'lever',
        kind: 'lever',
        pos: new THREE.Vector3(w.x, 1.4, r.y * CELL + WALL_T / 2 + 0.2),
        radius: 2.0,
        prompt: 'PULL MAINS BREAKER',
        active: true,
        data: { pulled: false },
      });
      this.addNoteAt(w.x + 1.0, w.z + 0.6, 9);
      this.refs_breaker(br.leverRef, br.lampOn, new THREE.Vector3(w.x, 1.4, r.y * CELL + WALL_T / 2 + 0.2));
    }

    // stairwell room: exit door on south wall
    {
      const r = roomBy('stairwell');
      const w = this.roomWorld(r);
      const door = P.buildStairwellDoor(this.tex.signs.exit, this.tex.doorMetal);
      const dz = (r.y + r.h) * CELL - WALL_T / 2 - 0.06;
      door.group.position.set(w.x, 0, dz);
      door.group.rotation.y = 0; // built facing -Z (outward), south wall -> front faces -Z
      this.scene.add(door.group);
      const crate = P.buildCrateStack({ map: this.tex.crateWood.map, bumpMap: this.tex.crateWood.bump });
      this.placeProp(crate.group, w.x - w.w / 2 + 0.8, w.z - w.h / 2 + 0.8, 0.2, crate.collider);
      this.addInteractable({
        id: 'doorStair',
        kind: 'doorStair',
        pos: new THREE.Vector3(w.x, 1.2, dz - 0.3),
        radius: 2.2,
        prompt: 'STAIRWELL E7',
        active: true,
      });
      this.refs_stairwell(door.lamp, door.group, new THREE.Vector3(w.x, 1.2, dz - 0.3));
    }

    // party room: door on chosen wall + balloons + smiley
    {
      const r = roomBy('party');
      const w = this.roomWorld(r);
      const wall = m.partyDoorWall!;
      const door = P.buildPartyDoor(this.tex.signs.smile, this.tex.doorParty);
      let dx = w.x;
      let dz = w.z;
      if (wall.dir === 'N') {
        dx = (wall.cx + 0.5) * CELL;
        dz = r.y * CELL + WALL_T / 2 + 0.06;
        door.group.rotation.y = Math.PI;
      } else {
        dz = (wall.cy + 0.5) * CELL;
        dx = r.x * CELL + WALL_T / 2 + 0.06;
        door.group.rotation.y = -Math.PI / 2;
      }
      door.group.position.set(dx, 0, dz);
      this.scene.add(door.group);
      const balloons = P.buildBalloons();
      balloons.position.set(dx + (wall.dir === 'N' ? 1.3 : 0.5), 0, dz + (wall.dir === 'N' ? 0.5 : 1.3));
      this.scene.add(balloons);
      const smile = P.buildWallSign(this.tex.signs.smile, 1.6, 0.8);
      smile.position.set(w.x, 1.7, (r.y + r.h) * CELL - WALL_T / 2 - 0.05);
      smile.rotation.y = Math.PI;
      this.scene.add(smile);
      this.addInteractable({
        id: 'doorParty',
        kind: 'doorParty',
        pos: new THREE.Vector3(dx, 1.2, dz).add(new THREE.Vector3(wall.dir === 'N' ? 0 : -0.3, 0, wall.dir === 'N' ? -0.3 : 0)),
        radius: 2.2,
        prompt: 'DOOR THAT HUMS',
        active: true,
      });
      this.refs_party(door.group, new THREE.Vector3(dx, 1.2, dz));
      this.addNoteAt(w.x - 1.2, w.z + 0.8, 8);
    }

    // red room
    {
      const r = roomBy('red');
      const w = this.roomWorld(r);
      const light = new THREE.PointLight(0xff2213, 3.2, 7.5, 1.8);
      light.position.set(w.x, 2.4, w.z);
      this.scene.add(light);
      const sign = P.buildWallSign(this.tex.signs.dontStop, 2.0, 1.0);
      sign.position.set(w.x, 1.7, r.y * CELL + WALL_T / 2 + 0.05);
      this.scene.add(sign);
      this.addNoteAt(w.x, w.z - 0.8, 7);
    }

    // lounges: a table, mismatched chairs, sometimes a bottle
    {
      const lounges = m.roomAt.filter((rr) => rr.kind === 'lounge');
      for (let i = 0; i < lounges.length; i++) {
        const r = lounges[i];
        const w = this.roomWorld(r);
        const t = P.buildTable();
        this.placeProp(t.group, w.x, w.z, 0.2, t.collider);
        const ch1 = P.buildChair();
        this.placeProp(ch1.group, w.x - 1.0, w.z + 0.4, Math.PI * 0.5, ch1.collider);
        const ch2 = P.buildChair();
        this.placeProp(ch2.group, w.x + 1.0, w.z - 0.4, -Math.PI * 0.5, ch2.collider);
        if (i === 0) this.addBottleAt(w.x + 0.3, w.z + 0.6);
      }
    }

    // utility pockets: wall pipes and crates
    {
      const utils = m.roomAt.filter((rr) => rr.kind === 'utility');
      for (const r of utils) {
        const w = this.roomWorld(r);
        const pipes = P.buildPipes(w.w - 1);
        pipes.position.set(w.x, 0, w.z - w.h / 2 + 0.6);
        this.scene.add(pipes);
        const c = P.buildCrateStack({ map: this.tex.crateWood.map, bumpMap: this.tex.crateWood.bump });
        this.placeProp(c.group, w.x + w.w / 2 - 0.8, w.z + w.h / 2 - 0.8, 0.9, c.collider);
      }
    }

    // closets: cramped crate pockets (often lightless - Smiler country)
    {
      const closets = m.roomAt.filter((rr) => rr.kind === 'closet');
      for (let i = 0; i < closets.length; i++) {
        const r = closets[i];
        const w = this.roomWorld(r);
        const c = P.buildCrateStack({ map: this.tex.crateWood.map, bumpMap: this.tex.crateWood.bump });
        this.placeProp(c.group, w.x - 0.5, w.z - 0.4, this.rand() * 3, c.collider);
        if (i === 1) this.addBottleAt(w.x + 0.6, w.z + 0.5);
      }
    }

    // hub: signposts pointing to exits + red emergency light
    {
      const r = roomBy('hub');
      const w = this.roomWorld(r);
      const targets: [THREE.Texture, { x: number; z: number }][] = [
        [this.tex.signs.arrowStair, { x: this.maze.stairwellCell.x, z: this.maze.stairwellCell.y }],
        [this.tex.signs.arrowFun, { x: this.maze.partyCell.x, z: this.maze.partyCell.y }],
        [this.tex.signs.arrowSpawn, { x: this.maze.spawnCell.x, z: this.maze.spawnCell.y }],
      ];
      const corners = [
        [w.x - w.w / 2 + 0.7, w.z - w.h / 2 + 0.7],
        [w.x + w.w / 2 - 0.7, w.z - w.h / 2 + 0.7],
        [w.x - w.w / 2 + 0.7, w.z + w.h / 2 - 0.7],
      ];
      targets.forEach(([tex, cell], i) => {
        const tx = (cell.x + 0.5) * CELL;
        const tz = (cell.z + 0.5) * CELL;
        const rotY = Math.atan2(tx - w.x, tz - w.z);
        const sp = P.buildSignpost(tex, rotY);
        this.placeProp(sp, corners[i][0], corners[i][1], 0, { w: 0.5, d: 0.5 });
      });
      const emerg = new THREE.PointLight(0xff2a1a, 2.2, 8, 1.8);
      emerg.position.set(w.x, 2.5, w.z);
      this.scene.add(emerg);
    }

    // scattered notes in pillar halls + a random far one
    {
      const halls = m.roomAt.filter((r) => r.kind === 'pillars');
      halls.forEach((r, i) => {
        const w = this.roomWorld(r);
        this.addNoteAt(w.x + (i === 0 ? 1.1 : -1.3), w.z + (i === 0 ? -1.0 : 1.0), i === 0 ? 2 : 6);
      });
      // extra page in a random corridor cell
      for (let tries = 0; tries < 50; tries++) {
        const cx = Math.floor(this.rand() * GRID);
        const cy = Math.floor(this.rand() * GRID);
        if (m.roomId[cy * GRID + cx] === -1) {
          this.addNoteAt((cx + 0.5) * CELL, (cy + 0.5) * CELL, 10);
          break;
        }
      }
    }

    // scattered bottles in corridors
    {
      let placed = 0;
      for (let tries = 0; tries < 200 && placed < 3; tries++) {
        const cx = Math.floor(this.rand() * GRID);
        const cy = Math.floor(this.rand() * GRID);
        if (m.roomId[cy * GRID + cx] === -1) {
          this.addBottleAt((cx + 0.5) * CELL + (this.rand() - 0.5), (cy + 0.5) * CELL + (this.rand() - 0.5));
          placed++;
        }
      }
    }
    // decor scrawls on random corridor walls
    {
      const scrawls: [THREE.Texture, number, number][] = [
        [this.tex.signs.humLies, 2.2, 1.1],
        [this.tex.signs.hears, 2.2, 1.1],
      ];
      for (const [tex, sw, sh] of scrawls) {
        for (let tries = 0; tries < 80; tries++) {
          const cx = Math.floor(this.rand() * GRID);
          const cy = Math.floor(this.rand() * GRID);
          if (m.roomId[cy * GRID + cx] !== -1) continue;
          // find a solid wall of this cell to hang the scrawl
          if (m.wallsN[cy * GRID + cx]) {
            const s = P.buildWallSign(tex, sw, sh);
            s.position.set((cx + 0.5) * CELL, 1.7, cy * CELL + WALL_T / 2 + 0.03);
            this.scene.add(s);
            break;
          }
          if (m.wallsW[cy * (GRID + 1) + cx]) {
            const s = P.buildWallSign(tex, sw, sh);
            s.position.set(cx * CELL + WALL_T / 2 + 0.03, 1.7, (cy + 0.5) * CELL);
            s.rotation.y = Math.PI / 2;
            this.scene.add(s);
            break;
          }
        }
      }
    }
  }

  // The furnish method references refs before it exists; these setters wire it up.
  private _breaker!: { lever: THREE.Mesh; lampOn: THREE.Mesh; pos: THREE.Vector3 };
  private _stairwell!: { lamp: THREE.Mesh; group: THREE.Group; pos: THREE.Vector3 };
  private _party!: { group: THREE.Group; pos: THREE.Vector3 };
  private _notes: THREE.Vector3[] = [];
  private _bottles: THREE.Group[] = [];

  private refs_breaker(lever: THREE.Mesh, lampOn: THREE.Mesh, pos: THREE.Vector3): void {
    this._breaker = { lever, lampOn, pos };
  }
  private refs_stairwell(lamp: THREE.Mesh, group: THREE.Group, pos: THREE.Vector3): void {
    this._stairwell = { lamp, group, pos };
  }
  private refs_party(group: THREE.Group, pos: THREE.Vector3): void {
    this._party = { group, pos };
  }
  private refs_final(notes: THREE.Vector3[], bottles: THREE.Group[]): void {
    this._notes = notes;
    this._bottles = bottles;
    this.refs = {
      interactables: this.interactables,
      lightMats: this.lightMats,
      lightFX: this.lightFX,
      stairwellLamp: this._stairwell.lamp,
      breakerLever: this._breaker.lever,
      breakerLampOn: this._breaker.lampOn,
      stairwellDoor: this._stairwell.group,
      partyDoor: this._party.group,
      bottles: this._bottles,
      notePos: this._notes,
      partyDoorPos: this._party.pos,
      stairwellDoorPos: this._stairwell.pos,
      breakerPos: this._breaker.pos,
      radioPos: this.interactables.find((i) => i.kind === 'radio')!.pos,
      hubPos: (() => {
        const r = this.maze.roomAt.find((rr) => rr.kind === 'hub')!;
        return new THREE.Vector3((r.x + r.w / 2) * CELL, 0, (r.y + r.h / 2) * CELL);
      })(),
      breachPos: (() => {
        const bw = this.maze.breachWall;
        return new THREE.Vector3(bw.edgeX * CELL - WALL_T / 2 - 0.35, 1.1, (bw.cy + 0.5) * CELL);
      })(),
      hubEntry: this._hub ? { ...this._hub.entry } : { x: 300, z: 300.3, yaw: Math.PI },
      hubOutpost: this._hub ? this._hub.outpost.clone() : new THREE.Vector3(298, 0, 323.5),
      hubElevator: this._hub ? this._hub.elevator.clone() : new THREE.Vector3(300, 1.25, 342.6),
      hubLiftLamp: this._hub
        ? this._hub.elevatorLamp
        : new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), new THREE.MeshBasicMaterial()),
      hubLiftButton: this._hub
        ? this._hub.elevatorButton
        : new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), new THREE.MeshBasicMaterial()),
      hubWater: this._hub ? this._hub.water : null,
      hubMachineLever: this._hub ? this._hub.machineLever : null,
      hubMachineLampOff: this._hub ? this._hub.machineLampOff : null,
      hubMachineLampOn: this._hub ? this._hub.machineLampOn : null,
      hubMachineLight: this._hub ? this._hub.machineLight : null,
      hubMachinePos: this._hub ? this._hub.machinePos.clone() : null,
      hubWaterPos: this._hub ? this._hub.waterPos.clone() : null,
      hubGalleryMouth: this._hub ? this._hub.galleryMouth.clone() : null,
    };
  }
}

