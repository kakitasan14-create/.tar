// LightingFX - the fluorescent "alive lighting" rig for Level 0. Replaces the
// old fake volumetric cones with real-feeling fixtures:
//   - a soft glow halo directly under each live panel (the lens blooming)
//   - a warm light POOL cast on the carpet below each live panel
//   - a faint spill halo on the ceiling tiles around each fixture
// Everything is merged geometry per light group (steady + 3 flicker groups),
// additive, one draw call per mesh, driven by game-side group levels so
// flickering, surges and blackouts read as one electrical system.

import * as THREE from 'three';
import { WALL_H } from './maze';

export interface PanelSets {
  steady: THREE.Vector3[];
  flickerGroups: THREE.Vector3[][];
}

const GROUP_COUNT = 4; // 0 = steady, 1..3 = flicker groups

export class LightingFX {
  groupLevels: number[] = [1, 1, 1, 1];
  master = 1; // 0 during blackout
  surge = 0; // 0..1 extra brightness during power surges

  private glowMeshes: (THREE.Mesh | null)[] = [null, null, null, null];
  private poolMeshes: (THREE.Mesh | null)[] = [null, null, null, null];
  private spillMeshes: (THREE.Mesh | null)[] = [null, null, null, null];
  private mats: {
    glow: THREE.MeshBasicMaterial[];
    pool: THREE.MeshBasicMaterial[];
    spill: THREE.MeshBasicMaterial[];
  } = { glow: [], pool: [], spill: [] };

  constructor(private scene: THREE.Object3D, panels: PanelSets, glowTex: THREE.Texture) {
    const groups: THREE.Vector3[][] = [panels.steady, ...panels.flickerGroups];
    for (let g = 0; g < GROUP_COUNT; g++) {
      const list = groups[g] ?? [];
      if (list.length === 0) continue;

      const mkMat = (opacity: number): THREE.MeshBasicMaterial =>
        new THREE.MeshBasicMaterial({
          map: glowTex,
          transparent: true,
          opacity,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          fog: false,
          side: THREE.DoubleSide,
        });
      const glowMat = mkMat(0.85);
      const poolMat = mkMat(0.5);
      const spillMat = mkMat(0.16);
      this.mats.glow.push(glowMat);
      this.mats.pool.push(poolMat);
      this.mats.spill.push(spillMat);

      this.glowMeshes[g] = new THREE.Mesh(this.buildQuads(list, 'glow'), glowMat);
      this.poolMeshes[g] = new THREE.Mesh(this.buildQuads(list, 'pool'), poolMat);
      this.spillMeshes[g] = new THREE.Mesh(this.buildQuads(list, 'spill'), spillMat);
      for (const msh of [this.glowMeshes[g], this.poolMeshes[g], this.spillMeshes[g]]) {
        if (!msh) continue;
        msh.renderOrder = 5;
        msh.frustumCulled = false;
        this.scene.add(msh);
      }
    }
    this.apply();
  }

  /**
   * Merged radial-gradient quads for one light group. `kind` picks the flavor:
   * glow = downward halo right under the fixture, pool = big soft ellipse on
   * the carpet, spill = wide faint halo just below ceiling level.
   */
  private buildQuads(panels: THREE.Vector3[], kind: 'glow' | 'pool' | 'spill'): THREE.BufferGeometry {
    const pos: number[] = [];
    const uv: number[] = [];
    const idx: number[] = [];
    const pushQuad = (
      cx: number,
      cy: number,
      cz: number,
      w: number,
      d: number,
      rot: number
    ): void => {
      const base = pos.length / 3;
      const ca = Math.cos(rot);
      const sa = Math.sin(rot);
      const corners = [
        [-w / 2, -d / 2],
        [w / 2, -d / 2],
        [w / 2, d / 2],
        [-w / 2, d / 2],
      ];
      const uvs = [
        [0, 0],
        [1, 0],
        [1, 1],
        [0, 1],
      ];
      for (let i = 0; i < 4; i++) {
        const [ox, oz] = corners[i];
        pos.push(cx + ox * ca + oz * sa, cy, cz + -ox * sa + oz * ca);
        uv.push(uvs[i][0], uvs[i][1]);
      }
      idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    };

    for (const p of panels) {
      // keep quads aligned with the fixture rotation (game rotates panels by
      // (x+y)%2 * PI/2 - recover it from world position parity)
      const cellX = Math.floor(p.x / 3.6);
      const cellY = Math.floor(p.z / 3.6);
      const rot = (cellX + cellY) % 2 === 0 ? 0 : Math.PI / 2;
      if (kind === 'glow') {
        pushQuad(p.x, WALL_H - 0.1, p.z, 2.7, 1.8, rot);
      } else if (kind === 'pool') {
        pushQuad(p.x, 0.028, p.z, 3.6, 2.6, rot);
      } else {
        pushQuad(p.x, WALL_H - 0.16, p.z, 2.8, 2.0, rot);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    return geo;
  }

  /** Push current groupLevels/master/surge into the materials. */
  apply(): void {
    const boost = 1 + this.surge * 1.1;
    for (let g = 0; g < GROUP_COUNT; g++) {
      const lvl = this.groupLevels[g] * this.master * boost;
      const glow = this.glowMeshes[g];
      const pool = this.poolMeshes[g];
      const spill = this.spillMeshes[g];
      if (glow) {
        (glow.material as THREE.MeshBasicMaterial).color.setRGB(lvl * 1.0, lvl * 0.92, lvl * 0.72);
      }
      if (pool) {
        (pool.material as THREE.MeshBasicMaterial).color.setRGB(lvl * 0.62, lvl * 0.55, lvl * 0.4);
      }
      if (spill) {
        (spill.material as THREE.MeshBasicMaterial).color.setRGB(lvl * 0.2, lvl * 0.18, lvl * 0.13);
      }
    }
  }

  setGroupLevel(g: number, v: number): void {
    this.groupLevels[g] = Math.max(0, Math.min(1.2, v));
  }

  setMaster(v: number): void {
    this.master = Math.max(0, Math.min(1, v));
  }

  setSurge(v: number): void {
    this.surge = Math.max(0, Math.min(1, v));
  }

  dispose(): void {
    for (const set of [this.glowMeshes, this.poolMeshes, this.spillMeshes]) {
      for (const m of set) {
        if (!m) continue;
        this.scene.remove(m);
        m.geometry.dispose();
        (m.material as THREE.Material).dispose();
      }
    }
    this.glowMeshes = [null, null, null, null];
    this.poolMeshes = [null, null, null, null];
    this.spillMeshes = [null, null, null, null];
  }
}
