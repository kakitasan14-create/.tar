// The Backrooms: Level 0 - game orchestrator. Owns the renderer, world,
// input, dialogue queue, set-piece timelines (intro / blackout / endings),
// audio beds and the HUD bridge.

import * as THREE from 'three';
import { generateMaze, GRID, CELL, WALL_H, hasLOS } from './maze';
import { Level, Interactable } from './level';
import { buildTextures, GameTextures } from './textures';
import { Player } from './player';
import { Entity } from './entity';
import { AudioEngine } from './audio';
import { VHSPass } from './vhs';
import { NOTES, SCRIPTS, DialogueLine } from './content';
import { useGameUI } from './store';
import { mulberry32 } from './rng';
import * as P from './props';

type EngineState = 'idle' | 'intro' | 'playing' | 'dying' | 'cine' | 'over';
type Phase = 'explore' | 'blackout' | 'escape';

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export class BackroomsGame {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private vhs: VHSPass;
  private world = new THREE.Group();

  private audio = new AudioEngine();
  private tex: GameTextures;
  private maze!: ReturnType<typeof generateMaze>;
  private level!: Level;
  private player: Player;
  private entity!: Entity;
  private rand: () => number;

  private ambient!: THREE.AmbientLight;
  private hemi!: THREE.HemisphereLight;
  private camLight!: THREE.PointLight;

  // dynamic light pool: a set of point lights recycled onto the nearest live
  // ceiling panels so corridors are actually illuminated by the fixtures.
  // group 0 = steady circuits, 1..3 = the three independent flicker circuits
  private lightPool: { light: THREE.PointLight; group: number; base: number }[] = [];
  private poolAssignT = 0;

  // title screen set: camcorder prop + live LCD feed
  private feedCam!: THREE.PerspectiveCamera;
  private feedRT!: THREE.WebGLRenderTarget;
  private camcorder: { group: THREE.Group; recLed: THREE.Mesh; recDot: THREE.Mesh } | null = null;
  private menuCamBase = { x: 0, y: 0.24, z: 0, yaw: 0, pitch: 0 };
  private feedFrame = 0;

  // viewfinder state: the tape (VHS pipeline) only exists once the camcorder is
  // grabbed, and the picture is only "through the lens" while it is raised
  private tapeOn = false;
  private camAnim = 1; // 0 = lowered, 1 = raised at the eye
  private camGoal = 1;
  private vm: THREE.Group | null = null;
  private vmRecLed: THREE.Mesh | null = null;
  private vmLcd: THREE.Group | null = null;
  private vmLight: THREE.PointLight | null = null;
  private vmAmb: THREE.AmbientLight | null = null;
  private vmSway = { x: 0, y: 0 };
  private glitchBurst = 0; // static spike covering tape power cuts
  private lensTrack = 0; // 0..1 interference strength while the Smiler is on-camera
  private camcorderPos = { x: 0, z: 0 };
  private lcdAnim = 0; // 0 = flip-out screen folded, 1 = swung open at the eye
  private swAnim = 0; // smoothed 0..1 "screen swallows the view" glide
  private feedYawLag = 0; // the LCD feed lags the view like a real device
  private static readonly VM_RAISED = { x: 0.175, y: -0.17, z: -0.4, rx: 0.02, ry: -0.09, rz: -0.03 };
  private static readonly VM_LOWERED = { x: 0.26, y: -0.38, z: -0.5, rx: 0.42, ry: -0.38, rz: 0.1 };
  // final approach pose: the LCD arrives straight at the operator's head, so
  // the unit glides to eye-center before the prop is hidden entirely
  private static readonly VM_EYE = { x: 0.03, y: -0.12, z: -0.3, rx: -0.14, ry: 0.02, rz: 0 };

  // dynamic resolution: the canvas + tape RT shrink when the frame rate sags
  // on weak GPUs and grow back when there is headroom (small rate-limited
  // steps so it reads as tape quality, never as a visible switch)
  private resScale = 1;
  private frameAvg = 16;
  private resCheckT = 3; // warmup: let shaders settle before judging frames
  private resCooldown = 0;

  private engineState: EngineState = 'idle';
  private phase: Phase = 'explore';
  private inHub = false; // The Hub: the Smiler cannot follow, no death, no maze logic
  private rumbleShake = 0; // ending C: lift-cage climb shake ramp
  private raf = 0;
  private lastT = 0;
  private elapsed = 0;
  private disposed = false;

  // dialogue
  private queue: DialogueLine[] = [];
  private dialogueAuto = 0;

  // triggers
  private flags: Record<string, boolean> = {};
  private triggerTimers: Record<string, number> = {};

  // blackout
  private blackoutTimer = 0;
  private blackoutKnow = 0;

  // cinematic
  private introT = 0;
  private cine: { type: 'A' | 'B' | 'C'; t: number } | null = null;
  private dieT = 0;

  // fx levels
  private tearLevel = 0;
  private staticBase = 0.07;

  // flicker: three independent lighting circuits buzz and blink on their own
  private flickGroups: { on: boolean; next: number; level: number }[] = [
    { on: true, next: 1.7, level: 1 },
    { on: true, next: 3.3, level: 1 },
    { on: true, next: 5.2, level: 1 },
  ];
  // power surges: brief bright spikes that make the rooms feel wired alive
  private surgeT = 0;
  private nextSurge = 30;
  private baseAmbient = 0.55;
  private baseHemi = 0.62;

  // ambience events
  private nextEvent = 16;

  // hud throttle
  private hudAcc = 0;

  // water cloud cooldown
  private cloudCooldown = 0;

  // stats
  private notesFound = 0;
  private watersDrunk = 0;
  private deaths = 0;

  private currentTarget: Interactable | null = null;

  // input
  private keys = new Set<string>();
  private dragging = false;
  private touchMode = false;

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      stencil: false,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    // manual info accounting: autoReset would leave only the final post-quad
    // blit (1 call / 2 tris) in the stats after each frame - reset at frame
    // start instead so perf() reports the whole frame (scene + vm + post)
    this.renderer.info.autoReset = false;

    this.camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 55);
    // far 55 (was 70): FogExp2 @0.038 leaves <2% contrast at 50m, so nothing
    // readable is clipped - but the shorter frustum lets the chunked walls +
    // props cull ~30% more of the map every frame
    this.scene.add(this.camera);
    this.scene.add(this.world);
    this.scene.background = new THREE.Color(0x0d0a04);
    this.scene.fog = new THREE.FogExp2(0x0d0a04, 0.052);

    this.ambient = new THREE.AmbientLight(0xffedb8, 0.55);
    this.hemi = new THREE.HemisphereLight(0xfff3cf, 0x241a08, 0.6);
    this.scene.add(this.ambient, this.hemi);
    this.camLight = new THREE.PointLight(0xffe6a8, 8.5, 12, 1.7);
    this.camera.add(this.camLight);

    // dynamic fluorescent light pool (9 active lights is the perf ceiling:
    // every light in the scene is paid per-pixel by the MeshStandard walls,
    // so the pool size dominates the frame cost on weak GPUs)
    for (let i = 0; i < 9; i++) {
      const l = new THREE.PointLight(0xffedb0, 0, 10.5, 1.55);
      this.scene.add(l);
      this.lightPool.push({ light: l, group: 0, base: 0 });
    }

    this.player = new Player(this.camera);
    // NOTE: the flashlight + its target are children of the camera, so the beam
    // follows the view direction. Do NOT re-add the target to the scene - that
    // orphans it at a fixed world position and the beam stops tracking the view.

    const seed = (Math.random() * 1e9) | 0;
    this.rand = mulberry32(seed);
    this.tex = buildTextures(seed);

    this.vhs = new VHSPass(
      Math.floor(window.innerWidth * 0.75),
      Math.floor(window.innerHeight * 0.75)
    );
    this.vhs.setLevel(useGameUI.getState().vhsLevel);

    // title-screen live feed camera + target
    this.feedCam = new THREE.PerspectiveCamera(64, 1.6, 0.05, 40);
    this.feedRT = new THREE.WebGLRenderTarget(256, 160, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: true,
    });

    this.buildWorld();

    // Precompile everything that would otherwise hitch the first time it is
    // used in-game: build the (holstered) viewmodel, run the depth-cleared vm
    // pass once, then push one frame through the full VHS tape pass.
    this.buildViewmodel();
    this.vm!.visible = true;
    this.renderViewmodelOverlay();
    this.vm!.visible = false;
    // one synchronous compile of every visible world material - wall chunks,
    // props, the Hub at the far end of the map and the (usually hidden)
    // Smiler. Without this the first look at each compiles GLSL mid-frame and
    // shows up as a one-off stutter right when things get exciting.
    this.entity.group.visible = true;
    this.renderer.compile(this.scene, this.camera);
    this.entity.group.visible = false;
    this.vhs.set(0, this.staticBase, 0);
    this.vhs.render(this.renderer, this.scene, this.camera, () => this.renderViewmodelOverlay());

    this.applyResolution();
    this.bindInput();
    window.addEventListener('resize', this.onResize);
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  /** Applies the current resolution scale to the canvas + tape RT. */
  private applyResolution(): void {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    this.renderer.setPixelRatio(dpr * this.resScale);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    const w = Math.max(160, Math.floor(window.innerWidth * 0.75 * this.resScale));
    const h = Math.max(100, Math.floor(window.innerHeight * 0.75 * this.resScale));
    this.vhs.setSize(w, h);
  }

  // ---------------- world ----------------

  private buildWorld(): void {
    this.maze = generateMaze((this.rand() * 1e9) | 0);
    this.level = new Level(this.world, this.maze, this.tex, (this.rand() * 1e9) | 0);
    this.level.build();
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    this.player.reset(sw.x, sw.z, Math.PI * 0.25);
    this.camera.position.set(sw.x, 1.62, sw.z);

    const evts = {
      onFootstep: (_h: boolean, _p: number, _v: number) => {
        const d = Math.hypot(this.entity.pos.x - this.camera.position.x, this.entity.pos.z - this.camera.position.z);
        const vol = clamp01(1.15 - d / 22);
        this.audio.step('entity', this.panTo(this.entity.pos.x, this.entity.pos.z), vol);
      },
      onDetect: () => {
        this.audio.sting('detect', this.panTo(this.entity.pos.x, this.entity.pos.z));
        this.tearLevel = 0.4;
      },
      onLunge: (pan: number, vol: number) => {
        // it is CHARGING - scream, tape screams too
        this.audio.sting('detect', pan);
        this.tearLevel = Math.max(this.tearLevel, 0.35 + vol * 0.2);
      },
      onTransition: (from: string, to: string) => {
        if (to === 'hunt' && from !== 'hunt') this.audio.sting('detect', this.panTo(this.entity.pos.x, this.entity.pos.z));
      },
    };
    this.entity = new Entity(this.maze, this.tex, evts);
    this.entity.setLightField(this.level); // the Smiler reads the light map
    this.world.add(this.entity.group);
    this.entity.sendFar(sw.x, sw.z, 20, this.rand);

    useGameUI.getState().set({ notesTotal: NOTES.length });
    this.stageMenuSet();
  }

  /** Places the camcorder + menu camera and aims the live-feed camera down a lit corridor. */
  private stageMenuSet(): void {
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    const ccPos = { x: sw.x + 1.0, z: sw.z + 0.62 };

    const cc = P.buildCamcorder(this.feedRT.texture);
    cc.group.position.set(ccPos.x, 0, ccPos.z);
    cc.group.rotation.y = 0.25; // 3/4 hero angle: silver lens + sticker in shot, LCD open
    this.world.add(cc.group);
    this.camcorder = cc;
    this.camcorderPos = { x: ccPos.x, z: ccPos.z };
    if (this.vm) this.vm.visible = false; // the viewmodel stays holstered on the menu

    // find a corridor shot: two steady panels with line of sight between them
    let placed = false;
    const panels = this.level.panelPos.steady;
    outer: for (let i = 0; i < panels.length; i++) {
      const a = panels[i];
      for (let j = i + 1; j < Math.min(panels.length, i + 14); j++) {
        const b = panels[j];
        const d = Math.hypot(a.x - b.x, a.z - b.z);
        if (d < 4.5 || d > 13.5) continue;
        if (!hasLOS(this.maze, a.x, a.z, b.x, b.z)) continue;
        this.feedCam.position.set(a.x, WALL_H - 0.5, a.z);
        this.feedCam.lookAt(b.x, WALL_H - 0.75, b.z);
        placed = true;
        break outer;
      }
    }
    if (!placed) {
      // fallback: hover above the spawn room looking down at the camcorder
      this.feedCam.position.set(sw.x, WALL_H - 0.35, sw.z);
      this.feedCam.lookAt(ccPos.x, 0.1, ccPos.z);
    }

    // low, intimate menu camera framing the camcorder (reference: LCD in frame)
    const EYE_Y = 0.24;
    const mx = ccPos.x - 0.52;
    const mz = ccPos.z + 0.92;
    // aim slightly left of the camcorder so it sits right-of-center like the ref
    const aimX = ccPos.x - 0.14;
    const aimZ = ccPos.z;
    const dx = aimX - mx;
    const dz = aimZ - mz;
    const horiz = Math.hypot(dx, dz) || 1;
    this.menuCamBase = {
      x: mx,
      y: EYE_Y,
      z: mz,
      yaw: Math.atan2(-dx, -dz),
      pitch: Math.atan2(0.09 - EYE_Y, horiz),
    };
    this.camera.fov = 42; // tighter lens for the close-up feel
    this.camera.updateProjectionMatrix();
    this.camLight.intensity = 2.4; // soft warm fill for the little scene
  }

  private updateMenu(dt: number): void {
    const t = performance.now() / 1000;
    const b = this.menuCamBase;
    // slow handheld breathing on the locked-off shot
    this.camera.position.set(b.x + Math.cos(t * 0.33) * 0.01, b.y + Math.sin(t * 0.5) * 0.011, b.z + Math.sin(t * 0.21) * 0.008);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = b.yaw + Math.sin(t * 0.4) * 0.006;
    this.camera.rotation.x = b.pitch + Math.sin(t * 0.27) * 0.004;
    this.camera.rotation.z = Math.sin(t * 0.18) * 0.0022;
    // keep the world alive behind the title: blinking circuits, drifting pools
    this.updateFlicker(dt);
    this.updateSurge(dt);
    this.updateLightPool(dt);
    // blink the REC led + on-screen dot
    if (this.camcorder) {
      const on = Math.floor(t * 1.7) % 2 === 0;
      (this.camcorder.recLed.material as THREE.MeshBasicMaterial).color.set(on ? 0xff2a22 : 0x350c0a);
      this.camcorder.recDot.visible = on;
    }
  }

  private disposeWorld(): void {
    this.world.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((mm) => mm.dispose());
      else if (mat) mat.dispose();
    });
    this.world.clear();
  }

  // ---------------- input ----------------

  private bindInput(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    document.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('mousedown', this.onMouseDown);
    document.addEventListener('mouseup', this.onMouseUp);
    document.addEventListener('pointerlockchange', this.onLockChange);
    this.canvas.addEventListener('click', this.onCanvasClick);
    this.canvas.addEventListener('contextmenu', this.onCtx); // RMB toggles the camcorder
    this.touchMode = 'ontouchstart' in window && window.matchMedia('(pointer: coarse)').matches;
    useGameUI.getState().set({ touch: this.touchMode });
  }

  private onCtx = (e: MouseEvent): void => {
    e.preventDefault();
  };

  private onResize = (): void => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.applyResolution();
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.code === 'Space') e.preventDefault();
    if (this.keys.has(e.code)) return;
    this.keys.add(e.code);
    const ui = useGameUI.getState();
    if (ui.screen === 'playing') {
      if (e.code === 'Space' || e.code === 'Enter') {
        if (ui.noteOpen) this.closeNote();
        else this.advanceDialogue();
      }
      if (e.code === 'KeyE') {
        if (ui.noteOpen) this.closeNote();
        else this.tryInteract();
      }
      if (e.code === 'KeyQ') this.drinkWater();
      // J / C / RMB: TOGGLE the camcorder up or down - no holding required
      if (e.code === 'KeyC' || e.code === 'KeyJ') this.toggleCamcorder();
      if (e.code === 'KeyF') {
        this.player.toggleFlashlight();
        useGameUI.getState().set({ flashOn: this.player.flashlightOn });
      }
      if (e.code === 'Escape') {
        this.pause();
      }
    } else if (ui.screen === 'intro') {
      if (e.code === 'Space' || e.code === 'Enter' || e.code === 'KeyE') this.skipIntro();
    }
    if (ui.screen === 'playing' || ui.screen === 'intro') {
      switch (e.code) {
        case 'KeyW': case 'ArrowUp': this.player.input.f = true; break;
        case 'KeyS': case 'ArrowDown': this.player.input.b = true; break;
        case 'KeyA': case 'ArrowLeft': this.player.input.l = true; break;
        case 'KeyD': case 'ArrowRight': this.player.input.r = true; break;
        case 'ShiftLeft': case 'ShiftRight': this.player.input.sprint = true; break;
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
    switch (e.code) {
      case 'KeyW': case 'ArrowUp': this.player.input.f = false; break;
      case 'KeyS': case 'ArrowDown': this.player.input.b = false; break;
      case 'KeyA': case 'ArrowLeft': this.player.input.l = false; break;
      case 'KeyD': case 'ArrowRight': this.player.input.r = false; break;
      case 'ShiftLeft': case 'ShiftRight': this.player.input.sprint = false; break;
    }
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (useGameUI.getState().screen !== 'playing') return;
    if (document.pointerLockElement === this.canvas) {
      this.player.input.lookDX += e.movementX;
      this.player.input.lookDY += e.movementY;
    } else if (this.dragging) {
      this.player.input.lookDX += e.movementX * 1.4;
      this.player.input.lookDY += e.movementY * 1.4;
    }
    // viewmodel drag: the camera hand lags behind fast glances
    this.vmSway.x += e.movementX * 0.5;
    this.vmSway.y += e.movementY * 0.5;
    this.vmSway.x = Math.max(-120, Math.min(120, this.vmSway.x));
    this.vmSway.y = Math.max(-120, Math.min(120, this.vmSway.y));
  };

  private onMouseDown = (e: MouseEvent): void => {
    const ui = useGameUI.getState();
    if (ui.screen !== 'playing') return;
    if ((e.target as HTMLElement)?.tagName === 'CANVAS' || document.pointerLockElement === this.canvas) {
      this.dragging = true;
    }
    if (e.button === 2) this.toggleCamcorder(); // RMB tap: toggle the camcorder
  };

  private onMouseUp = (e: MouseEvent): void => {
    this.dragging = false;
  };

  private onCanvasClick = (): void => {
    const ui = useGameUI.getState();
    if (ui.screen !== 'playing' || this.touchMode) return;
    if (document.pointerLockElement !== this.canvas) {
      this.requestLock();
    }
  };

  private onLockChange = (): void => {
    const ui = useGameUI.getState();
    if (document.pointerLockElement !== this.canvas && ui.screen === 'playing' && !this.touchMode) {
      this.setScreen('paused');
    }
  };

  requestLock(): void {
    if (this.touchMode) return;
    try {
      const p = this.canvas.requestPointerLock() as unknown as Promise<void> | undefined;
      if (p && typeof p.catch === 'function') p.catch(() => undefined);
    } catch {
      /* pointer lock unavailable - drag-look fallback stays active */
    }
  }

  // ---------------- public API (React) ----------------

  startRun(): void {
    this.audio.init();
    this.audio.resume();
    this.audio.setAmbience(1, 1);
    this.audio.setStatic(this.staticBase);
    this.setLights(true); // restore camLight intensity + cones for gameplay
    this.touchMode = useGameUI.getState().touch;
    this.player.sens = [0.6, 1, 1.5][useGameUI.getState().sensLevel] ?? 1;
    this.startIntro();
  }

  resume(): void {
    this.audio.resume();
    this.setScreen('playing');
    this.requestLock();
  }

  pause(): void {
    const ui = useGameUI.getState();
    if (ui.screen === 'playing') this.setScreen('paused');
  }

  toMenu(): void {
    this.resetRun();
    useGameUI.getState().set({ menuPanel: 'root', exitToast: null });
    this.setScreen('menu');
  }

  /** Ending screen "NEW TAPE": a genuinely fresh tape - regenerated maze,
   *  zeroed stats, back into the wake-up intro. (retry() rewinds the SAME tape.) */
  newTape(): void {
    this.resetRun();
    this.startRun();
  }

  retry(): void {
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    this.inHub = false;
    this.player.reset(sw.x, sw.z, Math.PI * 0.25);
    this.player.stamina = 1;
    this.entity.sendFar(sw.x, sw.z, 8, this.rand);
    this.tearLevel = 0;
    // the tape is already rolling after a rewind: force the viewfinder up
    this.camAnim = 1;
    this.camGoal = 1;
    if (!this.tapeOn) this.powerTape(true);
    this.audio.setStatic(this.staticBase);
    this.audio.setAmbience(1, 1);
    if (this.phase === 'blackout') {
      this.restorePower();
      this.phase = 'escape';
      this.playScript('kStairwellReady');
      this.setObjective('ESCAPE', 'stairwell E7 is live - go, do not look back');
    }
    this.setScreen('playing');
    this.requestLock();
  }

  setMuted(m: boolean): void {
    this.audio.setMuted(m);
    useGameUI.getState().set({ muted: m });
  }

  /** Menu UI sounds (safe to call before/without a run - no-ops without audio). */
  uiTick(): void {
    this.audio.sting('uiTick');
  }

  uiConfirm(): void {
    this.audio.sting('uiConfirm');
  }

  setVhsLevel(level: number): void {
    this.vhs.setLevel(level);
    useGameUI.getState().set({ vhsLevel: level });
  }

  /** Mouse look sensitivity: 0 slow · 1 normal · 2 fast. Live-applies mid-run. */
  setSensLevel(level: number): void {
    const l = ((level % 3) + 3) % 3;
    this.player.sens = [0.6, 1, 1.5][l] ?? 1;
    useGameUI.getState().set({ sensLevel: l });
  }

  /** EXIT menu item: eject the tape and try to close the tab. */
  exitToDesktop(): void {
    useGameUI.getState().set({ exitToast: 'EJECTING TAPE...' });
    window.setTimeout(() => {
      window.close();
    }, 400);
    window.setTimeout(() => {
      if (!this.disposed) useGameUI.getState().set({ exitToast: 'EJECT FAILED - THE TAPE RESISTS' });
    }, 1300);
    window.setTimeout(() => {
      if (!this.disposed) useGameUI.getState().set({ exitToast: null });
    }, 4600);
  }

  // touch API
  touchLook(dx: number, dy: number): void {
    this.player.input.lookDX += dx;
    this.player.input.lookDY += dy;
  }
  setTouchMove(x: number, y: number): void {
    this.player.touchMove.x = x;
    this.player.touchMove.y = y;
  }
  setTouchSprint(on: boolean): void {
    this.player.input.sprint = on;
  }

  advanceDialogue(): void {
    const ui = useGameUI.getState();
    if (!ui.dialogue) return;
    if (!ui.dialogueDone) {
      ui.set({ dialogueDone: true });
      return;
    }
    this.showNextLine();
  }

  closeNote(): void {
    useGameUI.getState().set({ noteOpen: null });
  }

  // ---------------- dialogue ----------------

  private playScript(name: string): void {
    const script = SCRIPTS[name];
    if (!script) return;
    if (this.flags[`script-${name}`]) return;
    this.flags[`script-${name}`] = true;
    const wasEmpty = this.queue.length === 0;
    this.queue.push(...script.map((l) => ({ ...l })));
    if (wasEmpty) this.showNextLine();
  }

  private showNextLine(): void {
    const line = this.queue.shift();
    if (!line) {
      useGameUI.getState().set({ dialogue: null, dialogueDone: false });
      this.audio.setRadio(false);
      return;
    }
    useGameUI.getState().set({ dialogue: line, dialogueDone: false });
    if (line.garble) {
      this.audio.setRadio(true);
      this.audio.radioGarble(0.5);
    }
    this.dialogueAuto = performance.now() / 1000 + Math.max(2.4, line.text.length * 0.052);
  }

  private updateDialogue(): void {
    const ui = useGameUI.getState();
    if (ui.dialogue && performance.now() / 1000 > this.dialogueAuto) {
      this.showNextLine();
    }
  }

  // ---------------- interaction ----------------

  // scratch vectors for the per-frame interactable scan (no per-frame allocs)
  private _tgtFwd = new THREE.Vector3();
  private _tgtFwdH = new THREE.Vector3();
  private _tgtTo = new THREE.Vector3();
  private lastPrompt = '';

  private updateTarget(): void {
    const camPos = this.camera.position;
    const fwd = this._tgtFwd;
    this.camera.getWorldDirection(fwd);
    // horizontal facing (floor items should not require staring at your feet)
    const fwdH = this._tgtFwdH.set(fwd.x, 0, fwd.z).normalize();
    let best: Interactable | null = null;
    let bestScore = -Infinity;
    for (const it of this.level.interactables) {
      if (!it.active) continue;
      const d = Math.hypot(it.pos.x - camPos.x, it.pos.z - camPos.z);
      if (d > it.radius) continue;
      const to = this._tgtTo.set(it.pos.x - camPos.x, 0, it.pos.z - camPos.z).normalize();
      const dot = to.dot(fwdH);
      if (dot < 0.35) continue;
      const score = dot - d * 0.05;
      if (score > bestScore) {
        bestScore = score;
        best = it;
      }
    }
    this.currentTarget = best;
    let prompt = '';
    if (best) {
      switch (best.kind) {
        case 'note': prompt = 'READ PAGE'; break;
        case 'water': prompt = 'TAKE ALMOND WATER'; break;
        case 'lever': prompt = this.flags.leverPulled ? '' : 'PULL MAINS BREAKER'; break;
        case 'doorStair': prompt = this.phase === 'escape' ? 'DESCEND TO LEVEL 1' : 'STAIRWELL E7 - NO POWER'; break;
        case 'doorParty': prompt = 'OPEN THE HUMMING DOOR'; break;
        case 'radio': prompt = 'RADIO - LISTEN'; break;
        case 'doorHub': prompt = 'CRAWL THROUGH THE HOLE'; break;
        case 'radioOutpost': prompt = 'OUTPOST RADIO - LISTEN'; break;
        case 'hubLever': prompt = this.flags.hubPowered ? '' : 'SHUT DOWN THE PUMP RIG'; break;
        case 'elevator': prompt = this.flags.hubPowered ? 'CALL THE FREIGHT LIFT' : 'FREIGHT LIFT - NO POWER'; break;
      }
    }
    // only touch the React store when the prompt actually changed (this runs
    // every frame - unguarded it re-rendered the whole HUD 60x per second)
    if (prompt !== this.lastPrompt) {
      this.lastPrompt = prompt;
      useGameUI.getState().set({ prompt });
    }
  }

  /** Touch UI: toggles the flashlight (mirrors the F key). */
  toggleFlashlight(): void {
    this.player.toggleFlashlight();
    useGameUI.getState().set({ flashOn: this.player.flashlightOn });
  }

  /** Touch UI + keyboard: uses the current interactable target. */
  tryInteract(): void {
    const it = this.currentTarget;
    if (!it) return;
    switch (it.kind) {
      case 'note': {
        const data = it.data as { id: number };
        it.active = false;
        if (it.mesh) it.mesh.visible = false;
        this.notesFound++;
        this.audio.sting('paper');
        this.entity.hearNoise(this.player.pos.x, this.player.pos.z, 3);
        useGameUI.getState().set({
          noteOpen: NOTES[data.id],
          notes: this.notesFound,
          prompt: '',
        });
        break;
      }
      case 'water': {
        it.active = false;
        if (it.mesh) it.mesh.visible = false;
        const ui = useGameUI.getState();
        ui.set({ water: ui.water + 1 });
        this.audio.sting('pickup');
        if (!this.flags.kWater) {
          this.flags.kWater = true;
          this.playScript('kWater');
        }
        break;
      }
      case 'lever': {
        if (this.flags.leverPulled) return;
        this.flags.leverPulled = true;
        this.onLeverPulled();
        break;
      }
      case 'doorStair': {
        if (this.phase === 'escape') this.startEnding('A');
        else {
          this.audio.sting('thud');
          if (!this.flags.doorLockedMsg) {
            this.flags.doorLockedMsg = true;
            this.queue.push({ speaker: 'YOU', text: 'Dead lamps. It needs mains power from somewhere.' });
            if (useGameUI.getState().dialogue === null) this.showNextLine();
          }
        }
        break;
      }
      case 'doorParty': {
        this.startEnding('B');
        break;
      }
      case 'doorHub': {
        this.crawlThrough();
        break;
      }
      case 'radioOutpost': {
        if (!this.flags['script-kOutpost']) {
          this.playScript('kOutpost');
        } else {
          this.audio.radioGarble(0.4);
          this.queue.push({ speaker: 'K', text: 'The Hub is still holding. Keep moving - and mind the hole.', garble: true });
          if (useGameUI.getState().dialogue === null) this.showNextLine();
        }
        break;
      }
      case 'hubLever': {
        if (this.flags.hubPowered) return;
        this.flags.hubPowered = true;
        this.onHubPowerDown();
        break;
      }
      case 'elevator': {
        if (!this.flags.hubPowered) {
          this.audio.sting('thud');
          this.playScript('kLiftNoPower');
          this.setObjective('RESTORE POWER', 'the pump rig drinks the mains - follow the water east');
        } else {
          this.startEnding('C');
        }
        break;
      }
      case 'radio': {
        if (!this.flags['script-kIntro']) {
          this.playScript('kIntro');
        } else {
          this.audio.radioGarble(0.4);
          this.queue.push({ speaker: 'K', text: 'Stay sharp out there. And quiet.', garble: true });
          if (useGameUI.getState().dialogue === null) this.showNextLine();
        }
        break;
      }
    }
  }

  drinkWater(): void {
    const ui = useGameUI.getState();
    if (ui.water <= 0 || this.player.stamina > 0.97) return;
    ui.set({ water: ui.water - 1 });
    this.watersDrunk++;
    this.player.stamina = 1;
    this.player.exhausted = false;
    this.audio.sting('drink');
    this.entity.hearNoise(this.player.pos.x, this.player.pos.z, 9);
    if (this.cloudCooldown <= 0 && (this.entity.state === 'hunt' || this.entity.state === 'search')) {
      // the scent clouds its nose - it loses your trail
      this.entity.lastHeard = null;
      this.entity.lastSeen = null;
      this.entity.state = 'stalk';
      this.entity.stateTimer = 2;
      this.cloudCooldown = 30;
      this.tearLevel = 0.22;
    }
  }

  // ---------------- The Hub ----------------

  /** Pump rig shutdown: the siphon stops, the lift circuit goes live. */
  private onHubPowerDown(): void {
    this.audio.sting('lever');
    const L = this.level.refs;
    if (L.hubMachineLampOff) L.hubMachineLampOff.visible = false;
    if (L.hubMachineLampOn) L.hubMachineLampOn.visible = true;
    if (L.hubMachineLight) {
      L.hubMachineLight.color.set(0x49ff70);
      L.hubMachineLight.intensity = 0.7;
    }
    (L.hubLiftButton.material as THREE.MeshBasicMaterial).color.set(0x35ff5e);
    (L.hubLiftLamp.material as THREE.MeshBasicMaterial).color.set(0x39ff6a);
    this.playScript('kMachine');
    this.setObjective('CALL THE LIFT', 'cage circuit live - the lift waits at the end of the line');
  }

  /** Interacting with the breach: dialogue, fade to black, crawl, arrive. */
  private crawlThrough(): void {
    if (this.flags.hubCrawled) return;
    this.flags.hubCrawled = true;
    this.audio.sting('paper'); // wallpaper tear + scrape
    this.audio.sting('thud');
    this.playScript('kHubEnter');
    this.entity.hearNoise(this.player.pos.x, this.player.pos.z, 6);
    useGameUI.getState().set({ fade: true, prompt: '' });
    window.setTimeout(() => {
      if (this.disposed) return;
      this.enterHubWorld();
      window.setTimeout(() => {
        if (!this.disposed) useGameUI.getState().set({ fade: false });
      }, 400);
    }, 1150);
  }

  /** Teleport into the tunnel network: the Smiler stays behind, forever. */
  private enterHubWorld(): void {
    this.inHub = true;
    const e = this.level.refs.hubEntry;
    this.player.reset(e.x, e.z, e.yaw);
    this.camera.position.set(e.x, 1.62, e.z);
    if (this.phase === 'blackout') {
      // crawling away from the dark ends the blackout set piece early
      this.phase = 'escape';
      this.restorePower();
      this.entity.sendFar(this.player.pos.x, this.player.pos.z, 6, this.rand);
      this.entity.aggressive = true;
      this.playScript('kBlackoutEnd');
    }
    this.entity.state = 'dormant';
    this.entity.stateTimer = 1e9; // never wakes on its own in here
    this.audio.setAmbience(0.3, 0.75); // less fluorescent hum, more room tone
    this.audio.setMusicBox(false, 0);
    this.playScript('kHubArrive');
    this.setObjective('FOLLOW THE TUNNEL', 'concrete. lamps. quiet. follow the bulbs');
    this.tearLevel = 0.45; // tape re-syncs after the transition
    this.glitchBurst = 0.55;
  }

  /** Debug/testing hook: instant crawl (skip the walk to the breach). */
  debugEnterHub(): void {
    if (useGameUI.getState().screen !== 'playing') return;
    this.flags.hubCrawled = true;
    this.enterHubWorld();
    useGameUI.getState().set({ fade: false });
  }

  // ---------------- set pieces ----------------

  private startIntro(): void {
    this.engineState = 'intro';
    this.introT = 0;
    // the tape does not exist yet: you wake up with your OWN eyes (clean render)
    this.tapeOn = false;
    this.camAnim = 0;
    this.camGoal = 0;
    this.vmSway.x = 0;
    this.vmSway.y = 0;
    this.glitchBurst = 0;
    this.camera.fov = 72; // naked-eye lens until the camcorder powers on
    this.camera.updateProjectionMatrix();
    this.camLight.intensity = 3.2; // dimmer during the wake-up: eyes adjusting
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    // no-clip arrival: falling out of reality onto the carpet
    this.camera.position.set(sw.x, 2.6, sw.z);
    this.camera.rotation.set(0.5, Math.PI * 0.25, 0.6, 'YXZ');
    useGameUI.getState().set({
      screen: 'intro',
      eyelids: true,
      fade: false,
      dialogue: null,
      camRaised: false,
      tracked: false,
    });
    if (this.vm) this.vm.visible = false;
    this.audio.setAmbience(1, 1);
  }

  private skipIntro(): void {
    this.introT = 999;
  }

  /** Yaw/pitch to look at the floor camcorder from the spawn pose. */
  private aimAtCamcorder(fromX: number, fromY: number, fromZ: number): { yaw: number; pitch: number } {
    const dx = this.camcorderPos.x - fromX;
    const dz = this.camcorderPos.z - fromZ;
    const dy = 0.07 - fromY;
    const yaw = Math.atan2(-dx, -dz);
    const pitch = Math.asin(Math.max(-1, Math.min(1, dy / (Math.hypot(dx, dz, dy) || 1))));
    return { yaw, pitch };
  }

  private updateIntro(dt: number): void {
    this.introT += dt;
    const t = this.introT;
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    const ui = useGameUI.getState();
    // the room breathes while you wake up: flicker circuits + drifting pools
    this.updateFlicker(dt);
    this.updateSurge(dt);
    this.updateLightPool(dt);
    if (t > 1.2 && !this.flags['intro-lines']) {
      this.flags['intro-lines'] = true;
      this.playScript('intro');
    }
    // the floor prop's REC led blinks, waiting to be found
    if (this.camcorder) {
      const on = Math.floor(t * 1.7) % 2 === 0;
      (this.camcorder.recLed.material as THREE.MeshBasicMaterial).color.set(on ? 0xff2a22 : 0x350c0a);
    }
    if (t < 0.95) {
      // no-clip fall: tumbling out of reality, then the thud
      const k = Math.min(1, t / 0.95);
      const e = k * k;
      this.camera.position.set(sw.x, 2.6 - e * 2.1, sw.z);
      this.camera.rotation.set(0.5 + e * 0.55, Math.PI * 0.25, 0.6 * (1 - e * 0.7), 'YXZ');
      if (t > 0.88 && !this.flags['intro-thud']) {
        this.flags['intro-thud'] = true;
        this.audio.sting('thud');
        this.audio.step('walk', 0, 1.2);
      }
    } else if (t < 2.8) {
      // lying on the floor, staring at a flickering light - no VHS, naked eyes
      this.camera.position.set(sw.x + Math.sin(t * 0.5) * 0.03, 0.5, sw.z);
      this.camera.rotation.set(1.05, Math.PI * 0.25 + Math.sin(t * 0.3) * 0.05, 0, 'YXZ');
      if (t > 1.7 && ui.eyelids) ui.set({ eyelids: false });
    } else if (t < 3.6) {
      // notice the camcorder blinking on the carpet: turn the head toward it
      const k = Math.min(1, (t - 2.8) / 0.8);
      const e = k * k * (3 - 2 * k);
      const look = this.aimAtCamcorder(sw.x, 0.5, sw.z);
      const baseYaw = Math.PI * 0.25 + Math.sin(t * 0.3) * 0.05;
      let dyaw = look.yaw - baseYaw;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      this.camera.position.set(sw.x, 0.5, sw.z);
      this.camera.rotation.set(1.05 * (1 - e) + look.pitch * e, baseYaw + dyaw * e, 0, 'YXZ');
    } else if (t < 5.0) {
      // the grab: the camcorder lifts off the carpet toward the reaching hand
      const k = Math.min(1, (t - 3.6) / 1.4);
      const e = k * k * (3 - 2 * k);
      const cam = this.camera;
      cam.updateMatrixWorld();
      const grab = new THREE.Vector3(0.19, -0.2, -0.5).applyMatrix4(cam.matrixWorld);
      const cc = this.camcorder;
      if (cc) {
        cc.group.position.set(
          THREE.MathUtils.lerp(this.camcorderPos.x, grab.x, e),
          THREE.MathUtils.lerp(0, grab.y - 0.07, e),
          THREE.MathUtils.lerp(this.camcorderPos.z, grab.z, e)
        );
        const targetYaw = cam.rotation.y + Math.PI; // lens ends up facing forward
        let dyaw = targetYaw - 0.25;
        while (dyaw > Math.PI) dyaw -= Math.PI * 2;
        while (dyaw < -Math.PI) dyaw += Math.PI * 2;
        cc.group.rotation.y = 0.25 + dyaw * e;
        cc.group.rotation.z = 0.35 * (1 - e); // settles level in the hand
      }
      if (t > 4.75 && !this.flags['intro-grab-fx']) {
        this.flags['intro-grab-fx'] = true;
        this.audio.sting('paper'); // glove fabric + plastic foley
      }
    } else if (!this.flags['intro-grab']) {
      this.finishIntro();
    }
  }

  /** The grab moment: control comes back, viewmodel in hand, lens still lowering... */
  private finishIntro(): void {
    const sp = this.maze.spawnCell;
    const sw = cellWorld(sp.x, sp.y);
    const yaw = this.camera.rotation.y;
    this.player.reset(sw.x, sw.z, yaw);
    // swap the floor prop for the viewmodel
    if (this.camcorder) {
      this.world.remove(this.camcorder.group);
      this.camcorder = null;
    }
    this.buildViewmodel();
    this.vm!.visible = true;
    this.camAnim = 0;
    this.camGoal = 1; // it rises to the eye while you take your first steps
    this.camLight.intensity = 8.5; // back to gameplay fill
    this.engineState = 'playing';
    useGameUI.getState().set({ screen: 'playing', eyelids: false });
    this.setObjective('FIND A WAY OUT', 'two exits. one hums. one needs power');
    this.requestLock();
  }

  private onLeverPulled(): void {
    this.audio.sting('lever');
    this.entity.hearNoise(this.player.pos.x, this.player.pos.z, 100);
    // animate the lever
    this.level.refs.breakerLever.rotation.x = 1.25;
    this.level.refs.breakerLampOn.visible = true;
    this.phase = 'blackout';
    this.blackoutTimer = 24;
    this.blackoutKnow = 0.8;
    this.audio.sting('powerdown');
    this.setLights(false);
    this.audio.setAmbience(0, 0.4);
    this.setObjective('SURVIVE', 'grid rerouting - it heard the lever');
    window.setTimeout(() => {
      if (!this.disposed && this.phase === 'blackout') this.playScript('kBlackout');
    }, 1400);
  }

  private restorePower(): void {
    this.setLights(true);
    this.audio.sting('powerup');
    this.audio.setAmbience(1, 1);
    this.level.refs.breakerLever.rotation.x = 1.25;
    this.level.refs.breakerLampOn.visible = true;
    (this.level.refs.stairwellLamp.material as THREE.MeshBasicMaterial).color.set(0x39ff6a);
  }

  private setLights(on: boolean): void {
    const L = this.level.lightMats;
    const fx = this.level.lightFX;
    this.level.powerLevel = on ? 1 : 0;
    fx.setMaster(on ? 1 : 0);
    fx.apply();
    if (on) {
      L.steady.color.set(0xfffacf);
      for (const m of L.flickerGroups) m.color.set(0xfffacf);
      this.ambient.intensity = this.baseAmbient;
      this.hemi.intensity = this.baseHemi;
      (this.scene.fog as THREE.FogExp2).density = 0.038;
      this.camLight.intensity = 8.5;
    } else {
      L.steady.color.set(0x100e08);
      for (const m of L.flickerGroups) m.color.set(0x100e08);
      this.ambient.intensity = 0.07;
      this.hemi.intensity = 0.05;
      (this.scene.fog as THREE.FogExp2).density = 0.085;
      this.camLight.intensity = 5;
      for (const p of this.lightPool) {
        p.light.intensity = 0;
        p.base = 0;
      }
    }
  }

  private startEnding(type: 'A' | 'B' | 'C'): void {
    this.engineState = 'cine';
    this.cine = { type, t: 0 };
    this.audio.setMusicBox(false, 0);
    this.audio.setGrowl(0, 0);
    this.audio.setStatic(0.1);
    if (type === 'A') {
      this.audio.sting('doorCreak');
      useGameUI.getState().set({ fade: true, prompt: '', dialogue: null });
      this.queue = [];
    } else if (type === 'B') {
      this.audio.sting('doorCreak');
      useGameUI.getState().set({ fade: false, prompt: '', dialogue: null });
      this.queue = [];
    } else {
      // C: press the call button, cage grinds open, ride up
      this.audio.setMachineHum(0);
      this.audio.sting('lever');
      const L = this.level.refs;
      (L.hubLiftButton.material as THREE.MeshBasicMaterial).color.set(0x35ff5e);
      (L.hubLiftLamp.material as THREE.MeshBasicMaterial).color.set(0x39ff6a);
      this.setObjective('RIDE IT UP', '');
      useGameUI.getState().set({ fade: false, prompt: '', dialogue: null });
      this.queue = [];
    }
  }

  private updateCine(dt: number): void {
    if (!this.cine) return;
    this.cine.t += dt;
    const t = this.cine.t;
    if (this.cine.type === 'A') {
      if (t > 1.0 && !this.flags['cineA-slam']) {
        this.flags['cineA-slam'] = true;
        this.audio.sting('slam');
      }
      if (t > 1.4 && !this.flags['cineA-steps']) {
        this.flags['cineA-steps'] = true;
        let i = 0;
        const step = () => {
          if (this.disposed) return;
          this.audio.step('walk', 0, 1.1);
          if (++i < 7) window.setTimeout(step, 430);
        };
        step();
      }
      if (t > 4.0) this.showEnding('A');
    } else if (this.cine.type === 'B') {
      if (t > 0.5 && !this.flags['cineB-horn']) {
        this.flags['cineB-horn'] = true;
        this.audio.sting('party');
        useGameUI.getState().set({ flashWhite: true });
      }
      if (t > 1.1 && !this.flags['cineB-fade']) {
        this.flags['cineB-fade'] = true;
        useGameUI.getState().set({ flashWhite: false, fade: true });
      }
      if (t > 2.6) this.showEnding('B');
    } else {
      // C: freight lift - button, cage grinds open, step in, rumble upward, fade
      if (t > 0.7 && !this.flags['cineC-creak']) {
        this.flags['cineC-creak'] = true;
        this.audio.sting('doorCreak');
      }
      if (t > 1.15 && !this.flags['cineC-clank']) {
        this.flags['cineC-clank'] = true;
        this.audio.clank(0, 1); // cage doors roll open
      }
      if (t > 1.4 && !this.flags['cineC-steps']) {
        this.flags['cineC-steps'] = true;
        let i = 0;
        const step = () => {
          if (this.disposed) return;
          this.audio.step('walk', 0, 1.0);
          if (i === 2) this.audio.clank(0, 0.5); // cage floor flexes underfoot
          if (++i < 4) window.setTimeout(step, 400);
        };
        step();
      }
      if (t > 3.1 && !this.flags['cineC-lever']) {
        this.flags['cineC-lever'] = true;
        this.audio.sting('lever', 0.3);
        this.audio.sting('powerup');
      }
      if (t > 3.9 && !this.flags['cineC-rumble']) {
        this.flags['cineC-rumble'] = true;
        this.rumbleShake = 0;
        this.audio.startLiftRumble();
      }
      // the cage climbs: camera shakes harder as the cables take the load
      if (this.flags['cineC-rumble']) {
        this.rumbleShake = Math.min(1, this.rumbleShake + dt * 0.45);
        const s = this.rumbleShake * 0.022;
        this.camera.position.x += (Math.random() - 0.5) * s;
        this.camera.position.y += (Math.random() - 0.5) * s * 0.6;
        this.camera.rotation.z += (Math.random() - 0.5) * s * 0.4;
      }
      this.audio.updateRumble();
      if (t > 7.5 && !this.flags['cineC-fade']) {
        this.flags['cineC-fade'] = true;
        this.audio.stopLiftRumble();
        useGameUI.getState().set({ fade: true });
      }
      if (t > 9.2) this.showEnding('C');
    }
  }

  private showEnding(type: 'A' | 'B' | 'C'): void {
    this.cine = null;
    this.engineState = 'over';
    // release the mouse: the ending screen needs a clickable cursor
    if (document.pointerLockElement) document.exitPointerLock();
    this.audio.setStatic(0);
    const ui = useGameUI.getState();
    ui.set({
      screen: type === 'A' ? 'endingA' : type === 'B' ? 'endingB' : 'endingC',
      endingStats: {
        time: this.elapsed,
        notes: this.notesFound,
        water: this.watersDrunk,
        deaths: this.deaths,
      },
      fade: false,
      flashWhite: false,
      dialogue: null,
      noteOpen: null,
    });
    if (type === 'A') window.setTimeout(() => { if (!this.disposed) this.playScript('endingA'); }, 600);
    if (type === 'C') window.setTimeout(() => { if (!this.disposed) this.playScript('endingC'); }, 600);
  }

  private die(): void {
    if (this.engineState !== 'playing') return;
    this.engineState = 'dying';
    this.dieT = 0;
    // release the mouse: the death screen needs a clickable cursor
    if (document.pointerLockElement) document.exitPointerLock();
    // the death cam is the tape's POV: whip the viewfinder up if it was down
    this.camAnim = 1;
    this.camGoal = 1;
    if (!this.tapeOn) this.powerTape(true);
    this.audio.sting('catch');
    this.audio.setStatic(0.5);
    useGameUI.getState().set({ dialogue: null, noteOpen: null, prompt: '' });
    this.queue = [];
  }

  private updateDying(dt: number): void {
    this.dieT += dt;
    this.tearLevel = Math.min(1, this.dieT * 1.3);
    this.audio.setStatic(0.3 + this.dieT * 0.5);
    // force look at the entity
    const dx = this.entity.pos.x - this.camera.position.x;
    const dz = this.entity.pos.z - this.camera.position.z;
    const targetYaw = Math.atan2(-dx, -dz);
    let diff = targetYaw - this.player.yaw;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.player.yaw += diff * Math.min(1, dt * 6);
    this.player.pitch = THREE.MathUtils.lerp(this.player.pitch, 0.12, dt * 4);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.player.yaw;
    this.camera.rotation.x = this.player.pitch;
    if (this.dieT > 1.25) {
      this.engineState = 'over';
      this.deaths++;
      this.audio.setStatic(0.12);
      useGameUI.getState().set({ screen: 'death', deaths: this.deaths, fade: false, flashWhite: false });
    }
  }

  private resetRun(): void {
    this.disposeWorld();
    this.queue = [];
    this.flags = {};
    this.phase = 'explore';
    this.inHub = false;
    this.elapsed = 0;
    this.notesFound = 0;
    this.watersDrunk = 0;
    this.tearLevel = 0;
    this.engineState = 'idle';
    // back to the naked eye: the menu is real life, no tape, no viewfinder
    this.tapeOn = false;
    this.camAnim = 1;
    this.camGoal = 1;
    this.lensTrack = 0;
    this.glitchBurst = 0;
    this.buildWorld();
    this.setLights(true);
    this.audio.setStatic(0);
    this.audio.setMusicBox(false, 0);
    this.audio.setGrowl(0, 0);
    this.audio.setMachineHum(0);
    this.audio.stopLiftRumble();
    this.setObjective('FIND A WAY OUT', 'collect pages - listen for the radio');
    useGameUI.getState().set({
      water: 0,
      notes: 0,
      deaths: 0,
      stamina: 1,
      fade: false,
      flashWhite: false,
      eyelids: false,
      dialogue: null,
      noteOpen: null,
      endingStats: null,
      camRaised: false,
      tracked: false,
    });
  }

  // ---------------- helpers ----------------

  private setObjective(o: string, sub: string): void {
    useGameUI.getState().set({ objective: o, objectiveSub: sub });
  }

  private setScreen(s: 'menu' | 'intro' | 'playing' | 'paused' | 'death' | 'endingA' | 'endingB' | 'endingC'): void {
    this.engineState = s === 'playing' ? 'playing' : s === 'intro' ? 'intro' : s === 'menu' ? 'idle' : s === 'death' ? 'over' : this.engineState === 'over' ? 'over' : 'idle';
    useGameUI.getState().set({ screen: s });
  }

  private panTo(x: number, z: number): number {
    const dx = x - this.camera.position.x;
    const dz = z - this.camera.position.z;
    const len = Math.hypot(dx, dz) || 1;
    const rightX = Math.cos(this.player.yaw);
    const rightZ = -Math.sin(this.player.yaw);
    return Math.max(-1, Math.min(1, ((dx / len) * rightX + (dz / len) * rightZ) * 0.9));
  }

  // ---------------- viewmodel & viewfinder ----------------

  /**
   * Builds the in-hand camcorder (right hand, lens forward) as a camera child.
   * The viewmodel lives on render layer 1 and is drawn in a SECOND, depth-cleared
   * pass with the world lights silenced - the camera point light sits centimetres
   * away and would otherwise blow it out to white.
   */
  private buildViewmodel(): void {
    if (this.vm) {
      this.vm.visible = true;
      return;
    }
    const vm = new THREE.Group();
    const cc = P.buildViewCamcorder(this.feedRT.texture); // the flip-out LCD shows the live feed
    this.vmRecLed = cc.recLed;
    this.vmLcd = cc.lcdPivot;
    vm.add(cc.group);
    const hand = P.buildHand();
    hand.position.set(0.128, -0.02, 0.02); // wraps the grip
    vm.add(hand);
    vm.scale.setScalar(0.48);
    vm.traverse((o) => o.layers.set(1));
    vm.visible = false;
    this.camera.add(vm);
    this.vm = vm;
    // dedicated viewmodel lighting (only on during the vm pass; layer 1 so the
    // layer-1 camera pass picks them up and the main pass ignores them)
    const key = new THREE.PointLight(0xffe2b0, 1.35, 1.9, 1.5);
    key.position.set(0.16, 0.12, 0.14);
    key.layers.set(1);
    key.visible = false; // flipped on inside renderViewmodelOverlay
    this.camera.add(key);
    this.vmLight = key;
    const amb = new THREE.AmbientLight(0xffedb8, 0.85);
    amb.layers.set(1);
    amb.visible = false;
    this.camera.add(amb);
    this.vmAmb = amb;
  }

  /**
   * Depth-cleared second pass: vm on layer 1 with its own layer-1 lights.
   * Self-manages autoClear/background so it is safe from BOTH render paths.
   */
  private renderViewmodelOverlay(): void {
    if (!this.vm || !this.vm.visible) return;
    // a Color scene background FORCES a clear even with autoClear=false - null
    // it, and suspend autoClear or this pass wipes the world render to black
    const bg = this.scene.background;
    this.scene.background = null;
    const autoClear = this.renderer.autoClear;
    this.renderer.autoClear = false;
    this.renderer.clearDepth();
    if (this.vmLight) this.vmLight.visible = true;
    if (this.vmAmb) this.vmAmb.visible = true;
    this.camera.layers.set(1);
    try {
      this.renderer.render(this.scene, this.camera);
    } finally {
      this.camera.layers.set(0);
      if (this.vmLight) this.vmLight.visible = false;
      if (this.vmAmb) this.vmAmb.visible = false;
      this.scene.background = bg;
      this.renderer.autoClear = autoClear;
    }
  }

  /** Raise/lower the camcorder. While lowered you see with your OWN eyes - and the Smiler is invisible. */
  setCam(raised: boolean): void {
    if (useGameUI.getState().screen !== 'playing') return;
    const goal = raised ? 1 : 0;
    if (this.camGoal === goal) return;
    this.camGoal = goal;
  }

  toggleCamcorder(): void {
    this.setCam(this.camGoal < 0.5);
  }

  /** Tape power state flips under a static burst so the picture switch reads diegetic. */
  private powerTape(on: boolean): void {
    this.tapeOn = on;
    this.glitchBurst = on ? 0.85 : 0.6;
    useGameUI.getState().set({ camRaised: on });
    if (on) {
      this.audio.sting('flicker');
      this.audio.setStatic(this.staticBase + 0.3);
    }
  }

  private updateViewmodel(dt: number, moved: boolean, sprinting: boolean): void {
    if (!this.vm) return;
    // animate toward the goal
    const dir = Math.sign(this.camGoal - this.camAnim);
    if (dir !== 0) this.camAnim = clamp01(this.camAnim + dir * dt / 0.42);
    // tape power thresholds (mid-animation, hidden by the static burst)
    if (this.camGoal === 1 && this.camAnim > 0.62 && !this.tapeOn) this.powerTape(true);
    if (this.camGoal === 0 && this.camAnim < 0.45 && this.tapeOn) this.powerTape(false);

    // PROP ELIMINATION: the swing ends with the LCD pressed to the operator's
    // head, so the camera body itself is out of view - hide it the moment the
    // raise completes (also skips the entire second render pass while raised).
    // A static burst covers the hand-off from prop screen to tape picture.
    if (this.camGoal === 1 && this.camAnim >= 0.999) {
      if (this.vm.visible) {
        this.vm.visible = false;
        this.glitchBurst = Math.max(this.glitchBurst, 0.5);
      }
    } else if (!this.vm.visible) {
      this.vm.visible = true; // lowering (or mid-raise): the prop comes back into view
    }

    // flip-out LCD: swings open toward your eye as the camera rises, folds
    // back against the flank on the way down - slow servo, Outlast style
    const lcdTarget = this.camGoal === 1 && this.camAnim > 0.15 ? 1 : 0;
    const lcdDir = Math.sign(lcdTarget - this.lcdAnim);
    if (lcdDir !== 0) this.lcdAnim = clamp01(this.lcdAnim + lcdDir * dt / 0.62);
    if (this.vmLcd) {
      const le = this.lcdAnim * this.lcdAnim * (3 - 2 * this.lcdAnim);
      this.vmLcd.rotation.order = 'YXZ';
      this.vmLcd.rotation.y = THREE.MathUtils.lerp(P.LCD_CLOSED.y, P.LCD_OPEN.y, le);
      this.vmLcd.rotation.x = THREE.MathUtils.lerp(P.LCD_CLOSED.x, P.LCD_OPEN.x, le);
    }

    const e = this.camAnim * this.camAnim * (3 - 2 * this.camAnim);
    // the final approach: past 70% of the raise the unit glides from the
    // shoulder pose straight to the head so the screen "arrives" at the eye.
    // The blend is itself smoothed so aborting a raise mid-glide eases back.
    const swRaw = clamp01((this.camAnim - 0.7) / 0.3);
    const swTarget = this.camGoal === 1 ? swRaw * swRaw * (3 - 2 * swRaw) : 0;
    this.swAnim += (swTarget - this.swAnim) * Math.min(1, dt * 9);
    const sw = this.swAnim;
    const P0 = BackroomsGame.VM_LOWERED;
    const P1 = BackroomsGame.VM_RAISED;
    const P2 = BackroomsGame.VM_EYE;
    const lerp = THREE.MathUtils.lerp;

    // look sway: the camera lags behind fast glances
    this.vmSway.x *= Math.exp(-dt * 7);
    this.vmSway.y *= Math.exp(-dt * 7);
    const swx = Math.max(-1, Math.min(1, this.vmSway.x / 90));
    const swy = Math.max(-1, Math.min(1, this.vmSway.y / 90));

    // walk cycle + breathing (damped out as the screen takes over the view)
    const bobAmp = (moved ? (sprinting ? 1.5 : 1) : 0) * (0.35 + 0.65 * e) * (1 - sw * 0.7);
    const bobY = Math.sin(this.player.bob) * 0.0042 * bobAmp;
    const bobX = Math.cos(this.player.bob * 0.5) * 0.005 * bobAmp;
    const breath = Math.sin(performance.now() / 1000 * 1.3) * 0.0015;

    this.vm.position.set(
      lerp(lerp(P0.x, P1.x, e), P2.x, sw) + bobX + swx * 0.012 * (1 - e * 0.4),
      lerp(lerp(P0.y, P1.y, e), P2.y, sw) + bobY + breath - swy * 0.01,
      lerp(lerp(P0.z, P1.z, e), P2.z, sw)
    );
    this.vm.rotation.set(
      lerp(lerp(P0.rx, P1.rx, e), P2.rx, sw) - swy * 0.06,
      lerp(lerp(P0.ry, P1.ry, e), P2.ry, sw) + swx * 0.05,
      lerp(lerp(P0.rz, P1.rz, e), P2.rz, sw) + bobX * 0.8
    );

    // viewfinder lens narrows twice: naked eye 76 -> raised 66 -> the screen
    // swallowing the view 60 (the zoom sells the "panel reaches your face")
    const fovT = 76 - e * 10 - sw * 6;
    if (Math.abs(this.camera.fov - fovT) > 0.05) {
      this.camera.fov = fovT;
      this.camera.updateProjectionMatrix();
    }

    // REC led blink on the viewmodel
    if (this.vmRecLed && this.tapeOn) {
      const on = Math.floor(performance.now() / 1000 * 1.7) % 2 === 0;
      (this.vmRecLed.material as THREE.MeshBasicMaterial).color.set(on ? 0xff2a22 : 0x350c0a);
    }
  }

  /** Independent flicker circuits: each blinks on its own phase like real wiring. */
  private updateFlicker(dt: number): void {
    const L = this.level.lightMats;
    for (let gi = 0; gi < 3; gi++) {
      const g = this.flickGroups[gi];
      g.next -= dt;
      if (g.next <= 0) {
        if (g.on) {
          g.on = false;
          g.next = 0.05 + this.rand() * 0.2;
          // audible buzz when a nearby circuit cuts out
          const panels = this.level.panelPos.flickerGroups[gi];
          if (panels.length > 0) {
            const p = panels[Math.floor(this.rand() * panels.length)];
            const d = Math.hypot(p.x - this.player.pos.x, p.z - this.player.pos.z);
            if (d < 15 && this.rand() < 0.65) this.audio.flickerBurst(0.5);
          }
        } else {
          g.on = true;
          g.next = 0.7 + this.rand() * 2.6;
          if (this.rand() < 0.3) g.next = 0.22 + this.rand() * 0.4; // stutter back on
        }
      }
      const target = g.on ? 1 : 0.05;
      g.level += (target - g.level) * Math.min(1, dt * 32);
      const c = 0.07 + g.level * 0.93;
      L.flickerGroups[gi].color.setRGB(c, c * 0.97, c * 0.85);
      this.level.lightFX.setGroupLevel(gi + 1, g.level);
    }
    this.level.lightFX.apply();
  }

  /** Mains surges: the whole floor brightens for a beat, then settles. */
  private updateSurge(dt: number): void {
    const fx = this.level.lightFX;
    if (this.level.powerLevel > 0.5 && this.phase !== 'blackout') {
      this.nextSurge -= dt;
      if (this.nextSurge <= 0) {
        this.nextSurge = 26 + this.rand() * 34;
        this.surgeT = 0.5;
        this.audio.flickerBurst(1.25);
      }
    }
    if (this.surgeT > 0) {
      this.surgeT -= dt;
      const t = 0.5 - this.surgeT;
      const env = t < 0.07 ? t / 0.07 : Math.max(0, 1 - (t - 0.07) / 0.43);
      const flick = 0.78 + 0.22 * Math.sin(t * 47);
      const k = env * flick;
      fx.setSurge(k);
      this.ambient.intensity = this.baseAmbient * (1 + k * 0.45);
      this.hemi.intensity = this.baseHemi * (1 + k * 0.35);
    } else if (fx.surge !== 0) {
      fx.setSurge(0);
      this.ambient.intensity = this.baseAmbient;
      this.hemi.intensity = this.baseHemi;
    }
    fx.apply();
  }

  /** Reassign the pooled point lights to the brightest nearby live panels. */
  private poolCands: { x: number; z: number; group: number; d2: number }[] = [];
  private assignLightPool(): void {
    const px = this.player.pos.x;
    const pz = this.player.pos.z;
    const R2 = 13.5 * 13.5; // tight radius: only nearby fixtures get real lights
    // reusable candidate buffer - this runs ~5x/sec and allocating here was
    // pure GC churn on low-RAM machines
    const cands = this.poolCands;
    let n = 0;
    const consider = (group: number, panels: THREE.Vector3[]): void => {
      for (const p of panels) {
        const d2 = (p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz);
        if (d2 < R2) {
          if (n >= cands.length) cands.push({ x: p.x, z: p.z, group, d2 });
          else {
            const c = cands[n];
            c.x = p.x;
            c.z = p.z;
            c.group = group;
            c.d2 = d2;
          }
          n++;
        }
      }
    };
    consider(0, this.level.panelPos.steady);
    consider(1, this.level.panelPos.flickerGroups[0]);
    consider(2, this.level.panelPos.flickerGroups[1]);
    consider(3, this.level.panelPos.flickerGroups[2]);
    // insertion sort of the small first-n slice (stable, zero allocation)
    for (let i = 1; i < n; i++) {
      const c = cands[i];
      let j = i - 1;
      while (j >= 0 && cands[j].d2 > c.d2) {
        cands[j + 1] = cands[j];
        cands[j] = c;
        j--;
      }
    }
    for (let i = 0; i < this.lightPool.length; i++) {
      const slot = this.lightPool[i];
      const c = i < n ? cands[i] : null;
      if (!c) {
        slot.light.intensity = 0;
        slot.base = 0;
        continue;
      }
      slot.light.position.set(c.x, 2.72, c.z);
      slot.group = c.group;
      // nearer panels a touch brighter; falls off with decay anyway
      slot.base = 10.5 - Math.min(3.5, Math.sqrt(c.d2) * 0.16);
    }
  }

  /** Per-frame pool shimmer: steady micro-flicker + hard cut per flicker circuit. */
  private updateLightPool(dt: number): void {
    this.poolAssignT -= dt;
    if (this.poolAssignT <= 0) {
      this.poolAssignT = 0.22;
      this.assignLightPool();
    }
    const t = performance.now() / 1000;
    const powered = this.level.powerLevel > 0.5;
    const surge = 1 + this.level.lightFX.surge * 0.55;
    for (const slot of this.lightPool) {
      if (slot.base <= 0) continue;
      if (!powered) {
        slot.light.intensity = 0;
        continue;
      }
      if (slot.group === 0) {
        // subtle mains shimmer so the light never feels frozen
        slot.light.intensity = slot.base * (0.93 + 0.07 * Math.sin(t * 43.0 + slot.light.position.x * 7.1)) * surge;
      } else {
        slot.light.intensity = slot.base * this.flickGroups[slot.group - 1].level * surge;
      }
    }
  }

  // ---------------- main loop ----------------

  private loop = (now: number): void => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    this.renderer.info.reset();
    const dt = Math.min(0.1, (now - this.lastT) / 1000);
    this.lastT = now;
    const screen = useGameUI.getState().screen;
    const worldActive = screen === 'playing' && !useGameUI.getState().noteOpen;

    // dynamic resolution: track the smoothed frame time while playing and
    // step the canvas/tape RT up or down with hysteresis + a step cooldown
    this.frameAvg += (dt * 1000 - this.frameAvg) * 0.04;
    this.resCooldown -= dt;
    if (screen === 'playing') {
      this.resCheckT -= dt;
      if (this.resCheckT <= 0 && this.resCooldown <= 0) {
        this.resCheckT = 1.1;
        if (this.frameAvg > 26.5 && this.resScale > 0.56) {
          this.resScale = Math.max(0.55, this.resScale - 0.15);
          this.resCooldown = 0.7;
          this.applyResolution();
        } else if (this.frameAvg < 14.5 && this.resScale < 0.99) {
          this.resScale = Math.min(1, this.resScale + 0.1);
          this.resCooldown = 0.7;
          this.applyResolution();
        }
      }
    }

    if (screen === 'menu') {
      this.updateMenu(dt);
      // live feed into the camcorder LCD (every 5th frame - it is a tiny
      // 256x160 picture of a static corridor, freshness is irrelevant)
      this.feedFrame++;
      if (this.feedFrame % 5 === 0 && this.camcorder) {
        this.renderer.setRenderTarget(this.feedRT);
        this.renderer.clear();
        this.renderer.render(this.scene, this.feedCam);
        this.renderer.setRenderTarget(null);
      }
    } else if (screen === 'intro') {
      this.updateIntro(dt);
      this.updateDialogue();
    } else if (worldActive && this.engineState === 'playing') {
      this.updateWorld(dt);
      // the flip-out screen shows a live lens feed with a soft yaw lag ONLY
      // while the panel is actually on screen (mid raise/lower) - once the
      // prop is hidden the tape picture IS the view, so the feed RT stops
      // burning a second scene render every frame. Fresh every 4th frame:
      // the visible window is short, so it must keep up with your turns.
      if (this.tapeOn && this.vm && this.vm.visible && this.camAnim > 0.4) {
        this.feedFrame++;
        if (this.feedFrame % 4 === 0) this.renderFeed();
      }
    } else if (this.engineState === 'dying') {
      this.updateDying(dt);
      this.updateDialogue();
    } else if (this.engineState === 'cine') {
      this.updateCine(dt);
    }

    // The Smiler exists only on tape - and never inside The Hub
    const entVisible = (this.tapeOn && !this.inHub) || this.engineState === 'dying';
    if (this.entity.group.visible !== entVisible) {
      this.entity.group.visible = entVisible;
      if (entVisible && this.camGoal === 1) this.glitchBurst = Math.max(this.glitchBurst, 0.4);
    }

    // VHS params
    this.tearLevel = Math.max(0, this.tearLevel - dt * 1.6);
    const showTape = this.tapeOn && screen !== 'menu';
    if (showTape) {
      const tapeBase = this.inHub ? 0.05 : this.staticBase; // cleaner signal in the tunnels
      const statik =
        tapeBase + (this.tearLevel > 0 ? 0.12 : 0) + this.lensTrack * 0.3 + this.glitchBurst;
      this.glitchBurst = Math.max(0, this.glitchBurst - dt * 2.6);
      this.vhs.set(now / 1000, Math.min(1, statik), this.tearLevel);
      this.vhs.render(this.renderer, this.scene, this.camera, () => this.renderViewmodelOverlay());
    } else {
      // menu + pre-grab intro + lowered camcorder: your own eyes, clean render
      this.glitchBurst = 0;
      this.lensTrack = 0;
      this.renderer.render(this.scene, this.camera);
      this.renderViewmodelOverlay();
    }
  };

  /** Park the feed camera on the player's view (with lag) and render to the RT. */
  private renderFeed(): void {
    // the little flip-out screen shows what the lens sees: yaw lags the view
    let dy = this.player.yaw - this.feedYawLag;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.feedYawLag += dy * 0.16;
    this.feedCam.position.set(this.player.pos.x, 1.58, this.player.pos.z);
    this.feedCam.rotation.order = 'YXZ';
    this.feedCam.rotation.set(this.player.pitch * 0.9, this.feedYawLag, 0);
    this.feedCam.updateMatrixWorld();
    this.renderer.setRenderTarget(this.feedRT);
    this.renderer.clear();
    this.renderer.render(this.scene, this.feedCam);
    this.renderer.setRenderTarget(null);
  }

  private updateWorld(dt: number): void {
    this.elapsed += dt;
    const ui = useGameUI.getState();

    // player
    const frame = this.player.update(dt, this.level);
    if (frame.stepped) {
      this.audio.step(frame.stepped);
      const r = this.player.noiseRadius(frame.sprinting, true);
      this.entity.hearNoise(this.player.pos.x, this.player.pos.z, r);
    }
    this.updateViewmodel(dt, frame.moved, frame.sprinting);

    // world lighting: flicker circuits + surges + pooled panel lights
    this.updateFlicker(dt);
    this.updateSurge(dt);
    this.updateLightPool(dt);

    // music box near the party door (silences itself in the Hub: too far away)
    const pd = this.level.refs.partyDoorPos;
    const dParty = Math.hypot(pd.x - this.player.pos.x, pd.z - this.player.pos.z);
    const musicOn = dParty < 16 && this.phase !== 'blackout';
    this.audio.setMusicBox(musicOn, this.panTo(pd.x, pd.z));
    this.audio.updateMusicBox(this.panTo(pd.x, pd.z));

    if (this.inHub) {
      // ---------- THE HUB: concrete. quiet. the Smiler cannot follow. ----------
      const out = this.level.refs.hubOutpost;
      const dOut = Math.hypot(out.x - this.player.pos.x, out.z - this.player.pos.z);
      if (!this.flags['script-kOutpost'] && dOut < 6) {
        this.playScript('kOutpost');
        this.setObjective('FOLLOW THE TUNNEL', 'outpost echo-4 - take what you need');
      }
      const elv = this.level.refs.hubElevator;
      const dElv = Math.hypot(elv.x - this.player.pos.x, elv.z - this.player.pos.z);
      if (!this.flags['script-kElevator'] && dElv < 7) {
        this.playScript('kElevator');
        if (this.flags.hubPowered) {
          this.setObjective('CALL THE LIFT', 'the freight lift goes up. trust it');
        } else {
          this.setObjective('RESTORE POWER', 'the cage is dead - something is drinking the mains');
        }
      }
      // pump gallery: drips + machinery bed + the east-wing hint
      const wp = this.level.refs.hubWaterPos;
      if (wp) {
        const dW = Math.hypot(wp.x - this.player.pos.x, wp.z - this.player.pos.z);
        this.audio.updateDrips(clamp01(1 - dW / 10), this.panTo(wp.x, wp.z));
      }
      const mp = this.level.refs.hubMachinePos;
      if (mp && !this.flags.hubPowered) {
        const dM = Math.hypot(mp.x - this.player.pos.x, mp.z - this.player.pos.z);
        this.audio.setMachineHum(clamp01(1 - dM / 16), this.panTo(mp.x, mp.z));
      } else {
        this.audio.setMachineHum(0);
      }
      const gm = this.level.refs.hubGalleryMouth;
      if (gm && !this.flags.hubPowered && !this.flags['hint-machine']) {
        const dG = Math.hypot(gm.x - this.player.pos.x, gm.z - this.player.pos.z);
        if (dG < 5.5) {
          this.flags['hint-machine'] = true;
          this.playScript('kMachineHint');
          this.setObjective('RESTORE POWER', 'something east is drinking the mains - follow the water');
        }
      }
      // pump-mains lever flips down as the rig dies
      const leverM = this.level.refs.hubMachineLever;
      if (leverM && this.flags.hubPowered && leverM.rotation.x > -0.74) {
        leverM.rotation.x = Math.max(-0.75, leverM.rotation.x - dt * 4.5);
      }
      // water sheen drifts on its own bump copy
      const waterMesh = this.level.refs.hubWater;
      if (waterMesh) {
        const bm = (waterMesh.material as THREE.MeshStandardMaterial).bumpMap;
        if (bm) {
          bm.offset.y = (this.elapsed * 0.021) % 1;
          bm.offset.x = (this.elapsed * 0.007) % 1;
        }
      }
      // no growl, no heartbeat, no hunt static: the tape rests down here
      this.audio.setGrowl(0, 0);
      this.audio.heartbeat(0);
      this.audio.setStatic(0.05);
      this.lensTrack = 0;
      if (useGameUI.getState().tracked) useGameUI.getState().set({ tracked: false });
    } else {
      // ---------- LEVEL 0: entity, blackout, hunt audio, maze triggers ----------
      // entity
      const e = this.entity.update(dt, this.player.pos.x, this.player.pos.z, this.rand);
      this.entity.faceCamera(this.camera.position.x, this.camera.position.z);
      if (e.caught) {
        this.die();
        return;
      }

      // blackout timeline
      if (this.phase === 'blackout') {
        this.blackoutTimer -= dt;
        this.blackoutKnow -= dt;
        if (this.blackoutKnow <= 0) {
          this.blackoutKnow = 2.2;
          this.entity.forceKnowledge(this.player.pos.x, this.player.pos.z);
        }
        if (this.blackoutTimer <= 0) {
          this.phase = 'escape';
          this.restorePower();
          this.entity.sendFar(this.player.pos.x, this.player.pos.z, 6, this.rand);
          this.entity.aggressive = true;
          this.playScript('kBlackoutEnd');
          this.playScript('kHubHint');
          this.setObjective('ESCAPE', 'stairwell E7 is live - or the hole behind the wallpaper');
        }
      }

      // audio beds
      const dist = e.dist;
      const active = this.entity.state !== 'dormant';
      const growl = active ? Math.pow(clamp01(1 - dist / 15), 1.4) : 0;
      this.audio.setGrowl(growl, this.panTo(this.entity.pos.x, this.entity.pos.z));
      this.audio.heartbeat(this.entity.state === 'hunt' ? clamp01(1 - dist / 9) : clamp01(1 - dist / 5) * 0.5);
      const huntStatic = this.entity.state === 'hunt' ? 0.1 + 0.28 * clamp01(1 - dist / 12) : 0;

      // lens interference: through the viewfinder the tape REACTS to it
      let tracked = false;
      if (this.tapeOn && active && dist < 16) {
        const dx = this.entity.pos.x - this.player.pos.x;
        const dz = this.entity.pos.z - this.player.pos.z;
        const len = Math.hypot(dx, dz) || 1;
        const fx = -Math.sin(this.player.yaw);
        const fz = -Math.cos(this.player.yaw);
        const dot = (dx / len) * fx + (dz / len) * fz;
        if (
          dot > 0.35 &&
          hasLOS(this.maze, this.player.pos.x, this.player.pos.z, this.entity.pos.x, this.entity.pos.z)
        ) {
          tracked = true;
        }
      }
      this.lensTrack = tracked ? clamp01(1 - dist / 16) : 0;
      if (tracked !== useGameUI.getState().tracked) useGameUI.getState().set({ tracked });
      this.audio.setStatic(this.staticBase + huntStatic + this.lensTrack * 0.15);

      // proximity triggers
      if (!this.flags['script-kIntro'] && this.elapsed > 40) this.playScript('kIntro');
      if (this.flags['script-kIntro'] && !this.flags['script-kGoal'] && this.notesFound >= 1) this.playScript('kGoal');
      if (!this.flags['script-kHum'] && this.elapsed > 70) this.playScript('kHum');
      if (!this.flags['script-kStalker'] && (this.entity.state === 'hunt' || this.elapsed > 95)) this.playScript('kStalker');
      const hub = this.level.refs.hubPos;
      if (!this.flags['script-kPillars']) {
        const roomHere = this.maze.roomId[
          Math.floor(this.player.pos.z / CELL) * GRID + Math.floor(this.player.pos.x / CELL)
        ];
        if (roomHere >= 0 && this.maze.roomAt[roomHere].kind === 'pillars') this.playScript('kPillars');
      }
      const br = this.level.refs.breakerPos;
      if (!this.flags['script-kElectrical'] && Math.hypot(br.x - this.player.pos.x, br.z - this.player.pos.z) < 7) {
        this.playScript('kElectrical');
      }
      if (!this.flags['script-kNearParty'] && dParty < 9) this.playScript('kNearParty');
      if (this.phase === 'escape' && !this.flags['script-kFinale'] && dist < 6 && this.entity.state === 'hunt') {
        this.playScript('kFinale');
      }
    }

    // dialogue
    this.updateDialogue();

    // interactables
    this.updateTarget();

    // bottle idle animation
    this.level.refs.bottles.forEach((b, i) => {
      if (!b.visible) return;
      b.rotation.y += dt * 0.8;
      b.position.y = 0.04 + Math.sin(this.elapsed * 2 + i * 1.7) * 0.025;
    });

    // random ambience events
    if (this.phase !== 'blackout') {
      this.nextEvent -= dt;
      if (this.nextEvent <= 0) {
        this.nextEvent = 14 + this.rand() * 18;
        const roll = this.rand();
        const pan = this.rand() * 2 - 1;
        if (roll < 0.4) this.audio.sting('thud', pan);
        else if (roll < 0.7) this.audio.sting('whisper', pan);
        else this.audio.sting('flicker');
      }
    }

    // HUD push (throttled)
    this.hudAcc += dt;
    if (this.hudAcc > 0.12) {
      this.hudAcc = 0;
      useGameUI.getState().set({
        hunted: this.entity.state === 'hunt',
        elapsed: this.elapsed,
        stamina: frame.stamina,
        exhausted: this.player.exhausted,
      });
    }
  }

  /** Debug/perf: live renderer stats for quick checks (window.__backrooms.perf()). */
  perf(): { fps: number; calls: number; tris: number; resScale: number; geoms: number; texs: number; programs: number } {
    const i = this.renderer.info;
    return {
      fps: Math.round(1000 / Math.max(1, this.frameAvg)),
      calls: i.render.calls,
      tris: i.render.triangles,
      resScale: Math.round(this.resScale * 100) / 100,
      geoms: i.memory.geometries,
      texs: i.memory.textures,
      programs: i.programs?.length ?? 0,
    };
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    document.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('mousedown', this.onMouseDown);
    document.removeEventListener('mouseup', this.onMouseUp);
    document.removeEventListener('pointerlockchange', this.onLockChange);
    this.canvas.removeEventListener('click', this.onCanvasClick);
    this.canvas.removeEventListener('contextmenu', this.onCtx);
    if (this.vm) {
      this.vm.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((mm) => mm.dispose());
        else if (mat) mat.dispose();
      });
      this.camera.remove(this.vm);
      this.vm = null;
    }
    if (this.vmLight) {
      this.camera.remove(this.vmLight);
      this.vmLight.dispose();
      this.vmLight = null;
    }
    if (this.vmAmb) {
      this.camera.remove(this.vmAmb);
      this.vmAmb.dispose();
      this.vmAmb = null;
    }
    this.disposeWorld();
    this.feedRT.dispose();
    this.vhs.dispose();
    this.audio.dispose();
    this.renderer.dispose();
  }
}

function cellWorld(cx: number, cy: number): { x: number; z: number } {
  return { x: (cx + 0.5) * CELL, z: (cy + 0.5) * CELL };
}

// singleton
let instance: BackroomsGame | null = null;
export function createGame(canvas: HTMLCanvasElement): BackroomsGame {
  if (instance) instance.dispose();
  instance = new BackroomsGame(canvas);
  // debug/testing hook (harmless in production)
  (window as unknown as { __backrooms?: BackroomsGame }).__backrooms = instance;
  return instance;
}
export function getGame(): BackroomsGame | null {
  return instance;
}

// LOS re-export guard (kept for potential debugging tools)
export const _los = hasLOS;
