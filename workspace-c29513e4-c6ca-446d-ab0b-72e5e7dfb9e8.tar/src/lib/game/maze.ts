// Level 0 layout: a proper maze-with-rooms generator. The floor starts SOLID and
// a recursive-backtracker carves twisty corridors around ~20 hand-placed special
// rooms; dead ends are braided into loops so the plan is confusing rather than
// frustrating, rooms get 1-3 real doorways each, and a connectivity repair pass
// guarantees every cell is reachable. Also: weighted pathfinding (the Smiler
// prefers dark routes), wall-crossing line of sight and dark-cell sampling.

import { mulberry32 } from './rng';

export const GRID = 40;
export const CELL = 3.6;
export const WALL_H = 3.05;
export const WALL_T = 0.34;

export type RoomKind =
  | 'spawn'
  | 'hub'
  | 'electrical'
  | 'stairwell'
  | 'party'
  | 'storage'
  | 'office'
  | 'wet'
  | 'red'
  | 'pillars'
  | 'closet'
  | 'lounge'
  | 'utility'
  | 'none';

export interface RoomRect {
  x: number;
  y: number;
  w: number;
  h: number;
  kind: RoomKind;
}

export interface MazeData {
  wallsN: Uint8Array; // (GRID+1)*GRID : wall between (x, y-1) and (x, y)
  wallsW: Uint8Array; // GRID*(GRID+1) : wall between (x-1, y) and (x, y)
  roomId: Int16Array;
  roomAt: RoomRect[];
  pillars: { x: number; z: number }[]; // world coords of pillar centers
  spawnCell: { x: number; y: number };
  hubCell: { x: number; y: number };
  electricalCell: { x: number; y: number };
  stairwellCell: { x: number; y: number };
  partyCell: { x: number; y: number };
  partyDoorWall: { cx: number; cy: number; dir: 'N' | 'S' | 'E' | 'W' } | null;
  /** The Hub breach: a sealed 3-cell wall run on the hub room's east edge. */
  breachWall: { edgeX: number; cy: number };
}

export function cellCenterWorld(cx: number, cy: number): { x: number; z: number } {
  return { x: (cx + 0.5) * CELL, z: (cy + 0.5) * CELL };
}

export function worldToCell(x: number, z: number): { x: number; y: number } {
  return {
    x: Math.max(0, Math.min(GRID - 1, Math.floor(x / CELL))),
    y: Math.max(0, Math.min(GRID - 1, Math.floor(z / CELL))),
  };
}

export function roomCenter(r: RoomRect): { x: number; y: number } {
  return { x: Math.floor(r.x + r.w / 2), y: Math.floor(r.y + r.h / 2) };
}

/**
 * 20 special rooms spread over the 40x40 floor. Single-instance kinds are the
 * furnished set pieces (spawn/hub/electrical/stairwell/party/office/wet/red),
 * pillars/storage repeat, and the new closet/lounge/utility pockets give the
 * floor more distinct rooms to hide dark corners in.
 */
const ROOMS: RoomRect[] = [
  // core progression
  { x: 2, y: 2, w: 4, h: 3, kind: 'spawn' },
  { x: 18, y: 18, w: 4, h: 4, kind: 'hub' },
  { x: 3, y: 33, w: 3, h: 3, kind: 'electrical' },
  { x: 34, y: 33, w: 3, h: 3, kind: 'stairwell' },
  { x: 33, y: 2, w: 4, h: 3, kind: 'party' },
  // pillar halls (big open rooms)
  { x: 6, y: 9, w: 6, h: 5, kind: 'pillars' },
  { x: 25, y: 11, w: 6, h: 5, kind: 'pillars' },
  { x: 12, y: 27, w: 7, h: 5, kind: 'pillars' },
  // furnished set pieces
  { x: 14, y: 5, w: 3, h: 2, kind: 'office' },
  { x: 8, y: 22, w: 3, h: 2, kind: 'wet' },
  { x: 28, y: 26, w: 2, h: 2, kind: 'red' },
  { x: 26, y: 4, w: 2, h: 2, kind: 'storage' },
  { x: 9, y: 17, w: 2, h: 2, kind: 'storage' },
  { x: 30, y: 20, w: 2, h: 2, kind: 'storage' },
  // extra rooms: lounge, utility and claustrophobic closets
  { x: 22, y: 8, w: 2, h: 3, kind: 'lounge' },
  { x: 4, y: 27, w: 3, h: 2, kind: 'utility' },
  { x: 36, y: 24, w: 2, h: 2, kind: 'closet' },
  { x: 15, y: 36, w: 2, h: 2, kind: 'closet' },
  { x: 24, y: 33, w: 2, h: 2, kind: 'closet' },
  { x: 20, y: 13, w: 2, h: 2, kind: 'closet' },
];

export function generateMaze(seed: number): MazeData {
  const rand = mulberry32(seed);
  const W = GRID;
  const wallsN = new Uint8Array((GRID + 1) * GRID);
  const wallsW = new Uint8Array(GRID * (GRID + 1));
  const roomId = new Int16Array(GRID * GRID).fill(-1);

  const idxN = (x: number, y: number) => y * W + x; // y in 0..GRID (edge rows)
  const idxW = (x: number, y: number) => y * (W + 1) + x; // x in 0..GRID (edge cols)

  // ---- 1. start SOLID: every edge is a wall ----
  wallsN.fill(1);
  wallsW.fill(1);

  // ---- 2. stamp rooms: clear interiors, tag cells ----
  for (let ri = 0; ri < ROOMS.length; ri++) {
    const r = ROOMS[ri];
    for (let y = r.y; y < r.y + r.h; y++) {
      for (let x = r.x; x < r.x + r.w; x++) {
        roomId[y * W + x] = ri;
        if (x > r.x) wallsW[idxW(x, y)] = 0;
        if (y > r.y) wallsN[idxN(x, y)] = 0;
      }
    }
  }
  const isRoom = (x: number, y: number): boolean => roomId[y * W + x] >= 0;

  // ---- 3. recursive backtracker: carve twisty corridors around the rooms ----
  const visited = new Uint8Array(GRID * GRID);
  const stack: number[] = [];
  outerStart: for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      if (!isRoom(x, y)) {
        visited[y * W + x] = 1;
        stack.push(y * W + x);
        break outerStart;
      }
    }
  }
  const DIRS = [
    [0, -1],
    [0, 1],
    [-1, 0],
    [1, 0],
  ];
  while (stack.length > 0) {
    const c = stack[stack.length - 1];
    const cx = c % W;
    const cy = (c / W) | 0;
    const opts: number[] = [];
    for (let d = 0; d < 4; d++) {
      const nx = cx + DIRS[d][0];
      const ny = cy + DIRS[d][1];
      if (nx < 0 || ny < 0 || nx >= GRID || ny >= GRID) continue;
      if (isRoom(nx, ny) || visited[ny * W + nx]) continue;
      opts.push(d);
    }
    if (opts.length === 0) {
      stack.pop();
      continue;
    }
    const d = opts[Math.floor(rand() * opts.length)];
    const nx = cx + DIRS[d][0];
    const ny = cy + DIRS[d][1];
    if (d === 0) wallsN[idxN(cx, cy)] = 0;
    else if (d === 1) wallsN[idxN(cx, cy + 1)] = 0;
    else if (d === 2) wallsW[idxW(cx, cy)] = 0;
    else wallsW[idxW(cx + 1, cy)] = 0;
    visited[ny * W + nx] = 1;
    stack.push(ny * W + nx);
  }

  // ---- 4. braid: turn ~60% of corridor dead ends into loops (confusing, not
  // claustrophobic) plus a batch of extra knockdowns for redundant routes ----
  const openEdges = (x: number, y: number): number => {
    let n = 0;
    if (!wallsN[idxN(x, y)]) n++;
    if (!wallsN[idxN(x, y + 1)]) n++;
    if (!wallsW[idxW(x, y)]) n++;
    if (!wallsW[idxW(x + 1, y)]) n++;
    return n;
  };
  const knockBetween = (x: number, y: number, d: number): boolean => {
    // knock the wall of cell (x,y) toward direction d if the neighbor exists,
    // is not a room, and the edge is currently closed
    const nx = x + DIRS[d][0];
    const ny = y + DIRS[d][1];
    if (nx < 1 || ny < 1 || nx >= GRID - 1 || ny >= GRID - 1) return false;
    if (isRoom(nx, ny)) return false;
    if (d === 0) {
      if (!wallsN[idxN(x, y)]) return false;
      wallsN[idxN(x, y)] = 0;
    } else if (d === 1) {
      if (!wallsN[idxN(x, y + 1)]) return false;
      wallsN[idxN(x, y + 1)] = 0;
    } else if (d === 2) {
      if (!wallsW[idxW(x, y)]) return false;
      wallsW[idxW(x, y)] = 0;
    } else {
      if (!wallsW[idxW(x + 1, y)]) return false;
      wallsW[idxW(x + 1, y)] = 0;
    }
    return true;
  };
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      if (isRoom(x, y)) continue;
      if (openEdges(x, y) !== 1) continue;
      if (rand() > 0.62) continue;
      const d = Math.floor(rand() * 4);
      knockBetween(x, y, d);
    }
  }
  for (let i = 0; i < 110; i++) {
    const x = 1 + Math.floor(rand() * (GRID - 2));
    const y = 1 + Math.floor(rand() * (GRID - 2));
    if (isRoom(x, y)) continue;
    knockBetween(x, y, Math.floor(rand() * 4));
  }

  // ---- 5. room doorways: 1-3 real openings per room, carved from solid wall ----
  const CRITICAL: RoomKind[] = ['spawn', 'hub', 'electrical', 'stairwell', 'party'];
  for (let ri = 0; ri < ROOMS.length; ri++) {
    const r = ROOMS[ri];
    const want = CRITICAL.includes(r.kind) ? 3 : 1 + Math.floor(rand() * 3);
    // collect candidate boundary edges (room cell <-> non-room cell)
    type Edge = { knock: () => void };
    const edges: Edge[] = [];
    for (let y = r.y; y < r.y + r.h; y++) {
      for (let x = r.x; x < r.x + r.w; x++) {
        if (y - 1 >= 0 && !isRoom(x, y - 1) && wallsN[idxN(x, y)]) edges.push({ knock: () => (wallsN[idxN(x, y)] = 0) });
        if (y + 1 < GRID && !isRoom(x, y + 1) && wallsN[idxN(x, y + 1)]) edges.push({ knock: () => (wallsN[idxN(x, y + 1)] = 0) });
        if (x - 1 >= 0 && !isRoom(x - 1, y) && wallsW[idxW(x, y)]) edges.push({ knock: () => (wallsW[idxW(x, y)] = 0) });
        if (x + 1 < GRID && !isRoom(x + 1, y) && wallsW[idxW(x + 1, y)]) edges.push({ knock: () => (wallsW[idxW(x + 1, y)] = 0) });
      }
    }
    let carved = 0;
    let guard = 0;
    // spread doorways across different sides when possible
    const usedSide = new Set<number>();
    while (carved < want && guard++ < 80 && edges.length > 0) {
      const i = Math.floor(rand() * edges.length);
      const e = edges.splice(i, 1)[0];
      e.knock();
      carved++;
      void usedSide;
    }
  }

  // ---- 6. a light sprinkle of extra openings (5%) so corridors breathe ----
  for (let y = 1; y < GRID; y++) {
    for (let x = 1; x < GRID; x++) {
      if (wallsN[idxN(x, y)] === 1 && !isRoom(x, y - 1) && !isRoom(x, y) && rand() < 0.05) wallsN[idxN(x, y)] = 0;
      if (wallsW[idxW(x, y)] === 1 && !isRoom(x - 1, y) && !isRoom(x, y) && rand() < 0.05) wallsW[idxW(x, y)] = 0;
    }
  }

  // ---- 7. connectivity repair: flood from spawn, knock walls until one region ----
  const visited2 = new Uint8Array(GRID * GRID);
  const queue = new Int32Array(GRID * GRID);
  const flood = (): number => {
    visited2.fill(0);
    let head = 0;
    let tail = 0;
    const sc = roomCenter(ROOMS[0]);
    queue[tail++] = sc.y * W + sc.x;
    visited2[sc.y * W + sc.x] = 1;
    while (head < tail) {
      const c = queue[head++];
      const cx = c % W;
      const cy = (c / W) | 0;
      // N
      if (cy > 0 && !wallsN[idxN(cx, cy)] && !visited2[c - W]) { visited2[c - W] = 1; queue[tail++] = c - W; }
      // S
      if (cy < GRID - 1 && !wallsN[idxN(cx, cy + 1)] && !visited2[c + W]) { visited2[c + W] = 1; queue[tail++] = c + W; }
      // W
      if (cx > 0 && !wallsW[idxW(cx, cy)] && !visited2[c - 1]) { visited2[c - 1] = 1; queue[tail++] = c - 1; }
      // E
      if (cx < GRID - 1 && !wallsW[idxW(cx + 1, cy)] && !visited2[c + 1]) { visited2[c + 1] = 1; queue[tail++] = c + 1; }
    }
    return tail;
  };
  const ensureConnected = (): void => {
    let reach = flood();
    let guard = 0;
    while (reach < GRID * GRID && guard++ < 200) {
      let fixed = false;
      outer: for (let y = 0; y < GRID; y++) {
        for (let x = 0; x < GRID; x++) {
          const c = y * W + x;
          if (!visited2[c]) continue;
          if (y > 0 && wallsN[idxN(x, y)] && !visited2[c - W]) { wallsN[idxN(x, y)] = 0; fixed = true; break outer; }
          if (y < GRID - 1 && wallsN[idxN(x, y + 1)] && !visited2[c + W]) { wallsN[idxN(x, y + 1)] = 0; fixed = true; break outer; }
          if (x > 0 && wallsW[idxW(x, y)] && !visited2[c - 1]) { wallsW[idxW(x, y)] = 0; fixed = true; break outer; }
          if (x < GRID - 1 && wallsW[idxW(x + 1, y)] && !visited2[c + 1]) { wallsW[idxW(x + 1, y)] = 0; fixed = true; break outer; }
        }
      }
      if (!fixed) break;
      reach = flood();
    }
  };
  ensureConnected();

  const find = (kind: RoomKind): RoomRect => ROOMS.find((r) => r.kind === kind) as RoomRect;
  const spawn = find('spawn');
  const hub = find('hub');
  const electrical = find('electrical');
  const stairwell = find('stairwell');
  const party = find('party');

  let breachEdge = { edgeX: hub.x + hub.w, cy: roomCenter(hub).y };
  // THE HUB breach: force a solid 3-cell wall run on the hub room's east edge
  // so there is always a real wall for the hole-in-the-wall prop to live in.
  // A guaranteed doorway on the south boundary keeps the room reachable, then
  // connectivity is re-verified (sealing can only ever be a no-op then).
  {
    const edgeX = hub.x + hub.w;
    const cy = roomCenter(hub).y;
    for (let y = cy - 1; y <= cy + 1; y++) {
      if (y >= 0 && y < GRID) wallsW[idxW(edgeX, y)] = 1;
    }
    // guaranteed opening on the south boundary of the hub room
    const sx = hub.x + 1;
    const sy = hub.y + hub.h;
    if (sx < GRID && sy < GRID) wallsN[idxN(sx, sy)] = 0;
    ensureConnected();
    breachEdge = { edgeX, cy };
  }

  // Party door: prefer a SOLID north boundary edge (a real door in a real wall)
  let partyDoorWall: MazeData['partyDoorWall'] = null;
  {
    const solid: number[] = [];
    for (let x = party.x; x < party.x + party.w; x++) {
      if (party.y > 0 && wallsN[idxN(x, party.y)] === 1) solid.push(x);
    }
    if (solid.length > 0) {
      const cx = solid[Math.floor(rand() * solid.length)];
      partyDoorWall = { cx, cy: party.y, dir: 'N' };
    } else {
      const y2 = party.y + party.h - 1;
      partyDoorWall = { cx: party.x, cy: y2, dir: 'W' };
    }
  }

  // ---- pillars inside pillar halls (at interior grid corners) ----
  const pillars: { x: number; z: number }[] = [];
  for (const r of ROOMS) {
    if (r.kind !== 'pillars') continue;
    for (let y = r.y + 1; y < r.y + r.h; y++) {
      for (let x = r.x + 1; x < r.x + r.w; x++) {
        pillars.push({ x: x * CELL, z: y * CELL });
      }
    }
  }

  return {
    wallsN,
    wallsW,
    roomId,
    roomAt: ROOMS,
    pillars,
    spawnCell: roomCenter(spawn),
    hubCell: roomCenter(hub),
    electricalCell: roomCenter(electrical),
    stairwellCell: roomCenter(stairwell),
    partyCell: roomCenter(party),
    partyDoorWall,
    breachWall: breachEdge,
  };
}

// ---------- pathfinding ----------

const prevBuf = new Int32Array(GRID * GRID);
const markBuf = new Uint8Array(GRID * GRID);
const queueBuf = new Int32Array(GRID * GRID);
const distBuf = new Float32Array(GRID * GRID);
// lazy Dijkstra can push a node more than once (one entry per improvement);
// 8x cells is a safe upper bound on improvements per search
const heapBuf = new Int32Array(GRID * GRID * 8);

/**
 * Path between cells. Without `cost` this is a plain BFS shortest path. With a
 * cost callback it runs Dijkstra where stepping INTO cell (nx, ny) costs
 * cost(nx, ny) - used by the Smiler to route through the dark.
 * Returns list of cells from start (excl) to goal (incl); [] when unreachable.
 */
export function findPath(
  m: MazeData,
  sx: number,
  sy: number,
  gx: number,
  gy: number,
  cost?: (cx: number, cy: number) => number
): { x: number; y: number }[] {
  if (sx === gx && sy === gy) return [];
  const W = GRID;
  const start = sy * W + sx;
  const goal = gy * W + gx;

  if (!cost) {
    markBuf.fill(0);
    let head = 0;
    let tail = 0;
    queueBuf[tail++] = start;
    markBuf[start] = 1;
    prevBuf[start] = -1;
    let found = false;
    while (head < tail) {
      const c = queueBuf[head++];
      if (c === goal) { found = true; break; }
      const cx = c % W;
      const cy = (c / W) | 0;
      const wRow = cy * (GRID + 1); // wallsW stride is GRID+1 (edge grid)
      if (cy > 0 && !m.wallsN[c] && !markBuf[c - W]) { markBuf[c - W] = 1; prevBuf[c - W] = c; queueBuf[tail++] = c - W; }
      if (cy < GRID - 1 && !m.wallsN[c + W] && !markBuf[c + W]) { markBuf[c + W] = 1; prevBuf[c + W] = c; queueBuf[tail++] = c + W; }
      if (cx > 0 && !m.wallsW[wRow + cx] && !markBuf[c - 1]) { markBuf[c - 1] = 1; prevBuf[c - 1] = c; queueBuf[tail++] = c - 1; }
      if (cx < GRID - 1 && !m.wallsW[wRow + cx + 1] && !markBuf[c + 1]) { markBuf[c + 1] = 1; prevBuf[c + 1] = c; queueBuf[tail++] = c + 1; }
    }
    if (!found) return [];
  } else {
    // Dijkstra with a binary min-heap (lazy deletion: a node may be pushed
    // several times as its distance improves; stale entries are skipped via
    // the current distBuf value)
    distBuf.fill(Infinity);
    prevBuf.fill(-1);
    const heapPos = markBuf; // reuse as "in heap" marker (0/1)
    heapPos.fill(0);
    let heapLen = 0;
    const push = (node: number): void => {
      if (heapLen >= heapBuf.length) return; // safety valve, never hit in practice
      heapBuf[heapLen++] = node;
      let i = heapLen - 1;
      while (i > 0) {
        const p = (i - 1) >> 1;
        if (distBuf[heapBuf[p]] <= distBuf[heapBuf[i]]) break;
        const t = heapBuf[p]; heapBuf[p] = heapBuf[i]; heapBuf[i] = t;
        i = p;
      }
    };
    const pop = (): number => {
      const top = heapBuf[0];
      heapBuf[0] = heapBuf[--heapLen];
      heapPos[top] = 0; // allow re-push if the distance improves later
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let m2 = i;
        if (l < heapLen && distBuf[heapBuf[l]] < distBuf[heapBuf[m2]]) m2 = l;
        if (r < heapLen && distBuf[heapBuf[r]] < distBuf[heapBuf[m2]]) m2 = r;
        if (m2 === i) break;
        const t = heapBuf[m2]; heapBuf[m2] = heapBuf[i]; heapBuf[i] = t;
        i = m2;
      }
      return top;
    };
    distBuf[start] = 0;
    push(start);
    heapPos[start] = 1;
    let found = false;
    while (heapLen > 0) {
      const c = pop();
      if (c === goal) { found = true; break; }
      const cx = c % W;
      const cy = (c / W) | 0;
      const wRow = cy * (GRID + 1); // wallsW stride is GRID+1 (edge grid)
      const relax = (n: number, nx: number, ny: number): void => {
        const nd = distBuf[c] + cost(nx, ny);
        if (nd < distBuf[n]) {
          distBuf[n] = nd;
          prevBuf[n] = c;
          if (!heapPos[n]) { heapPos[n] = 1; push(n); }
        }
      };
      if (cy > 0 && !m.wallsN[c]) relax(c - W, cx, cy - 1);
      if (cy < GRID - 1 && !m.wallsN[c + W]) relax(c + W, cx, cy + 1);
      if (cx > 0 && !m.wallsW[wRow + cx]) relax(c - 1, cx - 1, cy);
      if (cx < GRID - 1 && !m.wallsW[wRow + cx + 1]) relax(c + 1, cx + 1, cy);
    }
    if (!found) return [];
  }

  const path: { x: number; y: number }[] = [];
  let cur = goal;
  while (cur !== start && cur !== -1) {
    path.push({ x: cur % W, y: (cur / W) | 0 });
    cur = prevBuf[cur];
  }
  path.reverse();
  return path;
}

/** Line of sight between two world points, sampling wall crossings. */
export function hasLOS(m: MazeData, ax: number, az: number, bx: number, bz: number): boolean {
  const dx = bx - ax;
  const dz = bz - az;
  const dist = Math.hypot(dx, dz);
  const steps = Math.max(1, Math.ceil(dist / 0.22));
  let pcx = Math.floor(ax / CELL);
  let pcy = Math.floor(az / CELL);
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = ax + dx * t;
    const z = az + dz * t;
    const cx = Math.max(0, Math.min(GRID - 1, Math.floor(x / CELL)));
    const cy = Math.max(0, Math.min(GRID - 1, Math.floor(z / CELL)));
    if (cx !== pcx || cy !== pcy) {
      // crossed in x?
      if (cx !== pcx) {
        const edge = cx > pcx ? pcx + 1 : pcx;
        if (m.wallsW[cy * (GRID + 1) + edge]) return false;
      }
      // crossed in z?
      if (cy !== pcy) {
        const edge = cy > pcy ? pcy + 1 : pcy;
        if (m.wallsN[edge * GRID + cx]) return false;
      }
      pcx = cx;
      pcy = cy;
    }
  }
  return true;
}

/**
 * Random cell at least `minDist` manhattan cells away. When `preferDark` is
 * provided the best-scoring sample wins: distance plus how dark the cell is,
 * so the Smiler always respawns out in the shadows.
 */
export function randomOpenCellFar(
  m: MazeData,
  rand: () => number,
  fromX: number,
  fromY: number,
  minDist: number,
  preferDark?: (x: number, y: number) => number
): { x: number; y: number } {
  let best: { x: number; y: number } | null = null;
  let bestScore = -Infinity;
  for (let tries = 0; tries < 70; tries++) {
    const x = Math.floor(rand() * GRID);
    const y = Math.floor(rand() * GRID);
    const d = Math.abs(x - fromX) + Math.abs(y - fromY);
    if (d < minDist && tries < 50) continue;
    const dark = preferDark ? preferDark(x, y) : 0;
    const score = Math.min(d, 34) * 0.05 + dark * 1.5 + rand() * 0.3;
    if (score > bestScore) {
      bestScore = score;
      best = { x, y };
    }
  }
  return best ?? { x: GRID - 2, y: GRID - 2 };
}
