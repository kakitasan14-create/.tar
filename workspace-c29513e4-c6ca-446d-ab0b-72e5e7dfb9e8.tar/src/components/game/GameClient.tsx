// Mounts the WebGL canvas, boots the engine and layers all UI overlays.

'use client';

import { useEffect, useRef, useState } from 'react';
import { createGame } from '@/lib/game/game';
import { useGameUI } from '@/lib/game/store';
import { Hud } from './Hud';
import { DialogueBox } from './DialogueBox';
import { NoteOverlay } from './NoteOverlay';
import { MenuScreen, PauseMenu, DeathScreen, EndingScreen } from './Screens';
import { TouchControls } from './TouchControls';

export default function GameClient() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const screen = useGameUI((s) => s.screen);
  const eyelids = useGameUI((s) => s.eyelids);
  const fade = useGameUI((s) => s.fade);
  const flashWhite = useGameUI((s) => s.flashWhite);
  const camRaised = useGameUI((s) => s.camRaised);

  useEffect(() => {
    if (!canvasRef.current) return;
    let game: ReturnType<typeof createGame> | null = null;
    try {
      game = createGame(canvasRef.current);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'WebGL failed to initialize';
      queueMicrotask(() => setError(msg));
    }
    return () => {
      // engine disposes itself via singleton swap; full cleanup on unmount:
      window.dispatchEvent(new Event('backrooms-unmount'));
      void game;
    };
  }, []);

  const inGame = screen === 'playing' || screen === 'paused' || screen === 'intro';

  return (
    <div className="fixed inset-0 overflow-hidden bg-black">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black p-6 text-center font-vhs text-2xl text-[#e08b8b]">
          CAMCORDER MALFUNCTION: {error}
        </div>
      )}

      {inGame && <Hud />}
      {screen === 'playing' && (
        <>
          {/* naked-eye vignette: the lowered camcorder view is a clean render,
              this soft edge keeps it from feeling like a debug camera */}
          {!camRaised && (
            <div
              className="pointer-events-none fixed inset-0 z-10"
              style={{ background: 'radial-gradient(ellipse at center, transparent 48%, rgba(0,0,0,0.6) 100%)' }}
            />
          )}
          <DialogueBox />
          <NoteOverlay />
          <TouchControls />
        </>
      )}
      {screen === 'menu' && <MenuScreen />}
      {screen === 'paused' && <PauseMenu />}
      {screen === 'death' && <DeathScreen />}
      {(screen === 'endingA' || screen === 'endingB' || screen === 'endingC') && (
        <EndingScreen kind={screen === 'endingA' ? 'A' : screen === 'endingB' ? 'B' : 'C'} />
      )}

      {/* cinematic overlays */}
      {eyelids && (
        <div className="pointer-events-none fixed inset-0 z-40">
          <div
            className="absolute inset-x-0 top-0 h-[55%] bg-black"
            style={{ animation: 'eyelid-top 2.2s ease-out both', borderRadius: '0 0 45% 45%/0 0 30% 30%' }}
          />
          <div
            className="absolute inset-x-0 bottom-0 h-[55%] bg-black"
            style={{ animation: 'eyelid-bottom 2.2s ease-out both', borderRadius: '45% 45% 0 0/30% 30% 0 0' }}
          />
        </div>
      )}
      <div
        className="pointer-events-none fixed inset-0 z-40 bg-black transition-opacity duration-[1800ms]"
        style={{ opacity: fade ? 1 : 0 }}
      />
      <div
        className="pointer-events-none fixed inset-0 z-40 bg-[#fff8e8] transition-opacity duration-200"
        style={{ opacity: flashWhite ? 0.95 : 0 }}
      />
    </div>
  );
}
