// Touch controls: virtual joystick (left), look-drag (right half), action buttons.

'use client';

import { useEffect, useRef } from 'react';
import { getGame } from '@/lib/game/game';
import { useGameUI } from '@/lib/game/store';

export function TouchControls() {
  const touch = useGameUI((s) => s.touch);
  const screen = useGameUI((s) => s.screen);
  const camRaised = useGameUI((s) => s.camRaised);
  const padRef = useRef<HTMLDivElement>(null);
  const padState = useRef({ active: false, id: -1, cx: 0, cy: 0 });
  const lookState = useRef({ id: -1, x: 0, y: 0 });
  const sprintRef = useRef(false);

  const active = touch && screen === 'playing';

  useEffect(() => {
    if (!active) return;

    const onDown = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        const el = t.target as HTMLElement;
        if (el.closest('[data-touch-ui]')) continue; // buttons handle themselves
        if (t.clientX < window.innerWidth * 0.45 && !padState.current.active) {
          padState.current = { active: true, id: t.identifier, cx: t.clientX, cy: t.clientY };
        } else if (lookState.current.id === -1) {
          lookState.current = { id: t.identifier, x: t.clientX, y: t.clientY };
        }
      }
    };
    const onMove = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier === padState.current.id) {
          const dx = (t.clientX - padState.current.cx) / 52;
          const dy = (t.clientY - padState.current.cy) / 52;
          const len = Math.hypot(dx, dy);
          const cl = len > 1 ? 1 / len : 1;
          getGame()?.setTouchMove(dx * cl, -dy * cl);
        } else if (t.identifier === lookState.current.id) {
          const dx = t.clientX - lookState.current.x;
          const dy = t.clientY - lookState.current.y;
          lookState.current.x = t.clientX;
          lookState.current.y = t.clientY;
          getGame()?.touchLook(dx * 2.6, dy * 2.6);
        }
      }
      e.preventDefault();
    };
    const onUp = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier === padState.current.id) {
          padState.current = { active: false, id: -1, cx: 0, cy: 0 };
          getGame()?.setTouchMove(0, 0);
        } else if (t.identifier === lookState.current.id) {
          lookState.current.id = -1;
        }
      }
    };
    window.addEventListener('touchstart', onDown, { passive: false });
    window.addEventListener('touchmove', onMove, { passive: false });
    window.addEventListener('touchend', onUp);
    window.addEventListener('touchcancel', onUp);
    return () => {
      window.removeEventListener('touchstart', onDown);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onUp);
      window.removeEventListener('touchcancel', onUp);
      getGame()?.setTouchMove(0, 0);
    };
  }, [active]);

  if (!active) return null;

  const btn =
    'data-touch-ui flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#f2ecd2]/70 bg-black/40 font-vhs text-sm text-[#f2ecd2] vhs-text active:bg-[#f2ecd2]/20 select-none';

  return (
    <div className="fixed inset-0 z-25 select-none">
      {/* joystick base */}
      <div className="pointer-events-none absolute bottom-24 left-8 h-28 w-28 rounded-full border-2 border-[#f2ecd2]/40 bg-black/20">
        <div className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#f2ecd2]/50" />
      </div>

      {/* action buttons */}
      <div className="absolute bottom-24 right-6 flex flex-col items-end gap-3">
        <div className="flex gap-3">
          <button
            className={btn}
            onTouchStart={(e) => {
              e.stopPropagation();
              getGame()?.setTouchSprint(true);
              sprintRef.current = true;
            }}
            onTouchEnd={(e) => {
              e.stopPropagation();
              getGame()?.setTouchSprint(false);
              sprintRef.current = false;
            }}
          >
            RUN
          </button>
          <button
            className={`${btn} ${camRaised ? '' : 'border-[#e0b3a3] bg-[#e0b3a3]/10'}`}
            onTouchStart={(e) => {
              e.stopPropagation();
              getGame()?.toggleCamcorder();
            }}
          >
            CAM
          </button>
          <button
            className={btn}
            onTouchStart={(e) => {
              e.stopPropagation();
              getGame()?.toggleFlashlight();
            }}
          >
            LIGHT
          </button>
        </div>
        <div className="flex gap-3">
          <button
            className={btn}
            onTouchStart={(e) => {
              e.stopPropagation();
              getGame()?.drinkWater();
            }}
          >
            DRINK
          </button>
          <button
            className={btn}
            onTouchStart={(e) => {
              e.stopPropagation();
              const g = getGame();
              if (g) g.tryInteract();
            }}
          >
            USE
          </button>
        </div>
      </div>

      {/* pause */}
      <button
        className="data-touch-ui absolute right-4 top-12 border border-[#f2ecd2]/60 bg-black/40 px-3 py-1 font-vhs text-lg text-[#f2ecd2]"
        onTouchStart={(e) => {
          e.stopPropagation();
          getGame()?.pause();
        }}
      >
        II
      </button>
    </div>
  );
}
