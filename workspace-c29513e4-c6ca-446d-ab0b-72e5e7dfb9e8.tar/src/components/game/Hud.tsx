// Camcorder OSD overlay: REC dot, battery, timestamp, objective, prompts,
// stamina, almond water counter and the hunted vignette.

'use client';

import { useEffect, useState } from 'react';
import { useGameUI } from '@/lib/game/store';

function formatClock(elapsed: number): string {
  const total = 15 * 3600 + 47 * 60 + Math.floor(elapsed);
  const h = Math.floor(total / 3600) % 12;
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const ampm = Math.floor(total / 3600) % 24 < 12 ? 'AM' : 'PM';
  return `${ampm} ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function Hud() {
  const {
    prompt,
    stamina,
    exhausted,
    water,
    notes,
    notesTotal,
    objective,
    objectiveSub,
    hunted,
    flashOn,
    camRaised,
    tracked,
    elapsed,
    touch,
    screen,
    dialogue,
  } = useGameUI();
  const [batt, setBatt] = useState(100);

  useEffect(() => {
    const t = window.setInterval(() => setBatt((b) => Math.max(9, b - 1)), 45000);
    return () => window.clearInterval(t);
  }, []);

  const battBars = Math.ceil((batt / 100) * 3);

  return (
    <div className="pointer-events-none fixed inset-0 z-20 font-vhs vhs-text text-[#f2ecd2] select-none">
      {/* hunted vignette */}
      {hunted && <div className="vhs-hunted absolute inset-0" />}

      {/* top-left: REC + lens tracking - viewfinder OSD, only while raised */}
      {camRaised && (
        <div className="absolute left-4 top-3 flex items-center gap-3 text-lg md:text-xl">
          <span className="vhs-blink inline-block h-3.5 w-3.5 rounded-full bg-[#e33] shadow-[0_0_10px_rgba(255,40,40,0.9)]" />
          <span className="vhs-flicker">REC</span>
          <span className="text-base opacity-80">SP</span>
          {tracked && <span className="vhs-blink ml-1 text-base text-[#e0b3a3]">TRK</span>}
        </div>
      )}

      {/* top-right: battery + notes */}
      <div className="absolute right-4 top-3 flex items-center gap-2 text-lg md:text-xl">
        {flashOn && <span className="opacity-90">LIGHT</span>}
        <span className="opacity-80">{notes.toString().padStart(2, '0')}/{notesTotal}</span>
        {camRaised && (
          <span className="relative inline-block h-4 w-9 border-2 border-[#f2ecd2]/80">
            <span className="absolute right-[-5px] top-1/2 h-2 w-1 -translate-y-1/2 bg-[#f2ecd2]/80" />
            <span className="absolute inset-y-0.5 left-0.5 flex gap-0.5">
              {[0, 1, 2].map((i) => (
                <span key={i} className={`w-1.5 ${i < battBars ? 'bg-[#f2ecd2]' : 'bg-transparent'}`} />
              ))}
            </span>
          </span>
        )}
      </div>

      {/* objective top-center - only once you have control */}
      {screen === 'playing' && (
        <div className="absolute left-1/2 top-3 -translate-x-1/2 text-center">
          <div className="text-lg md:text-xl tracking-widest">{objective}</div>
          <div className="text-sm opacity-70">{objectiveSub}</div>
        </div>
      )}

      {/* bottom-left: timestamp - camcorder OSD */}
      {camRaised && (
        <div className="absolute bottom-4 left-4 text-lg md:text-xl leading-tight">
          <div>JUN 14 1996</div>
          <div>{formatClock(elapsed)}</div>
        </div>
      )}

      {/* bottom-right: water + stamina */}
      <div className="absolute bottom-4 right-4 flex flex-col items-end gap-2">
        {water > 0 && (
          <div className="text-lg md:text-xl">
            ALMOND WATER x{water} <span className="text-sm opacity-70">[Q]</span>
          </div>
        )}
        {stamina < 0.995 && (
          <div className={`h-2 w-36 border border-[#f2ecd2]/70 ${exhausted ? 'vhs-blink' : ''}`}>
            <div
              className={`h-full ${exhausted ? 'bg-[#e33]' : 'bg-[#f2ecd2]'}`}
              style={{ width: `${Math.round(stamina * 100)}%`, transition: 'width 120ms linear' }}
            />
          </div>
        )}
      </div>

      {/* crosshair - only while playing; difference blend keeps it visible on
          both bright wallpaper and near-black corridors */}
      {screen === 'playing' && (
        <div
          className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white mix-blend-difference"
          style={{ boxShadow: '0 0 3px rgba(255,255,255,0.55)' }}
        />
      )}

      {/* interaction prompt (hidden while the radio is talking - it sat under the box) */}
      {prompt && !dialogue && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 text-center text-xl md:text-2xl">
          <span className="border border-[#f2ecd2]/60 bg-black/40 px-3 py-1">
            [{touch ? 'USE' : 'E'}] {prompt}
          </span>
        </div>
      )}

      {/* camcorder corner brackets - viewfinder OSD */}
      {camRaised &&
        (
          [
            'left-3 top-3 border-l-2 border-t-2',
            'right-3 top-3 border-r-2 border-t-2',
            'left-3 bottom-3 border-l-2 border-b-2',
            'right-3 bottom-3 border-r-2 border-b-2',
          ] as const
        ).map((cls) => (
          <div key={cls} className={`absolute h-8 w-8 border-[#f2ecd2]/50 ${cls}`} />
        ))}
    </div>
  );
}
