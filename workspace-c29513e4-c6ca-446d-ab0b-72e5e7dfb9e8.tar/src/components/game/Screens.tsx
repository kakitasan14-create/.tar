// VHS title screen, pause menu, death screen and both ending screens.

'use client';

import { useGameUI } from '@/lib/game/store';
import { getGame } from '@/lib/game/game';
import { GameLogo } from './Logo';

function StaticOverlay({ opacity = 0.25 }: { opacity?: number }) {
  return <div className="vhs-noise pointer-events-none absolute inset-0" style={{ opacity }} />;
}

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

function MenuItem({
  label,
  hint,
  dim,
  onClick,
}: {
  label: string;
  hint?: string;
  dim?: boolean;
  onClick?: () => void;
}) {
  // tape-deck key sounds: hover blip, press thunk (no-op until the first
  // user gesture unlocks WebAudio - the browser guarantees that anyway)
  const hover = () => {
    if (!dim) getGame()?.uiTick();
  };
  const press = () => {
    if (!dim) {
      getGame()?.uiConfirm();
      onClick?.();
    }
  };
  return (
    <button
      disabled={dim}
      onMouseEnter={hover}
      onClick={press}
      className={`group flex items-baseline gap-3 text-left font-vhs text-[22px] leading-none tracking-[0.14em] transition-all md:text-2xl ${
        dim
          ? 'cursor-not-allowed text-[#6d6a5c]'
          : 'text-[#ddd8c2] hover:text-[#fff6d8]'
      }`}
    >
      <span
        className={`w-5 text-[#e03b2f] opacity-0 transition-opacity group-hover:opacity-100 ${dim ? 'hidden' : ''}`}
      >
        &#9656;
      </span>
      <span className={`menu-glow ${dim ? '' : 'group-hover:menu-glow-on'}`}>{label}</span>
      {hint && <span className="text-[13px] tracking-[0.2em] text-[#8d8871] md:text-sm">{hint}</span>}
    </button>
  );
}

/** Title screen: locked-off shot of the camcorder on the carpet (in-engine),
 *  with the tape-deck style menu column on the left. */
export function MenuScreen() {
  const muted = useGameUI((s) => s.muted);
  const touch = useGameUI((s) => s.touch);
  const vhsLevel = useGameUI((s) => s.vhsLevel);
  const sensLevel = useGameUI((s) => s.sensLevel);
  const menuPanel = useGameUI((s) => s.menuPanel);
  const exitToast = useGameUI((s) => s.exitToast);
  const setUI = useGameUI((s) => s.set);

  const back = () => setUI({ menuPanel: 'root' });

  return (
    <div className="fixed inset-0 z-30 overflow-hidden font-vhs text-[#e8e2d0]">
      <StaticOverlay opacity={0.13} />
      <div className="vhs-scanline pointer-events-none absolute inset-0" />

      <div className="absolute bottom-5 left-[7vw] z-10 text-xs tracking-[0.22em] text-[#8d8871] opacity-60 md:left-[9vw]">
        PROCEDURAL FLOOR ENGINE · BUILD 1.0 · EVERY TAPE IS A DIFFERENT MAZE
      </div>
      <div className="absolute bottom-5 right-6 z-10 text-right text-xs leading-relaxed opacity-60 md:text-sm">
        <div>HEADPHONES RECOMMENDED</div>
        <div>CONTAINS FLASHING IMAGES</div>
      </div>

      {/* left rail: logo on top, tape-deck menu centered in the space below -
          one flex column so the two can NEVER collide, even at 720p / short viewports */}
      <div className="absolute bottom-[9vh] left-[6vw] top-[6vh] z-10 flex flex-col md:left-[8vw]">
        <GameLogo hero />
        <div className="flex min-h-0 flex-1 items-center">
          <div className="max-h-full overflow-y-auto py-2 pl-[1vw] vhs-scroll">
        {menuPanel === 'root' && (
          <div className="flex flex-col gap-4">
            <MenuItem label="TAPES" onClick={() => setUI({ menuPanel: 'tapes' })} />
            <MenuItem label="OPTIONS" onClick={() => setUI({ menuPanel: 'options' })} />
            <MenuItem label="EXTRAS" onClick={() => setUI({ menuPanel: 'extras' })} />
            <MenuItem label="EXIT" onClick={() => getGame()?.exitToDesktop()} />
          </div>
        )}

        {menuPanel === 'tapes' && (
          <div className="flex flex-col gap-4">
            <MenuItem label="TAPE #0614" hint="LEVEL 0" onClick={() => getGame()?.startRun()} />
            <MenuItem label="TAPE #0615" hint="SIGNAL LOST" dim />
            <MenuItem label="TAPE #0616" hint="THE HUB - FIND IT IN #0614" dim />
            <div className="mt-2 max-w-[300px] text-sm leading-relaxed opacity-60">
              Only one tape has been recovered from Level 0. The others are still down there. Something is watching
              them back.
            </div>
            <MenuItem label="PLAY TAPE #0614" onClick={() => getGame()?.startRun()} />
            <MenuItem label="BACK" onClick={back} />
          </div>
        )}

        {menuPanel === 'options' && (
          <div className="flex flex-col gap-4">
            <MenuItem label={`SOUND: ${muted ? 'OFF' : 'ON'}`} onClick={() => getGame()?.setMuted(!muted)} />
            <MenuItem
              label={`LOOK SENSITIVITY: ${['SLOW', 'NORMAL', 'FAST'][sensLevel] ?? 'NORMAL'}`}
              onClick={() => getGame()?.setSensLevel(sensLevel + 1)}
            />
            <MenuItem
              label={`TAPE DEGRADATION: ${['LOW', 'MED', 'HIGH'][vhsLevel] ?? 'MED'}`}
              onClick={() => getGame()?.setVhsLevel((vhsLevel + 1) % 3)}
            />
            {touch && (
              <MenuItem label="TOUCH CONTROLS: ON" onClick={() => setUI({ touch: false })} />
            )}
            <div className="mt-2 max-w-[320px] text-sm leading-relaxed opacity-60">
              TAPE DEGRADATION controls how hard the camcorder chews the picture. MED is how the tape was found.
            </div>
            <MenuItem label="BACK" onClick={back} />
          </div>
        )}

        {menuPanel === 'extras' && (
          <div className="flex flex-col gap-3">
            <div className="grid max-w-[380px] grid-cols-1 gap-x-8 gap-y-1 text-sm opacity-85 md:grid-cols-2">
              {(touch
                ? ([
                    ['LEFT PAD', 'MOVE'],
                    ['RIGHT DRAG', 'LOOK'],
                    ['RUN BTN', 'SPRINT (LOUD)'],
                    ['USE BTN', 'INTERACT'],
                    ['DRINK BTN', 'ALMOND WATER'],
                    ['CAM BTN', 'CAMCORDER'],
                    ['LIGHT BTN', 'FLASHLIGHT'],
                  ] as const)
                : ([
                    ['W A S D', 'MOVE'],
                    ['MOUSE', 'LOOK'],
                    ['SHIFT', 'SPRINT (LOUD)'],
                    ['E', 'INTERACT'],
                    ['Q', 'DRINK ALMOND WATER'],
                    ['J / C / RMB', 'CAMCORDER'],
                    ['F', 'FLASHLIGHT'],
                  ] as const)
              ).map((pair) => {
                const [k, v] = pair as readonly [string, string];
                return (
                  <div key={k} className="flex justify-between gap-4">
                    <span className="text-[#c8b878]">{k}</span>
                    <span className="opacity-80">{v}</span>
                  </div>
                );
              })}
            </div>
            <div className="max-w-[380px] text-sm leading-snug text-[#e0b3a3] opacity-90">
              IT HUNTS BY SOUND. AND IT ONLY EXISTS ON TAPE - LOWER THE CAMCORDER AND IT IS NOT THERE.{' '}
              <span className="vhs-blink">WHICH IS WORSE.</span>
            </div>
            <div className="max-w-[380px] text-sm leading-snug text-[#c8b878] opacity-80">
              THE WALLPAPER LIES. SOME WALLS ARE HOLLOW. THE OLD-TIMERS CALL WHAT IS BEHIND THEM &quot;THE HUB&quot;.
            </div>
            <div className="max-w-[380px] text-xs leading-snug opacity-50">
              Fully procedural recovery - every texture, sound and corridor is synthesized the moment you press play.
            </div>
            <MenuItem label="BACK" onClick={back} />
          </div>
        )}
          </div>
        </div>
      </div>

      {exitToast && (
        <div className="absolute bottom-16 left-1/2 z-20 -translate-x-1/2 border border-[#e8e2d0]/40 bg-black/70 px-5 py-2 text-lg tracking-[0.2em]">
          {exitToast}
        </div>
      )}
    </div>
  );
}

export function PauseMenu() {
  const muted = useGameUI((s) => s.muted);
  const sensLevel = useGameUI((s) => s.sensLevel);
  return (
    <div className="fixed inset-0 z-30 flex flex-col items-center justify-center bg-black/85 font-vhs text-[#f2ecd2]">
      <StaticOverlay opacity={0.1} />
      <div className="relative z-10 flex flex-col items-center gap-4 text-center">
        <div className="text-4xl tracking-[0.3em]">PAUSED</div>
        <div className="text-lg opacity-70">TAPE ROLLING - THE FLOOR WAITS</div>
        <button
          className="mt-4 border-2 border-[#f2ecd2]/80 px-8 py-2 text-2xl hover:bg-[#f2ecd2] hover:text-black"
          onClick={() => getGame()?.resume()}
        >
          RESUME
        </button>
        <button
          className="border border-[#f2ecd2]/50 px-6 py-1 text-lg hover:bg-[#f2ecd2]/10"
          onClick={() => getGame()?.setMuted(!muted)}
        >
          SOUND: {muted ? 'OFF' : 'ON'}
        </button>
        <button
          className="border border-[#f2ecd2]/50 px-6 py-1 text-lg hover:bg-[#f2ecd2]/10"
          onClick={() => getGame()?.setSensLevel(sensLevel + 1)}
        >
          LOOK SENSITIVITY: {['SLOW', 'NORMAL', 'FAST'][sensLevel] ?? 'NORMAL'}
        </button>
        <button
          className="border border-[#f2ecd2]/50 px-6 py-1 text-lg hover:bg-[#f2ecd2]/10"
          onClick={() => getGame()?.retry()}
        >
          REWIND TO SPAWN (LOST?)
        </button>
        <button
          className="border border-[#f2ecd2]/50 px-6 py-1 text-lg opacity-80 hover:bg-[#f2ecd2]/10"
          onClick={() => getGame()?.toMenu()}
        >
          EJECT TAPE (MAIN MENU)
        </button>
      </div>
    </div>
  );
}

export function DeathScreen() {
  const deaths = useGameUI((s) => s.deaths);
  return (
    <div className="fixed inset-0 z-30 flex flex-col items-center justify-center bg-black font-vhs text-[#f2ecd2]">
      <StaticOverlay opacity={0.5} />
      <div className="relative z-10 flex flex-col items-center gap-3 px-6 text-center">
        <div className="vhs-flicker text-7xl tracking-widest text-[#e33] vhs-text md:text-8xl">NO SIGNAL</div>
        <div className="text-xl opacity-80">SIGNAL LOST - THE TAPE KEEPS RECORDING</div>
        <div className="mt-2 text-lg opacity-70">IT SMILED FOR THE CAMERA. RECOVERY TEAMS: {deaths}</div>
        <button
          className="mt-6 border-2 border-[#f2ecd2]/80 px-8 py-2 text-2xl hover:bg-[#f2ecd2] hover:text-black"
          onClick={() => getGame()?.retry()}
        >
          REWIND - TRY AGAIN
        </button>
        <button
          className="border border-[#f2ecd2]/50 px-6 py-1 text-lg opacity-80 hover:bg-[#f2ecd2]/10"
          onClick={() => getGame()?.toMenu()}
        >
          MAIN MENU
        </button>
      </div>
    </div>
  );
}

export function EndingScreen({ kind }: { kind: 'A' | 'B' | 'C' }) {
  const stats = useGameUI((s) => s.endingStats);
  const notesTotal = useGameUI((s) => s.notesTotal);

  const archivist = stats && stats.notes >= notesTotal;

  return (
    <div
      className="fixed inset-0 z-30 flex flex-col items-center justify-center pb-14 font-vhs text-[#f2ecd2]"
      style={{
        background:
          kind === 'A'
            ? 'radial-gradient(ellipse at 50% 30%, #101a10 0%, #050705 70%)'
            : kind === 'B'
              ? 'radial-gradient(ellipse at 50% 30%, #2a0a0a 0%, #070303 70%)'
              : 'radial-gradient(ellipse at 50% 30%, #1a1d18 0%, #070807 70%)',
      }}
    >
      <StaticOverlay opacity={0.12} />
      <div className="vhs-scanline pointer-events-none absolute inset-0" />
      {kind === 'B' && (
        <div className="vhs-flicker absolute text-[26vw] leading-none text-[#c8272f]/25 select-none" style={{ fontFamily: 'VT323, monospace' }}>
          =)
        </div>
      )}
      {kind === 'C' && (
        <div className="pointer-events-none absolute bottom-2 right-4 z-0 text-[10px] tracking-[0.4em] text-[#8fa08a]/50">
          CONCRETE ALL THE WAY UP
        </div>
      )}
      <div className="relative z-10 flex max-w-[680px] flex-col items-center gap-3 px-6 text-center">
        {kind === 'A' ? (
          <>
            <div className="text-lg tracking-[0.4em] text-[#8fd8a0]">ENDING RECOVERED - TAPE A</div>
            <h2 className="text-5xl md:text-6xl vhs-text" style={{ color: '#a8d8b0' }}>
              DESCENT
            </h2>
            <p className="mt-2 max-w-[520px] text-xl leading-relaxed opacity-90">
              You climbed down into the cold. The hum faded above you like a memory of a memory. Level 1 is dark,
              wet, and REAL - and somewhere ahead, a radio is calling your tape number.
            </p>
            <p className="mt-1 text-lg opacity-60">M.E.G. FIELD NOTE: subject exits Level 0. Status: alive. Smile: their own.</p>
          </>
        ) : kind === 'B' ? (
          <>
            <div className="text-lg tracking-[0.4em] text-[#e08b8b]">ENDING RECOVERED - TAPE B</div>
            <h2 className="text-5xl md:text-6xl vhs-text" style={{ color: '#e05555' }}>
              LEVEL FUN =)
            </h2>
            <p className="mt-2 max-w-[520px] text-xl leading-relaxed opacity-90">
              The music box was so pretty. The balloons never touch the floor. Everyone stayed. Everyone smiled.
              The camera keeps recording forever, and the party is SO glad you came.
            </p>
            <p className="mt-1 text-lg opacity-60">M.E.G. FIELD NOTE: do not open doors marked =). We told you. =)</p>
          </>
        ) : (
          <>
            <div className="text-lg tracking-[0.4em] text-[#c8d8b8]">ENDING RECOVERED - TAPE C</div>
            <h2 className="text-5xl md:text-6xl vhs-text" style={{ color: '#d8cdb0' }}>
              THE HUB
            </h2>
            <p className="mt-2 max-w-[520px] text-xl leading-relaxed opacity-90">
              Concrete tunnels. Caged lamps. Voices that do not smile. You crawled out of the yellow and into the
              oldest room in the building - the crossroads of every level, and the first door in a long time that
              did not want anything from you. The lift is going up. There are maps on the table.
            </p>
            <p className="mt-1 text-lg opacity-60">M.E.G. FIELD NOTE: subject found Outpost Echo-4. The Hub is real. Tell the old-timers they were right.</p>
          </>
        )}

        {stats && (
          <div className="mt-4 grid grid-cols-3 gap-6 border border-[#f2ecd2]/30 px-6 py-3 text-lg">
            <div>
              <div className="opacity-60">TIME</div>
              <div>{fmtTime(stats.time)}</div>
            </div>
            <div>
              <div className="opacity-60">PAGES</div>
              <div>
                {stats.notes}/{notesTotal}
              </div>
            </div>
            <div>
              <div className="opacity-60">REWINDS</div>
              <div>{stats.deaths}</div>
            </div>
          </div>
        )}
        {archivist && <div className="text-lg text-[#c8b878] vhs-blink">ARCHIVIST BADGE UNLOCKED - FULL RECOVERY</div>}

        <div className="mt-6 flex flex-wrap justify-center gap-4">
          <button
            className="border-2 border-[#f2ecd2]/80 px-8 py-2 text-2xl hover:bg-[#f2ecd2] hover:text-black"
            onClick={() => getGame()?.newTape()}
          >
            NEW TAPE - NEW MAZE
          </button>
          <button
            className="border border-[#f2ecd2]/50 px-6 py-2 text-lg opacity-80 hover:bg-[#f2ecd2]/10"
            onClick={() => getGame()?.toMenu()}
          >
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}
