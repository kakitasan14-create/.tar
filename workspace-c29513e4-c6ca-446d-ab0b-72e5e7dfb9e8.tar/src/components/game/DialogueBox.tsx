// Typewriter dialogue box (radio K / inner monologue).

'use client';

import { useEffect, useRef, useState } from 'react';
import { useGameUI } from '@/lib/game/store';
import { getGame } from '@/lib/game/game';

function Typewriter({ text, paused }: { text: string; paused: boolean }) {
  const [shown, setShown] = useState(0);
  const doneRef = useRef(false);
  const setUI = useGameUI((s) => s.set);

  useEffect(() => {
    if (paused) return;
    const iv = window.setInterval(() => {
      // pure updater only - no store writes here (React may run updaters
      // during render, which re-renders Hud => setState-in-render warning)
      setShown((v) => Math.min(v + 2, text.length));
    }, 26);
    return () => window.clearInterval(iv);
  }, [text, paused]);

  // report completion from an effect, never from the render path
  useEffect(() => {
    if (!paused && !doneRef.current && text.length > 0 && shown >= text.length) {
      doneRef.current = true;
      setUI({ dialogueDone: true });
    }
  }, [shown, text, paused, setUI]);

  return (
    <>
      {text.slice(0, shown)}
      <span className="vhs-blink">_</span>
    </>
  );
}

export function DialogueBox() {
  const dialogue = useGameUI((s) => s.dialogue);
  const dialogueDone = useGameUI((s) => s.dialogueDone);

  if (!dialogue) return null;

  const advance = () => getGame()?.advanceDialogue();
  const speakerColor =
    dialogue.speaker === 'K' ? 'text-[#8fd8a0]' : dialogue.speaker === 'YOU' ? 'text-[#f2ecd2]' : 'text-[#e08b8b]';

  return (
    <div
      className="fixed bottom-10 left-1/2 z-30 w-[min(92vw,760px)] -translate-x-1/2 cursor-pointer select-none font-vhs"
      onClick={advance}
    >
      <div className="border-2 border-[#f2ecd2]/70 bg-black/75 p-4 shadow-[0_0_24px_rgba(0,0,0,0.8)]">
        <div className={`mb-1 text-lg tracking-widest ${speakerColor}`}>
          {dialogue.speaker === 'K' ? 'K - M.E.G. RADIO' : dialogue.speaker === 'YOU' ? 'YOU' : '???'}
          {dialogue.garble && <span className="ml-2 text-sm opacity-60 vhs-blink">-zzt-</span>}
        </div>
        <div className="min-h-[3.2rem] text-xl leading-snug text-[#f2ecd2] md:text-2xl vhs-text">
          <Typewriter key={dialogue.text} text={dialogue.text} paused={dialogueDone} />
        </div>
        <div className="mt-1 text-right text-sm opacity-60">
          {dialogueDone ? 'TAP / [SPACE] TO CONTINUE' : 'TAP / [SPACE] TO SKIP'}
        </div>
      </div>
    </div>
  );
}
