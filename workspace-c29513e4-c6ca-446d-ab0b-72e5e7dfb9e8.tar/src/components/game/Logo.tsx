'use client';

// The game's logo lockup: distressed tape-label wordmark with the Smiler
// hiding in the REC badge. Pure DOM/CSS so it stays crisp at any size and
// picks up the same VHS treatment as the rest of the UI.

function SmilerBadge({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <circle cx="12" cy="12" r="10.6" fill="#070605" stroke="#e03b2f" strokeWidth="1.6" />
      <path
        d="M6.6 10.8 Q12 18.6 17.4 10.8"
        stroke="#f5f2e0"
        strokeWidth="2.1"
        fill="none"
        strokeLinecap="round"
        style={{ filter: 'drop-shadow(0 0 2.2px rgba(245,242,224,0.9))' }}
      />
      <path d="M7.6 7.4 L10.6 8.3" stroke="#f5f2e0" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M16.4 7.4 L13.4 8.3" stroke="#f5f2e0" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function GameLogo({ hero = false }: { hero?: boolean }) {
  return (
    <div className={`select-none ${hero ? 'leading-none' : ''}`}>
      {/* archive strip */}
      <div
        className={`flex items-center gap-2 font-vhs tracking-[0.32em] text-[#c8b878] ${
          hero ? 'text-[11px] md:text-sm' : 'text-[10px]'
        }`}
      >
        <span className="inline-block h-[2px] w-8 bg-[#c8b878]/70" />
        <span>M.E.G. FIELD ARCHIVE // RECOVERED MEDIA</span>
        <span className="inline-block h-[2px] flex-1 bg-[#c8b878]/70" />
      </div>

      {/* wordmark */}
      <h1
        className={`logo-grunge logo-gradient font-vhs font-bold ${
          hero ? 'mt-2 text-[clamp(2.6rem,6.5vw,5.2rem)]' : 'text-3xl'
        } leading-[0.92] tracking-[0.045em]`}
      >
        THE BACKROOMS
      </h1>

      {/* plate row: smiley REC badge + LEVEL 0 plate + FOUND FOOTAGE strip */}
      <div className={`mt-2 flex items-center gap-3 ${hero ? '' : 'mt-1'}`}>
        <span className={`relative inline-flex ${hero ? 'h-9 w-9 md:h-11 md:w-11' : 'h-6 w-6'}`}>
          <SmilerBadge className="absolute inset-0 h-full w-full" />
          <span className="absolute inset-0 animate-ping rounded-full bg-[#e03b2f]/25" />
        </span>
        <span
          className={`border-2 border-[#e8e2d0]/85 bg-[#e03b2f] px-2 font-vhs font-bold tracking-[0.18em] text-[#0d0a04] ${
            hero ? 'text-xl md:text-2xl' : 'text-sm'
          }`}
          style={{ textShadow: 'none' }}
        >
          LEVEL 0
        </span>
        <span
          className={`font-vhs tracking-[0.42em] text-[#ddd8c2]/90 ${
            hero ? 'text-sm md:text-base' : 'text-[10px]'
          }`}
        >
          FOUND FOOTAGE
        </span>
      </div>
    </div>
  );
}
