// Full-screen note reader overlay (pauses the world while open).

'use client';

import { useGameUI } from '@/lib/game/store';
import { getGame } from '@/lib/game/game';

export function NoteOverlay() {
  const noteOpen = useGameUI((s) => s.noteOpen);
  const touch = useGameUI((s) => s.touch);
  if (!noteOpen) return null;

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4"
      onClick={() => getGame()?.closeNote()}
    >
      <div
        className="max-h-[86vh] w-[min(94vw,620px)] overflow-y-auto p-6 md:p-8 shadow-[0_0_50px_rgba(0,0,0,0.9)]"
        style={{
          background: 'linear-gradient(160deg, #e9e2c8 0%, #ddd4b4 60%, #cfc5a2 100%)',
          boxShadow: 'inset 0 0 60px rgba(90,70,30,0.25), 0 0 40px rgba(0,0,0,0.8)',
          transform: 'rotate(-0.6deg)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 font-vhs text-xl tracking-widest text-[#4a3d20] md:text-2xl">{noteOpen.title}</div>
        <div className="whitespace-pre-wrap text-[17px] leading-relaxed text-[#2f2a1c] md:text-lg" style={{ fontFamily: '"Courier New", monospace' }}>
          {noteOpen.body}
        </div>
        <div className="mt-6 text-right font-vhs text-lg text-[#6b5c34]">
          [{touch ? 'TAP' : 'E'}] PUT PAGE BACK
        </div>
      </div>
    </div>
  );
}
