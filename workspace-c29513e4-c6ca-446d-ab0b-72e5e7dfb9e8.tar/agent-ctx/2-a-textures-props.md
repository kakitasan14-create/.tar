# Task 2-a — Work Record: Crate Wood Texture + CrateStack Texturing + Camcorder Lens Upgrade

**Files touched (only these two):**
- `src/lib/game/textures.ts`
- `src/lib/game/props.ts`

## JOB 1 — `makeCrateWood(seed: number): TextureSet` (textures.ts)
- New export placed right after `makeConcrete` (~line 519). 256x256, same three-canvases-in-one-pass pattern (color + rough + bump, per-pixel ImageData loop, then 2D overlay passes, returns `{ map: toTexture(c), rough: toDataTexture(rc), bump: toDataTexture(bc) }`).
- Content: 4 horizontal pine planks (seams at tile edges so it wraps), warm aged base `#8a7148` with per-plank tone jitter + broad mottle + long horizontal grain streaks (PeriodicNoise with v-axis stretched, integer multipliers → stays tileable), fine fiber tooth, soft groove + chamfer ridge per seam plus crisp 2px seam lines.
- Overlays: 8 rusted nail heads near plank ends (dark press ring → rusty steel disc → tiny glint; **bump: bright/proud**, rough: shinier), corner chafing specks (pale raw-wood + grime, rough: shinier), one faint elliptical water ring stain (tide line, lower-right quadrant, clear of the stencil), and the worn stencil: up-arrow + `THIS SIDE UP` (bold 17px Courier) + `M.E.G. SUPPLY 12` (bold 11px) in worn dark paint `#32291c` @ 0.55, eroded via `destination-out` speckle rects (same trick as `makeDoorMetal`; opaque materials ignore the punched alpha, ink RGB gets chewed). Identical speckle rects also erode the faint bump imprint (ink a hair proud) and rough imprint (paint sheens off raw wood).
- **Registered in `GameTextures` as `crateWood: TextureSet;`** with doc comment `/** Shipping crate: aged pine planks, nails, M.E.G. supply stencil. */` (right after `concrete`), and in `buildTextures` registry as `crateWood: makeCrateWood(seed),` right after `concrete: makeConcrete(seed),`.

## JOB 2 — `buildCrateStack` (props.ts, ~line 61)
- New signature: `export function buildCrateStack(tex?: { map: THREE.Texture; bumpMap?: THREE.Texture }): { group: THREE.Group; collider: { w: number; d: number } }` — optional param, zero-arg call sites still compile and behave identically (flat Lambert boxes `0x6a5a3c` / `0x5a4c32`).
- When `tex` provided: builds the two crate meshes **directly** with `new THREE.Mesh(BoxGeometry(...), woodMat)` (NOT via `box()`, which returns MeshLambertMaterial), where `woodMat = new THREE.MeshStandardMaterial({ map, bumpMap: tex.bumpMap ?? null, bumpScale: 0.25, roughness: 0.85, metalness: 0 })`. `?? null` avoids three.js "parameter has value of undefined" console spam.
- Geometry sizes, positions, `rotation.y = 0.3`, and collider `{ w: 0.8, d: 0.8 }` untouched. Both crates share one material instance.

## JOB 3 — Lens upgrade in shared `buildLensAssembly()` (props.ts, ~line 276)
- Outer bezel ring (was flat Lambert `0xa6abb3` "silver"): now `MeshStandardMaterial({ color: 0x2b2e30, metalness: 0.7, roughness: 0.35 })` — dark gunmetal. Geometry + z=0.108 unchanged.
- Inner step ring (was Lambert `0x565b62` bevel): now `MeshStandardMaterial({ color: 0x1d2022, metalness: 0.65, roughness: 0.5 })` — a shade darker than bezel, sinking inward. Geometry + z=0.119 unchanged.
- Front glass: `MeshBasicMaterial 0x0a1016` → `MeshStandardMaterial({ color: 0x090b0d, metalness: 0.6, roughness: 0.15 })` so direct menu light glazes a real specular across it.
- Coated inner element: `MeshBasicMaterial 0x152631` → `MeshStandardMaterial({ color: 0x111c22, metalness: 0.5, roughness: 0.25 })`, same z=0.121.
- NEW (1 extra low-poly mesh): thin torus ring highlight inside the glass — `TorusGeometry(0.036, 0.0016, 6, 24)`, unlit `0x39464d`, z=0.1215; plus the existing glint dot brightened (`0x2c4a58` → unlit `0xa9bac1`, r 0.008→0.006, same offset 0.014/0.011/z=0.122) — tiny offset specular dot that survives gloom.
- Barrel (mount/focus/teeth/zoom/hood), LCD, stickers, LEDs untouched. `buildCamcorder(feedTex)` signature and returned refs (`recLed`, `recDot`) unchanged. Both camcorders share this assembly, so the viewmodel gets the same look for free.

## Verification
- `bun run lint`: **0 errors**, only the pre-existing benign `@next/next/no-page-custom-font` warning in `src/app/layout.tsx` (not my file).
- `bunx tsc --noEmit`: **0 errors under `src/`** (only pre-existing errors in `examples/` and `skills/`, unrelated).
- dev.log: hot recompiles `✓ Compiled` clean after edits.

## Notes / risks for other agents
- Wiring `buildCrateStack`: pass `{ map: T.crateWood.map, bumpMap: T.crateWood.bump }` from `buildTextures()` output (`T.crateWood.rough` is available if you also want a roughnessMap — `woodMat.roughnessMap = tex.rough` would need a tiny props.ts change; not wired per spec).
- `level.ts` / `hub.ts` currently call `P.buildCrateStack()` with no args — still valid (flat-color fallback), so wiring the texture is purely additive.
- Texture is authored 1:1 per crate face (BoxGeometry default UVs 0..1 per face) — no repeat tweak needed.
- The stencil erosion punches alpha in the map canvas (house trick from `makeDoorMetal`); only safe for **opaque** materials — the provided `MeshStandardMaterial` (transparent defaults to false) is correct. Don't set `transparent: true` on the crate material.
